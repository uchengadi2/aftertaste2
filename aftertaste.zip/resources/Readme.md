# ext-theme-neptune-014a4d65-146d-43d4-9818-b62f0e14dcd9/resources

This folder contains static resources (typically an `"images"` folder as well).
