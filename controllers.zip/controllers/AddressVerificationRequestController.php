<?php

class AddressVerificationRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','requestforaddressverification','ListAllPendingVerificationRequest',
                                    'ListDomainPendingVerificationRequest','ListUserPendingVerificationRequest','retrieveextraaddressinfo',
                                    'deleteverificationrequest','freezeaverificationrequest','verifyingaverificationtionrequest',
                                    'notverifyingaverificationtionrequest','ListAllVerifiedVerificationRequest','ListAllUnverifiedVerificationRequest',
                                    'ListDomainVerifiedVerificationRequest','ListDomainUnverifiedVerificationRequest','ListUserVerifiedVerificationRequest',
                                    'ListUserUnverifiedVerificationRequest','ListAllRequestForAnInvoice','getunitcostandtotals',
                                    'requestforaddressreverification','ListDomainBillableRequestForAnInvoice','gettransactioncostparameters'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	 /**
         * This is the function that requests for the verification of an address
         */
        public function actionrequestforaddressverification(){
            
            $model = new AddressVerificationRequest;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $street_id = $_REQUEST['street_id'];
            
            $address_id = $_REQUEST['address_id'];
            
             //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           // $location_invoice_id = 0;
            
            $model->address_id = $address_id;
            $model->invoice_id = $location_invoice_id;
            $model->status = strtolower("requested");
            $model->type = strtolower("fresh");
            $model->requestor_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->requestor_id = Yii::app()->user->id;
            
            $model->verification_code = $model->generateTheVerificationCode($user_id,$domain_id);
            
            if($location_invoice_id>0){
                if($model->isThisRequestNotAlreadyMade($address_id,$user_id,$domain_id)){
                    if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "We have recieved your request for address verification and will commence work immediately. However, this is your verification code '$model->verification_code'";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The request for verification has some issues. Please contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
                
                    
                    
                }else{
                     //$result['success'] = 'false';
                         $msg = 'You have made this request before. Please be patient as the verification exercise is on going. We will get back to you shortly';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                }
                 
            }else{
                 //$result['success'] = 'false';
                         $msg = "'There was an issue trying to generate a new invoice for this user's location/branch. Please contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg,
                                        "location"=>$location_invoice_id)
                           );
            }
           
            
            
            
            
            
            
            
        }
        
        
        /**
         * This is the function that confirms if a domain has an existing transaction tree
         */
        public function isDomainWithLiveTransaction($domain_id){
            $model = new DomainTransactions;
            return $model->isDomainWithLiveTransaction($domain_id);
        }
        
        
        /**
         * This is the function that creates a new domain transaction tree
         */
        public function newDomainTransactionTreeAdded($domain_id){
            $model = new DomainTransactions;
            return $model->newDomainTransactionTreeAdded($domain_id);
        }
        
        
        /**
         * This is the function that returns the live domain transaction code
         */
        public function getTheLiveDomainTransId($domain_id){
            $model = new DomainTransactions;
            return $model->getTheLiveDomainTransId($domain_id);
        }
        
        
        
        /**
         * This is the function that retrieves domain id of a user
         */
        public function determineAUserDomainIdGiven($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
        
        
        /**
         * This is the function that retrieves the pending invoice id of a user's location
         */
        public function getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id){
            $model = new Invoice;
            return $model->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
        }
        
        
        /**
         * This is the function that list all pending verifications request
         */
        public function actionListAllPendingVerificationRequest(){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>"requested");
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
             if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $requests
            
                       ));
                }     
                       
        }
        
        
        
         /**
         * This is the function that list all pending domain verifications request
         */
        public function actionListDomainPendingVerificationRequest(){
             
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and requestor_domain_id=:domainid';
            $criteria->params = array(':status'=>"requested",':domainid'=>$domain_id);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
             if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $requests
            
                       ));
                }     
                       
        }
        
        
        
          /**
         * This is the function that list user pending domain verifications request
         */
        public function actionListUserPendingVerificationRequest(){
            $user_id = Yii::app()->user->id;
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and requestor_id=:requestorid';
            $criteria->params = array(':status'=>"requested",':requestorid'=>$user_id);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
             if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $requests
            
                       ));
                }     
                       
        }
        
        
        
        /**
         * This is the function that retrieves extra info for an address
         */
        public function actionretrieveextraaddressinfo(){
            
            $model = new State;
            $address_id = $_REQUEST['address_id'];
            $requestor_id = $_REQUEST['requestor_id'];
            $requestor_doman_id = $_REQUEST['requestor_doman_id'];
            
            
            //get the name of the 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$address_id);
             $address= Address::model()->find($criteria);
             
             
            //get the name of the 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$address['street_id']);
             $street= Street::model()->find($criteria);
             
             
             //get the city details
             
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$street['city_id']);
             $city= City::model()->find($criteria);
             
                          
             //get the name  and domain of the requestor
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$requestor_id);
             $user= User::model()->find($criteria);
             
             
            //get the name  and domain of the requestor
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$requestor_doman_id);
             $domain= Resourcegroupcategory::model()->find($criteria);
             
             $countryname = $model->getTheCountryOfThisState($city['state_id']);
             
                       
             $statename = $model->getTheNameOfThisState($city['state_id']);
             
             //get the location of this requestor
             $location = $this->getTheLocationOfThisUser($requestor_id);
             
             $cityname = $city['name'];
             
             $streetname = $street['name'];
             
             $number = $address['house_number'];
             
             $requestor = $user['name'];
             
             $domainname = $domain['name'];
             
             if($street===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "statename" => $statename,
                           "countryname"=>$countryname,
                           "cityname"=>$cityname,
                           "address"=>$number,
                           "requestor"=>$requestor,
                           "domain"=>$domainname,
                           "streetname"=>$streetname,
                           "location"=>$location)
                       );
                       
                }
            
            
        }
        
        
        /**
         * This is the function that deletes a verification request
         */
        public function actiondeleteverificationrequest(){
            
            $_id = $_POST['id'];
            $model=  AddressVerificationRequest::model()->findByPk($_id);
           
          
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "This verification request is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = "Attempt to delete this verification  wss  not successful";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
        }
        
        
        /**
         * This is the function that will freeze a verification request
         */
        public function actionfreezeaverificationrequest(){
            $model = new AddressVerificationRequest;
            $id = $_REQUEST['id'];
            if($model->isTheFreezingOfThisRequestASuccess($id)){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>"This verification request is frozen successfully"
            
                       ));
            }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The attempt to freeze this verification request is not successfully. Please contact customer service for assistance"
            
                       ));
            }
            
        }
        
        
        /**
         * This is the function that verifies an address verification request
         */
        public function actionverifyingaverificationtionrequest(){
            $model = new AddressVerificationRequest;
            $id = $_REQUEST['id'];
            $address_id = $_REQUEST['address_id'];
            if($model->isTheVerificationOfThisRequestASuccess($id)){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>"This address verification request is successfully verified"
            
                       ));
            }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The attempt to verify this verification request is not successfully. Please contact customer service for assistance"
            
                       ));
            }
        }
        
        
        
         /**
         * This is the function that verifies an address verification request that could not be verified
         */
        public function actionnotverifyingaverificationtionrequest(){
            $model = new AddressVerificationRequest;
            $id = $_REQUEST['id'];
            $address_id = $_REQUEST['address_id'];
            if($model->isNotVerificationOfThisRequestASuccess($id)){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>"This address verification request is successfully not verified"
            
                       ));
            }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"The attempt to not verify this verification request is not successfully. Please contact customer service for assistance"
            
                       ));
            }
        }
        
        
        /**
         * This is the function that gets the location of a user
         */
        public function getTheLocationOfThisUser($requestor_id){
            $model = new DomainLocations;
            return $model->getTheLocationOfThisUser($requestor_id);
        }
        
        
        /**
         * This is the function that list all verified address request for all domains
         */
        public function actionListAllVerifiedVerificationRequest(){
            $model = new Invoice;
            
            //retrieve all invoice that are still pending
            $invoices = $model->getAllPendingInvoices();
            
            $targets = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>"verified");
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $request){
                if(in_array($request['invoice_id'],$invoices)){
                    $targets[] = $request;
                }
            }
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $targets,
                         )
                       );
                       
                }
            
        }
        
        
        
        
        /**
         * This is the function that list all unverified address request for all domains
         */
        public function actionListAllUnverifiedVerificationRequest(){
            $model = new Invoice;
            
            //retrieve all invoice that are still pending
            $invoices = $model->getAllPendingInvoices();
            
            $targets = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>"not_verified");
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $request){
                if(in_array($request['invoice_id'],$invoices)){
                    $targets[] = $request;
                }
            }
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $targets,
                         )
                       );
                       
                }
            
        }
        
        
        
        /**
         * This is the function that list all verified address request for a domain
         */
        public function actionListDomainVerifiedVerificationRequest(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $model = new Invoice;
            
            //retrieve all invoice that are still pending
            $invoices = $model->getAllPendingInvoices();
            
            $targets = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and requestor_domain_id=:domain';
            $criteria->params = array(':status'=>"verified",':domain'=>$domain_id);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $request){
                if(in_array($request['invoice_id'],$invoices)){
                    $targets[] = $request;
                }
            }
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $targets,
                         )
                       );
                       
                }
            
        }
        
        
        
        /**
         * This is the function that list all unverified address request for a domain
         */
        public function actionListDomainUnverifiedVerificationRequest(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $model = new Invoice;
            
            //retrieve all invoice that are still pending
            $invoices = $model->getAllPendingInvoices();
            
            $targets = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and requestor_domain_id=:domain';
            $criteria->params = array(':status'=>"not_verified",':domain'=>$domain_id);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $request){
                if(in_array($request['invoice_id'],$invoices)){
                    $targets[] = $request;
                }
            }
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $targets,
                         )
                       );
                       
                }
            
        }
        
        
        
         /**
         * This is the function that list all verified address request by a user
         */
        public function actionListUserVerifiedVerificationRequest(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $model = new Invoice;
            
            //retrieve all invoice that are still pending
            $invoices = $model->getAllPendingInvoices();
            
            $targets = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and requestor_id=:userid';
            $criteria->params = array(':status'=>"verified",':userid'=>$user_id);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $request){
                if(in_array($request['invoice_id'],$invoices)){
                    $targets[] = $request;
                }
            }
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $targets,
                         )
                       );
                       
                }
            
        }
        
        
        
        /**
         * This is the function that list all unverified address request by a user
         */
        public function actionListUserUnverifiedVerificationRequest(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $model = new Invoice;
            
            //retrieve all invoice that are still pending
            $invoices = $model->getAllPendingInvoices();
            
            $targets = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and requestor_id=:userid';
            $criteria->params = array(':status'=>"not_verified",':userid'=>$user_id);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $request){
                if(in_array($request['invoice_id'],$invoices)){
                    $targets[] = $request;
                }
            }
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $targets,
                         )
                       );
                       
                }
            
        }
        
        
        /**
         * This is the function that list all request in an invoice
         */
        public function actionListAllRequestForAnInvoice(){
            $invoice_id  = $_REQUEST['invoice_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='invoice_id=:invoice and status=:status';
            $criteria->params = array(':invoice'=>$invoice_id, ':status'=>"verified");
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
             if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "invoice" => $requests,
                         )
                       );
                       
                }
        }
        
        
        
         /**
         * This is the function that gets the unit and total cost of transaction
         */
        public function actiongetunitcostandtotals(){
            
            $invoice_id  = $_REQUEST['invoice_id'];
            
            $total_cost = 0;
            
            //get the unit cost 
            $unit_cost = $this->getTheUnitCostOfVerificationTransaction();
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='invoice_id=:invoice and status=:status';
            $criteria->params = array(':invoice'=>$invoice_id,':status'=>"verified");
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $req){
                $total_cost = $total_cost + $unit_cost;
            }
            
             if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "total_cost" => $total_cost,
                            "unit_cost"=>$unit_cost
                         )
                       );
                       
                }
            
        }
        
        
        /**
         * this is the function that gets the unit xost of consumption transaction
         */
        public function getTheUnitCostOfVerificationTransaction(){
            $model = new VerificationCost;
            return $model->getTheUnitCostOfConsumptionTransaction();
        }
        
        
        
         /**
         * This is the function that requests for the reverification of an address
         */
        public function actionrequestforaddressreverification(){
            
            $model = new AddressVerificationRequest;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $street_id = $_REQUEST['street_id'];
            
            $address_id = $_REQUEST['address_id'];
            
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           // $location_invoice_id = 0;
            
            $model->address_id = $address_id;
            $model->invoice_id = $location_invoice_id;
            $model->status = strtolower("requested");
            $model->type = strtolower("reverified");
            $model->requestor_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->requestor_id = Yii::app()->user->id;
            
            $model->verification_code = $model->generateTheVerificationCode($user_id,$domain_id);
            
            if($location_invoice_id>0){
                if($model->isThisRequestNotAlreadyMade($address_id,$user_id,$domain_id)){
                    if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "We have recieved your request for address reverification and will commence work immediately. However, this is your reverification code '$model->verification_code'";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The request for reverification has some issues. Please contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
                
                    
                    
                }else{
                     //$result['success'] = 'false';
                         $msg = 'You have made this request before. Please be patient as the verification exercise is on going. We will get back to you shortly';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    
                }
                 
            }else{
                 //$result['success'] = 'false';
                         $msg = "'There was an issue trying to generate a new invoice for this user's location/branch. Please contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg,
                                        "location"=>$location_invoice_id)
                           );
            }
 
        }
        
        
        
        /**
         * This is the  function that retrieves all billable domain transactions
         */
        public function actionListDomainBillableRequestForAnInvoice(){
           $transid = $_REQUEST['trans_id'];
           
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_transaction_id=:transid';
            $criteria->params = array(':transid'=>$transid);
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "request" => $requests,
                            
                         )
                       );
                       
                }
            
            
        }
        
        
        /**
         * This is the function thats get transaction cost parameters based on trans id
         */
        public function actiongettransactioncostparameters(){
            $trans_id  = $_REQUEST['trans_id'];
            
            $total_cost = 0;
            
            //get the unit cost 
            $unit_cost = $this->getTheUnitCostOfVerificationTransaction();
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_transaction_id=:transid and status=:status';
            $criteria->params = array(':transid'=>$trans_id,':status'=>"verified");
            $requests= AddressVerificationRequest::model()->findAll($criteria);
            
            foreach($requests as $req){
                $total_cost = $total_cost + $unit_cost;
            }
            
             if($requests===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "total_cost" => $total_cost,
                            "unit_cost"=>$unit_cost
                         )
                       );
                       
                }
            
        }
}
