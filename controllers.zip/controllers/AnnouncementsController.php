<?php

class AnnouncementsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'AnnouncementBroadcast', 'determineAUserDomainIdGiven',
                                    'ListAllAnnouncements','retrieveThisAnnouncementForUpdate', 'RetrieveThisAnnouncementForEdit',
                                    'AnnouncementForUpdate','DeleteOneAnnouncement','determineAllToolsAssignedToThisUser','determineAllToolboxesAssignedToThisUser',
                                    'ListAllAnnouncementsForThisTool', 'isThisTheMostCurrentAnnouncementForThisTool','RetrieveThisToolAnnouncement'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Announcements;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Announcements']))
		{
			$model->attributes=$_POST['Announcements'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Announcements']))
		{
			$model->attributes=$_POST['Announcements'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Announcements');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Announcements('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Announcements']))
			$model->attributes=$_GET['Announcements'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}
        
        /**
         * This is the function that save a new announcement to the database
         */
        public function actionAnnouncementBroadcast(){
           
            //get the id of the use logged in
            $userid = Yii::app()->user->id;
            
            //obtain the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            
           $model=new Announcements;
            
            $model->resource_id = $_POST['id'];
            $model->announcement = $_POST['announcement'];
            $model->category_id = $domainid;
            $model->description = $_POST['description'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New Anouncement Broadcasted Successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Announcement Failed To Broadcast';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
            
        }
        
        /**
         * This is the function that retrieves an announcement for updating
         */
        public function actionAnnouncementForUpdate(){
            
            //get the state id
            $toolname = $_POST['tool'];
            
            $_id = $_POST['id'];
            $model=Announcements::model()->findByPk($_id);
            $model->announcement = $_POST['announcement'];
            $model->description = $_POST['description'];
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            if(is_numeric($toolname)) {
                $model->resource_id = $toolname;
                
            }else{
                               
                $model->resource_id = $this->determineResourceOrToolId($toolname);
               
                
            }
            
            $model->description = $_POST['description'];
            $model->update_time = new CDbExpression('NOW()');
          
            if($model->save()){
                        //$data['success'] = 'true';
                        $msg = 'Update of this Announcement information was successful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                    //$data['success'] = 'false';
                    $msg = 'Update of this Announcement information was not successful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                }
            
        }
        
        
        /**
         * This is the function that retrieves an announcement for updating
         */
        public function actionRetrieveThisAnnouncementForUpdate(){
            
           $_id = $_REQUEST['id'];
          // $_id = 1;
           $criteria = new CDbCriteria();
           $criteria->select = 'id, announcement, resource_id, description';
           $criteria->condition='id=:id';
           $criteria->params = array(':id'=>$_id);
           $announcement = Announcements::model()->find($criteria);  
           
           //obtain the name of the tool/resource
           
           $toolname = $this->determineResourceOrToolName($announcement['resource_id']);
           
           if($announcement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "announcement" => $announcement,
                           "tool" => $toolname)
                       );
                       
                } 
        }
        
        /**
         * This is the function that list all announcements for all tools in a domain
         */
        public function actionListAllAnnouncements(){
           //get the id of the use logged in
            $userid = Yii::app()->user->id;
            
            //obtain the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAnnouncementSupport")){
                //spool all the announcement belonging to this domain
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            //$criteria->condition='category_id=:id';
            //$criteria->params = array(':id'=>$domainid);
            $announcements= Announcements::model()->findAll($criteria1);
            
            if($announcements===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "announcement" => $announcements
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
                
            }else{
                
                //spool all the announcement belonging to this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='category_id=:id';
            $criteria->params = array(':id'=>$domainid);
            $announcements= Announcements::model()->findAll($criteria);
            
            if($announcements===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "announcement" => $announcements
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            }
            
            
            
        }
        
        /**
         * This is the function that retrieves all announcements base on tools assigned to a user
         */
        public function actionListAllAnnouncementsForThisTool(){
            
            //obtain the logged in user id
            $userid = Yii::app()->user->id;
            
            //obtain all the tools assigned to this user
            $usertools = $this->determineAllToolsAssignedToThisUser($userid);
            
            //for each of the tools retrieve all announcements on those tools
            $allannouncement = [];
            
          foreach($usertools as $usertool){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resource_id=:id';
                $criteria->params = array(':id'=>$usertool);
                $announcements= Announcements::model()->findAll($criteria);
                
                $allannouncement = array_merge($allannouncement,$announcements);
                
                
            }
            
           
            if($allannouncement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "announcement" =>  $allannouncement
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            
        }
        
        
        /**
         * This is the function that retrieves all announcement information for viewing
         */
        public function actionRetrieveThisToolAnnouncement(){
            
            //$_id = $_POST['id'];
            
             $_id = 1;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$_id);
            $announcement= Announcements::model()->find($criteria);
            
            $domainowner = $this->determineDomainNameGivenItId($announcement['category_id']);
            $tool = $this->determineResourceOrToolName($announcement['resource_id']);
            //determine if this announcement is the most current
           // $status = $this->isThisTheMostCurrentAnnouncementForThisTool($announcement['resource_id'],$announcement['create_time']);
            
            
            //spool the requester detail
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, firstname, middlename, lastname';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$announcement['create_user_id']);
            $user= User::model()->find($criteria1);
            
            if($announcement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"status" => $status,
                            "domain" => $domainowner,
                            "tool" =>$tool,
                           "user" =>$user,
                           "announcement" =>$announcement
                          
                           
                          
                       ));
                       
                } 
            
        }
        
        
        
        
        /**
         * This is the function to delete one announcement
         */
        public function actionDeleteOneAnnouncement(){
            
            $_id = $_POST['id'];
            $model=Announcements::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'Announcement Successfully Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'Announcement Not Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that determines all tools assigned to a user
         */
        public function determineAllToolsAssignedToThisUser($userid){
            
            $allusertoolboxes = [];
            //determine all toolboxes assigned to this user
            
            $usertoolboxes = $this->determineAllToolboxesAssignedToThisUser($userid);
            
            $allusertoolboxes = array_merge($allusertoolboxes, $usertoolboxes);
                  
           
            //determine all subgroups this user was assigned to
            $usersubgroups = $this->determineAllUserSubgroups($userid);
            
            if($usersubgroups != null or $allusertoolboxes !=null ){
                //determine all toolboxes assigned to this subgroup
           
                
            if($usersubgroups != null){
                
                $allsubgrouptoolboxes = [];
            foreach($usersubgroups as $usersubgroup){
                
                $criteria1 = new CDbCriteria();
                $criteria1->select = 'subgroup_id, resourcegroup_id';
                $criteria1->condition='subgroup_id=:id';
                $criteria1->params = array(':id'=>$usersubgroup);
                $toolboxes= SubgroupHasResourcegroup::model()->findAll($criteria1);
                
               $allsubgrouptoolboxes = array_merge($allsubgrouptoolboxes, $toolboxes);
                
            }
                
             foreach($allsubgrouptoolboxes as $allsubgrouptoolbox){
                
                  $allusertoolboxes[] = $allsubgrouptoolbox['resourcegroup_id'];
            }
            
             //determine all the group for each subgroup
            $allgroups = [];
            foreach($usersubgroups as $subgroup){
                
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, group_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$subgroup);
                $groups= SubGroup::model()->find($criteria2);
                
                $allgroups[] = $groups['group_id'];
                
            }
            
            //determine all toolboxes assigned to these groups
            $allgrouptoolboxes = [];
            foreach($allgroups as $allgroup){
                
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'group_id, resourcegroup_id';
                $criteria3->condition='group_id=:id';
                $criteria3->params = array(':id'=>$allgroup);
                $grouptoolboxes= GroupHasResourcegroup::model()->findAll($criteria3);
                
                $allgrouptoolboxes = array_merge($allgrouptoolboxes,$grouptoolboxes);
                
            }
           
            foreach($allgrouptoolboxes as $allgrouptoolbox){
                
                $allusertoolboxes[] = $allgrouptoolbox['resourcegroup_id'];
            }
            
            //make the toolbox array unique
            
            }  //end of the subgroup not null if statement  
            
            
            $uniquetoolboxes = array_unique($allusertoolboxes,SORT_REGULAR);
           
            $allusertools = [];
           
            foreach($uniquetoolboxes as $uniquetoolbox){
                
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'resource_id, resourcegroup_id';
                $criteria4->condition='resourcegroup_id=:id';
                $criteria4->params = array(':id'=>$uniquetoolbox);
                $tools= ResourceHasResourcegroups::model()->findAll($criteria4);
                
                $allusertools = array_merge($allusertools,$tools);
                
                
            }
             $alltools = [];
             foreach($allusertools as $allusertool){
                 
                 $alltools[] = $allusertool['resource_id'];
             }
             
             //make the tools unique
             $uniquetools = array_unique($alltools,SORT_REGULAR);
                       
             //return $uniquetools;
             
             if($uniquetools===null) {
                return null;
            
         }else{
              
            return $uniquetools;
            
         } 
             
         }//end of the subgroup not null loop
       
         
            
        }
        
        
        /**
         * This is the function that determines all toolboxes directly assigned to a user
         */
        public function determineAllToolboxesAssignedToThisUser($userid){
            
             $alltoolboxes = [];
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, resourcegroup_id';
             $criteria4->condition='user_id=:id';
             $criteria4->params = array(':id'=>$userid);
             $toolboxes= UserHasResourcegroup::model()->findAll($criteria4);
             
             foreach($toolboxes as $toolbox){
                 
                 $alltoolboxes[] = $toolbox['resourcegroup_id'];
                 
             }
             
             //make it unique
             $uniquetoolboxes = array_unique($alltoolboxes);
             
             return $uniquetoolboxes;
             
           
        }
        
        
        /**
         * This is the function that determines all user's subgroup
         */
        public function determineAllUserSubgroups($userid){
            
            $allsubgroups = [];
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, subgroup_id';
             $criteria4->condition='user_id=:id';
             $criteria4->params = array(':id'=>$userid);
             $subgroups= UserHasSubgroups::model()->findAll($criteria4);
             
             foreach($subgroups as $subgroup){
                 
                 $allsubgroups[] = $subgroup['subgroup_id'];
                 
                 //make it unique
             $uniquesubgroup = array_unique($allsubgroups);
             
             return $uniquesubgroup;
             }
             
            
            
        }
        
        /**
         * This is the function that determines if an announcement is the most current
         */
        public function isThisTheMostCurrentAnnouncementForThisTool($toolid, $dateissued){
            
            //spool all the announcements for this tool
            
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'id, resource_id, create_time';
             $criteria4->condition='resource_id=:id';
             $criteria4->params = array(':id'=>$toolid);
             $announcements= Announcements::model()->findAll($criteria4);
             
             $counter = 0;
             foreach($announcements as $announcement){
                 
                 $issueddate = new DateTime($dateissued);
                 $comparedate = new DateTime($announcement['create_time']);
                 if(var_dump($issueddate<$comparedate)){
                     $counter = $counter + 1;
                 }
                
             }
            if($counter >0){
                 return false;
             }else{
                 return true;
             }
              
             
          
            
        }
        
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Announcements the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Announcements::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Announcements $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='announcements-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
