<?php

class AssetsBucketsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','updateDomainAssetBucket','addNewDomainAssetBucket','DeleteThisAssetsBuckets',
                                    'retrieveDomainBuckets','retrieveallbucketsforthisnetwork','retrieveUserAssetBuckets',
                                    'retrieveUserAssetBucketsBasedOnIssues'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds new domain resource asset
         */
        public function actionaddNewDomainAssetBucket(){
            
            $model=new AssetsBuckets;

		$user_id = Yii::app()->user->id;
                
                $domain_id = $this->determineAUserDomainId($user_id);
                
                $model->name = $_POST['name'];
                $model->domain_id = $domain_id;
                $model->description = $_POST['description'];
                $model->issues_and_values_id = $_POST['issues_and_values_id'];
                $model->date_created = new CDbExpression('NOW()');
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New Asset Bucket was Created Successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to create this Asset Bucket was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
            
        }
        
        
         /**
         * This is the function that updates assets bucket for  domain
         */
        public function actionupdateDomainAssetBucket(){
            
         $user_id = Yii::app()->user->id;
                
          $domain_id = $this->determineAUserDomainId($user_id);
            
            $_id = $_POST['id'];
            
            $model= AssetsBuckets::model()->findByPk($_id);
            
            $model->name = $_POST['name'];
            $model->domain_id = $domain_id;
            $model->description = $_POST['description'];
            $model->issues_and_values_id = $_POST['issues_and_values_id'];
            $model->date_updated = new CDbExpression('NOW()');
            if($model->save()){
                        //$data['success'] = 'true';
                        $msg = 'Update of this information was successful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                    //$data['success'] = 'false';
                    $msg = 'Attempt to update this information was not successful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all domain buckets for d domain
         */
        public function actionretrieveDomainBuckets(){
            
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainId($user_id);
           
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $criteria->order = 'name';
           $buckets = AssetsBuckets::model()->findAll($criteria);
                 
           if($buckets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "buckets" => $buckets
            
                       ));
                       
                }
           
           
            
        }
        
        
        
         /**
         * This is the function that deletes asset bucket for a domain
         */
        public function actionDeleteThisAssetsBuckets(){
            
            $_id = $_POST['id'];
            //get the name of this asset bucket
            $bucket = $this->getThisAssetBucketName($_id);
            $model= AssetsBuckets::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$bucket' asset bucket was Successfully Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$bucket' asset bucket was Not Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainId($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
         /**
         * This is the function that gets the name of a domain asset bucket
         */
        public function getThisAssetBucketName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $bucket = AssetsBuckets::model()->find($criteria);   
            
            return $bucket['name'];
        }
        
        
          /**
         * This is the function that retrieves all buckets for a network
         */
        public function actionretrieveallbucketsforthisnetwork(){
            
           $model = new NetworkHasBuckets;
            $network_id = $_REQUEST['network'];
            
            //get all the buckets for this network
            $network_buckets = $model->retrieveAllBucketsForThisNetwork($network_id);
            
            $target = [];
            foreach($network_buckets as $buck){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$buck);
                $bucket = AssetsBuckets::model()->find($criteria); 
                
                $target[] = $bucket;
            }
            
            
             if($network_buckets===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "bucket" => $target,
                                  
                                   
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that retrieves all asset buckets created by a user
         */
        public function actionretrieveUserAssetBuckets(){
            
            $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainId($user_id);
           
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='owned_by=:ownedby';
           $criteria->params = array(':ownedby'=>$user_id);
           $criteria->order = 'name';
           $buckets = AssetsBuckets::model()->findAll($criteria);
                 
           if($buckets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "buckets" => $buckets
            
                       ));
                       
                }
            
        }
        
        
        
         /**
         * This is the function that retrieves all asset buckets created by user based on issues and values
         */
        public function actionretrieveUserAssetBucketsBasedOnIssues(){
            
            $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainId($user_id);
           
           $issues = $_REQUEST['issues_and_values'];
           
           if($issues == 0){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='owned_by=:ownedby';
               $criteria->params = array(':ownedby'=>$user_id);
               $criteria->order = 'name';
               $buckets = AssetsBuckets::model()->findAll($criteria);
               
           }else{
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='owned_by=:ownedby and issues_and_values_id=:issue';
               $criteria->params = array(':ownedby'=>$user_id,':issue'=>$issues);
               $criteria->order = 'name';
               $buckets = AssetsBuckets::model()->findAll($criteria);
               
           }
           
           
                 
           if($buckets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "buckets" => $buckets
            
                       ));
                       
                }
            
        }
}
