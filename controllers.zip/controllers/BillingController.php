<?php

class BillingController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addthisinvoicetobill'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds invoices to bill
         */
        public function actionaddthisinvoicetobill(){
            $model = new Billing;
            $verification_total_cost = $_REQUEST['total_cost'];
            $consumption_total_cost = $_REQUEST['consumption_total_cost'];
            $invoice_id = $_REQUEST['invoice_id'];
            $domain_transaction_id = $_REQUEST['domain_transaction_id'];
            
            $model->invoice_id=$invoice_id;
            $model->verification_request_amount = $verification_total_cost;
            $model->consumption_request_amount = $consumption_total_cost;
            $model->domain_transaction_id = $domain_transaction_id;
            $model->date_prepard = new CDbExpression('NOW()');
            $model->prepared_by = Yii::app()->user->id;
            
             if($model->save()){
                 if($this->isTheSettingOfNewInvoiceStatusASuccess($invoice_id)){
                      $msg = 'The preparation of the bill for this invoice was successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     
                 }else{
                      $msg = 'The preparation of the bill for this invoice was successful but the attempt to alter the invoice ststus to procesed was not successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                 }
                  
               
                       
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to prepare the bill for this invoice was not successful. Please contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
            
            
        }
        
        
        /**
         * This is the function that sets the transaction date and invoice status
         */
        public function isTheSettingOfNewInvoiceStatusASuccess($invoice_id){
            $model = new Invoice;
            return $model->isTheSettingOfNewInvoiceStatusASuccess($invoice_id);
        }
}
