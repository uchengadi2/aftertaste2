<?php

class ClusterController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewCluster','UpdateCluster','DeleteOneCluster',
                                    'listPlatformcluste','listDomaincluster'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that adds new clusters
         */
        public function actionAddNewCluster(){
            
            $model = new Cluster;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->type = strtolower($_POST['type']);
            $model->description = $_POST['description'];
            if(is_numeric($_POST['hood'])){
                $model->hood_id = $_POST['hood'];
            }else{
                 $model->hood_id = $_POST['hood_id'];
            }
            $model->domain_id = $domain_id;
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            $hood_name = $this->getTheNameOfThisNeighbourhood($model->hood_id);
                     
            if($model->save()){
               $msg = "Successfully created the  '$model->name' cluster for '$hood_name' neighbourhood";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' cluster could not be created for the '$hood_name' neighbourhood";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This  is the function that gets the name of a domain
         */
        public function getTheNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
        }
        
        
        /**
         * This is the function that gets the name of a neighbourhood
         */
        public function getTheNameOfThisNeighbourhood($hood_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$hood_id);
             $hood = Neighbourhood::model()->find($criteria);   
             
             return $hood['name'];
            
        }
        
        
        
        
        /**
         * This is the function that updates cluster information
         */
        public function actionUpdateCluster(){
           
            $_id = $_POST['id'];
            $model= Cluster::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->type = strtolower($_POST['type']);
            $model->description = $_POST['description'];
            if(is_numeric($_POST['hood'])){
                $model->hood_id = $_POST['hood'];
            }else{
                 $model->hood_id = $_POST['hood_id'];
            }
            $model->domain_id = $domain_id;
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
            $hood_name = $this->getTheNameOfThisNeighbourhood($model->hood_id);
                     
            if($model->save()){
               $msg = "Successfully updated the  '$model->name' cluster for '$hood_name' neighbourhood";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' cluster could not be updated for the '$hood_name' neighbourhood";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        /**
         * This is the function that deletes a cluster
         */
        public function actionDeleteOneCluster(){
            
             $_id = $_POST['id'];
            //get the name of this location
            $name = $this->getTheNameOfThisCluster($_id);
            $model= Cluster::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$name' cluster was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$name' cluster could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        /**
         * This is the function that gets the name of a cluster
         */
        public function getTheNameOfThisCluster($id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $cluster = Cluster::model()->find($criteria);   
             
             return $cluster['name'];
            
            
        }

        
        
        /**
         * This is the function that list all clusters on the platform
         */
        public function actionlistPlatformcluster(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
              // $criteria->condition='type!=:type';
              // $criteria->params = array(':type'=>'special_report');
            $clusters = Cluster::model()->findAll($criteria);
                 
            if($clusters===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "cluster" => $clusters
            
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that list all clusters belonging to a domain
         */
        public function actionlistDomaincluster(){
           
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid';
           $criteria->params = array(':domainid'=>$domain_id);
           $clusters = Cluster::model()->findAll($criteria);
                 
           if($clusters===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "cluster" => $clusters
            
                       ));
                       
                }
            
            
        }
}
