<?php

class ContextsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ListAllContextsInThePlatform','ListAllContexts'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewContext','UpdateContext','DeleteOneContext','ListAllContexts',
                                    'ListAllContextsInThePlatform'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add a new context/stage  to the platform
         */
        public function actionAddNewContext(){
            
            $model=new Contexts;
            
             //get the logged in user id
            $userid = Yii::app()->user->id;
            
            $model->name = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            
            //$model->domain_id = $domainid;
            $model->create_user_id = $userid;
            $model->create_time = new CDbExpression('NOW()');
                      
           
             if($model->save()){
                      
                            $msg = "'$model->name' new media context was successfully added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "'$model->name' media context was not added";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
        }
        
        
        /**
         * This is the function that updates the context table
         */
        public function actionUpdateContext(){
            
            $_id = $_POST['id'];
            $model=Contexts::model()->findByPk($_id);
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
                                
            $model->name = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            //$model->domain_id = $domainid;
            $model->update_user_id = $userid;
            $model->update_time = new CDbExpression('NOW()');
                      
           
             if($model->save()){
                      
                            $msg = " '$model->name' media context was updated successfully";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "'$model->name' media context was not updated";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
        }
        
        
        /**
         * This is the function that deletes one context from the platform
         */
        public function actionDeleteOneContext(){
            
            $_id = $_POST['id'];
            //get the name of the context
            $context_name = $this->getThisContextName($_id);
            $model=Contexts::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$context_name' Context was Successfully Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$context_name' context was Not Deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
        }

        
        
        /**
         * This is the function that retrieves the name of a context
         */
        public function getThisContextName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $context = Contexts::model()->find($criteria);   
            
            return $context['name'];
            
        }
        
        /**
         * This is the function that list all context on the platform
         */
        public function actionListAllContexts(){
            
             //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
           //spool all the contexts on the platform
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='domain_id=:id';
            //$criteria->params = array(':id'=>$domainid);
            $contexts= Contexts::model()->findAll($criteria);
            
                if($contexts===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "context" => $contexts
          
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that list all contexts in this platform
         */
        public function actionListAllContextsInThePlatform(){
            
            //spool all the contexts on the platform
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='domain_id=:id';
            //$criteria->params = array(':id'=>$domainid);
            $contexts= Contexts::model()->findAll($criteria);
            
                if($contexts===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "context" => $contexts
          
                       ));
                       
                }
        }
        
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Contexts the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Contexts::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Contexts $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='contexts-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
