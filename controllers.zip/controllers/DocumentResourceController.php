<?php

class DocumentResourceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllDocumentComplementaryResources','listPlatformDocumentComplementaryResources',
                                    'addNewDocumentResourceToThisDocument','editThisDocumentResourceInThisDocument',
                                    'deleteonedocumentresource','RetrieveThisDocumentComplementaryResource'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
        
        
        /**
         * This is the function that list all the complementary document resources for a document
         */
        public function actionlistAllDocumentComplementaryResources(){
            
            //$primary_document_id = $_REQUEST['primary_id'];
            $primary_document_id = $_REQUEST['primary_document_id'];
            
             //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='primary_document_id=:documentid'; 
                $criteria->params = array(':documentid'=>$primary_document_id);
                $doc= DocumentResource::model()->findAll($criteria);
           
                if($doc===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($doc);
                       
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves a single document resource
         */
        public function actionRetrieveThisDocumentComplementaryResource(){
            
             //$primary_document_id = $_REQUEST['primary_id'];
            $id = $_REQUEST['id'];
            
             //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id'; 
                $criteria->params = array(':id'=>$id);
                $doc= DocumentResource::model()->findAll($criteria);
           
                if($doc===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "complement" =>$doc
                          
                           
                           
                          
                       ));
                } 
            
        }

        
        
        /**
         * This is the function that list all the complementary document resources for the entire documents on the latform
         */
        public function actionlistPlatformDocumentComplementaryResources(){
            
            
             //spool all the private toolbox from this domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
              //  $criteria->condition='primary_document_id=:documentid'; 
               // $criteria->params = array(':documentid'=>$primary_document_id);
                $doc= DocumentResource::model()->findAll($criteria);
           
                if($doc===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($doc);
                       
                }
            
            
        }
        
        
        /**
         * This is the function that adds new commplementary document to a primary document
         */
        public function actionaddNewDocumentResourceToThisDocument(){
            $model = new DocumentResource;  
            
            //get the logged in user
            $user_id = Yii::app()->user->id;
            
            $model->domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->title = $_POST['title'];
            $model->input_type = strtolower($_POST['input_type']);
            $model->primary_document_id = $_POST['primary_document_id'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
           
            if(isset($_POST['keywords'])){
               $keywords = trim($_POST['keywords']);
           }else{
               $keywords = " ";
           }
            
            $zip_error_counter = 0;
           if($_FILES['filename']['name'] != ""){
                    if($this->isZipFileTypeAndSizeLegal($model->domain_id)){
                        
                        $filename = $_FILES['filename']['name'];
                        $size = $_FILES['filename']['size'];
                      
                    }else{
                         $zip_error_counter = $zip_error_counter + 1;
                        
                        }//end of the determine size and type statement
                }else{
                    $filename = null;
                    $size = 0;
                }//end of the if filename if statement
                
                  //Ensure that the files variables all validates
                if(($zip_error_counter ==0)){
                    
                       //determine if this task is squeezable
                    if($model->validate()){
                    
                            $zipped_file_details =  $this->moveTheDocumentZipFileToItsPathAndReturnTheZipFileName($model,$filename,$size);
                            $model->filename = $zipped_file_details[0];
                            $model->filesize = $zipped_file_details[1];
                            $model->file_fullname = $zipped_file_details[2];
                            
                            //confirm if the content of the full document file is the recommended format
                     // if($this->isTheContentOfTheFullDocumentFormatAcceptable($model->filename_with_extension,$model->resourcetype_id)){
                                 //save the file to the database
                      if($model->save()) {
                                $this->addKeywordsToThisComplementaryDocument($model->id,$keywords);                   
                                $msg = "'$model->title' document was created successfuly";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                                //delete all the moved files in the directory when validation error is encountered
                               $msg = "Document Format Error: The document format provided is not acceptable";
                               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                            }
                    
                                
                        /**    }else{
                                //delete all the moved files in the directory when validation error is encountered
                               $msg = 'Validaion Error: Check your file fields for correctness';
                               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                        "file"=>$model->full_media_filename
                                        )
                                ); 
                                
                            }
                         * 
                         */
                             
                             
                           
                }else{
                    
                    //delete all the moved files in the directory when validation error is encountered
                       $msg = "Validation Error: '$model->title' document could not be validated";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                    
                }
           
                     
              }elseif($zip_error_counter > 0){
                    //get the platform settings for this property
                    $max_zip_size = $this->getTheMaxZipSizeForThisDomain($model->domain_id);
                    $zip_types = $this->retrieveZippedFileMimeTypes();
                    $zip_types = json_encode($zip_types);
                    $msg = "Please check your zipped file type or size as the maximum allowable file size is '$max_zip_size'kb and types must be any of these: ' $zip_types'kb ";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() != 0,
                             "msg" => $msg)
                       );
                }
            
           
            
            
        }
        
        
        /**
         * This is the function that adds keywords to complementary document
         */
        public function addKeywordsToThisComplementaryDocument($id,$keywords){
            
            $all_keywords = explode("+",$keywords);
                
            $counter = 0;
            foreach($all_keywords as $keyword){
                    //write this keyword to this document resource
              if(!empty($keyword)){
                 if($this->isThisKeywordSuccessfullyWrittenToThisDocumentResource(trim($keyword),$id)){
                            $counter = $counter + 1;
                        }
                    }
                    
                }
                if($counter >0){
                    return true;
                    //return $counter;
                }else{
                    return false;
                   // return $counter;
                }
            
            
        }
	
        
        /**
         * This is the function that confirms if the addition of keywords to a document resources is auccessful
         */
        public function isThisKeywordSuccessfullyWrittenToThisDocumentResource($keyword,$id){
            
            if(!empty($keyword)){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->insert('document_resource_keyword',
                                  array(
                                    'document_resource_id'=>$id,
                                    'keyword'=>$keyword,
                                    'create_time'=>new CDbExpression('NOW()'),
                                   'create_user_id'=>Yii::app()->user->id,
                                  
                            )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
            
        }
        
        
        
        /**
         * This is the function that edits a complementary document content
         */
        public function actioneditThisDocumentResourceInThisDocument(){
            
            $_id = $_POST['id'];
            $model=  DocumentResource::model()->findByPk($_id);
            
            //get the logged in user
            $user_id = Yii::app()->user->id;
            
            $model->domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->title = $_POST['title'];
            $model->input_type = strtolower($_POST['input_type']);
            $model->primary_document_id = $_POST['primary_document_id'];
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
           
            $zip_error_counter = 0;
           if($_FILES['filename']['name'] != ""){
                    if($this->isZipFileTypeAndSizeLegal($model->domain_id)){
                        
                        $filename = $_FILES['filename']['name'];
                        $size = $_FILES['filename']['size'];
                      
                    }else{
                         $zip_error_counter = $zip_error_counter + 1;
                        
                        }//end of the determine size and type statement
                }else{
                    $filename = null;
                    $size = 0;
                }//end of the if filename if statement
                
                  //Ensure that the files variables all validates
                if(($zip_error_counter ==0)){
                    
                       //determine if this task is squeezable
                    if($model->validate()){
                    
                            $zipped_file_details =  $this->moveTheDocumentZipFileToItsPathAndReturnTheZipFileName($model,$filename,$size);
                            $model->filename = $zipped_file_details[0];
                            $model->filesize = $zipped_file_details[1];
                            $model->file_fullname = $zipped_file_details[2];
                            
                            //confirm if the content of the full document file is the recommended format
                     // if($this->isTheContentOfTheFullDocumentFormatAcceptable($model->filename_with_extension,$model->resourcetype_id)){
                                 //save the file to the database
                      if($model->save()) {
                        
                                $msg = "'$model->title' document was created successfuly";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                                //delete all the moved files in the directory when validation error is encountered
                               $msg = "Document Format Error: The document format provided os not acceptable";
                               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                            }
                    
                                
                        /**    }else{
                                //delete all the moved files in the directory when validation error is encountered
                               $msg = 'Validaion Error: Check your file fields for correctness';
                               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                        "file"=>$model->full_media_filename
                                        )
                                ); 
                                
                            }
                         * 
                         */
                             
                             
                           
                }else{
                    
                    //delete all the moved files in the directory when validation error is encountered
                       $msg = "Validation Error: '$model->title' document was created successfully";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                    
                }
           
                     
              }elseif($zip_error_counter > 0){
                    //get the platform settings for this property
                    $max_zip_size = $this->getTheMaxZipSizeForThisDomain($domainid);
                    $zip_types = $this->retrieveZippedFileMimeTypes();
                    $zip_types = json_encode($zip_types);
                    $msg = "Please check your zipped file type or size as the maximum allowable file size is '$max_zip_size'kb and types must be any of these: ' $zip_types'kb ";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() != 0,
                             "msg" => $msg)
                       );
                }
        }
        
        
       
        
        /**
         * This is the function that moves a demo zipped file to its path
         */
        public function moveTheDocumentZipFileToItsPathAndReturnTheZipFileName($model,$zipFileName,$zipFileSize){
            
             if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        //$zipFileName = $_FILES['zipped_filename']['name'];    
                        $zipFileType = $_FILES['filename']['type'];
                        //$zipFileSize = $_FILES['html5_demo_file']['size'];
                  
                    }
                    
                   if($zipFileName !== null) {
                       if($model->id === null){
                            $zipped_FileName= time().'_'.$zipFileName;
                            $name = explode(".",$zipped_FileName);
                            //$model->zipped_filename = $name[0];
                             //$name[1] = $zipFileSize;
                            
                             if($zipFileName !== null) {// validate to save file
                                        $zip_filePath = Yii::app()->params['zipHtml'].$zipped_FileName;
                                        $zipHtml = Yii::app()->params['zipHtml'];
                                         //$newDir = $zipHtml.
                                         $filenoext = basename ($zipped_FileName, '.zip'); 
                                        $filenoext = basename ($filenoext, '.ZIP');  
                                        $myDir = $zipHtml . $filenoext; 
                                        // $myDir = time().'_'.$myDir_1;
                                        mkdir($myDir, 0777);
                                        if(move_uploaded_file($tmpName,  $zip_filePath)){
                                        //extract the zip file to a folder
                                            $zip = new ZipArchive();
                                            $open = $zip->open($zip_filePath); // open the zip file to extract
                                            if ($open === true) {
                                                 $zip->extractTo($myDir); // place in the directory with same name
                                                 //get the unzipped directory size
                                                 $name[1] = $this->getThisDirectorySize($myDir);
                                                 $name[2] =$this->getTheNameOfTheFullDocumentFileInThisDirectory($myDir);
                                                 $zip->close();
                                                    unlink($zip_filePath);
                                                
                                             }
                                            
                                        }
                      
                                 //return $name[0];
                                 return $name;       
                      
                             }else {
                                return null;
                            }
                       }else{
                         if($this->noNewDemoZippedFileProvided($model->id,$zipFileName)){
                               $name[0]= $zipFileName;
                               $name[1] = $zipFileSize;
                               $name[2] = $model->file_fullname;
                                // $name = explode(".",$zipped_FileName);
                                return $name;
                           }else{
                            if($zipFileName !== null){
                                 if($this->removeThisExistingZippedFolder($model->id)){
                              
                                    $zipped_FileName= time().'_'.$zipFileName;
                                    $name = explode(".",$zipped_FileName);
                                    $name[1] = $zipFileSize;
                                //move the zipped file
                                $zip_filePath = Yii::app()->params['zipHtml'].$zipped_FileName;
                                        $zipHtml = Yii::app()->params['zipHtml'];
                                         //$newDir = $zipHtml.
                                         $filenoext = basename ($zipped_FileName, '.zip'); 
                                        $filenoext = basename ($filenoext, '.ZIP');  
                                        $myDir = $zipHtml . $filenoext; 
                                        // $myDir = time().'_'.$myDir_1;
                                        mkdir($myDir, 0777);
                                        
                                      if(move_uploaded_file($tmpName,  $zip_filePath)){
                                        //extract the zip file to a folder
                                            $zip = new ZipArchive();
                                            $open = $zip->open($zip_filePath); // open the zip file to extract
                                            if ($open === true) {
                                                 $zip->extractTo($myDir); // place in the directory with same name
                                                 //get the unzipped directory size
                                                 $name[1] = $this->getThisDirectorySize($myDir);
                                                 $name[2] =$this->getTheNameOfTheFullDocumentFileInThisDirectory($myDir);
                                                 $zip->close();
                                                    unlink($zip_filePath);
                                                
                                             }
                                            
                                        }
                                      }
                                      return $name;
                                }
                              
                                       
                                return null ;
                               // }  
                               
                           }
                           
                       }
                       
                     
                    }else{
                        return null;
                    }
            
        }
        
        
         /**
         * This is the function to get a directory size
         */
        public function getThisDirectorySize($directory){
            
            $size = 0; 
            foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory)) as $file){ 
                     $size+=$file->getSize(); 
            } 
            return $size; 
        } 
        
        
          /**
         * This is the function that will retrieve the media filename from the directory
         */
        public function getTheNameOfTheFullDocumentFileInThisDirectory($dir){
            
            if (is_dir($dir)){
                
                if ($handle = opendir($dir)) {

                    while (false !== ($entry = readdir($handle))) {

                        if ($entry != "." && $entry != "..") {

                            $file = $entry;
                        }
                     }

                 closedir($handle);
                }
            } 
            return $file;
        }
        
        
        
         /**
         * This is the function that deletes the existing zip file before a new one is created
         */
        public function removeThisExistingZippedFolder($id){
            
            if($this->isZippedFileANullValue($id) === false){
                 //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zipped= DocumentResource::model()->find($criteria);
                
                $filePath = "c:\\xampp\\htdocs\\docudome_client\\fullfiles\\";
                $directoryPath = $filePath.$zipped['filename'];
                if($this->deleteDir($directoryPath)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return true;
            }
           
                
        }
        
        
         /**
         * Recursively delete a directory and files in a directory tree
         */
       public static function deleteDir($dirPath) {
           if (! is_dir($dirPath)) {
                throw new InvalidArgumentException("$dirPath must be a directory");
           }
           if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
                $dirPath .= '/';
            }
            $files = glob($dirPath . '*', GLOB_MARK);
            foreach ($files as $file) {
            if (is_dir($file)) {
                self::deleteDir($file);
            } else {
                unlink($file);
         }
            }
            //rmdir($dirPath);
            
            if(rmdir($dirPath)){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function to ascertain if a new zipped was provided or not
         */
        public function noNewDemoZippedFileProvided($id,$zipped_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, file_fullname';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zipped= DocumentResource::model()->find($criteria);
                
                if($zipped['filename']==$zipped_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
         /**
         * This is the function that determines if a handholding file value is null
         */
        public function isZippedFileANullValue($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zip= DocumentResource::model()->find($criteria);
                
                if($zip['filename'] === null){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        
        
        
        /**
         * This is the function that determines the type and size of th zip file
         */
        public function isZipFileTypeAndSizeLegal($domainid){
           
         $ziptypes = []; 
            if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        $zipFileName = $_FILES['filename']['name'];    
                        $zipFileType = $_FILES['filename']['type'];
                        $zipFileSize = $_FILES['filename']['size'];
                  
            }
            //obtain the maximum demo sizes for this domain
           if($this->isSpecialMaxZipSizeProvided($domainid)){
               $size = $this->determineTheSpecialZipMaxSizeForThisDomain($domainid);
           }else{
               $size = $this->retrieveTheMaximumZippedfileSize();
           }
       
            $ziptypes = $this->retrieveZippedFileMimeTypes();
            
            //$size = 1024 * 1024 * 10;
           
          // if(($zipFileType === 'application/zip'|| $zipFileType === 'application/x-zip-compressed' || $zipFileType === 'multipart/x-zip' || $zipFileType === 'application/x-compressed') && $zipFileSize <= $size){
        if(in_array($zipFileType,$ziptypes) && $zipFileSize <= $size){ 
                return true;
            }else{
                return false;
            }
       
        }
        
        
         /**
         * This is the function that determines if a special demo or file size is provided
         */
        public function isSpecialMaxZipSizeProvided($domainid){
            
              //determine if the special max zip size is set
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_max_zip = DomainPolicy::model()->find($criteria); 
            
            if($special_max_zip['zip_file_size'] >0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         *This is the function that retrieves the value of the special max zip file
         */
        public function determineTheSpecialZipMaxSizeForThisDomain($domainid){
            
             //retreive the set domain special max video
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_max_zip = DomainPolicy::model()->find($criteria); 
            
            return $special_max_zip['zip_file_size'];
            
        }
        
        
         /**
         * This is the function that determines size of the zip file
         * 
         */
        public function retrieveTheMaximumZippedfileSize(){
            
            //retreive the platform set zip file size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $zip = PlatformSettings::model()->find($criteria); 
            
            return $zip['zip_file_size'];
            
           
            
        }
        
        
       
        
         /**
         * This is the function that retrieves all zip mime types
         */
        public function retrieveZippedFileMimeTypes(){
            
            //retrieve the zip mime types
            $zip_mimetype = [];
            $zip_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $zip_mime = PlatformSettings::model()->find($criteria); 
            
            $zip_mimetype = explode(',',$zip_mime['zip_file_type']);
            foreach($zip_mimetype as $zip){
                $zip_types[] =$zip; 
                
            }
            
            return $zip_types;
        }
        
        
        
         /**
         * This is the function that gets the maximum zip size permitted to a domain
         */
        public function getTheMaxZipSizeForThisDomain($domainid){
            
            if($this->isSpecialMaxZipSizeProvided($domainid)){
               $size = $this->determineTheSpecialZipMaxSizeForThisDomain($domainid);
           }else{
               $size = $this->retrieveTheMaximumDemoSize();
           }
           
           return $size;
        }
        
        
      /**
         * This is the function that deletes a keyword from a document resource
         */
        public function actiondeleteonedocumentresource(){
            
             //delete a resourcegroup from subgroup
            $id = $_REQUEST['id'];
            $title = $_REQUEST['title'];
            $primary_document_id = $_REQUEST['primary_document_id'];
            
            //get the name of the primary document
            
            $primary_document = $this->getTheNameOfThePrimaryDocument($primary_document_id);         
                
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('document_resource', 'id=:id', array(':id'=>$id));
            
           if($result>0){
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"The '$title' document resource had successfully been removed from the '$primary_document' document",
                       ));
           }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Could not remove the '$title' document resource from the '$primary_document' document",
                       ));
           }
            
            
        }
        
      
        /**
         * This is the function that retrieves the name of the primary document
         */
        public function getTheNameOfThePrimaryDocument($id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $doc= Resources::model()->find($criteria);
                
                return $doc['name'];
            
        }
        
        
         
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
}
