<?php

class EnlistmentVerificationCodeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','retrievetheactivedomainwebfeedbackforthiscode'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisEnlistmentVerificationCodes','updateenlistmentverificationcode',
                                    'retrieveenlistmentcodeinfo','retrievecodemessagecontent','retrievethemessageforthiscode','listAllEnlistmentVerificationCodes',
                                    'retrievecodeproductcontent','retrievetheproductforthiscode','submittingenlistmentcodefeedbackengagementdesign',
                                    'submittingenlistmentcodefeedbackdesign','settingengagementlimit','retrieconsumedenlistmentcodeinfo','listThisEnlistmentAllVerificationCodes',
                                    'retrievemessageconsumedenlistmentcodeinfo','listDomainAllEventEnlistmentVerificationCodes','enrollingthiseventdelegate',
                                    'updatethiseventdelegateinfo','unenrolaneventdelegate','retrieveeventparticipants','listAllEventParticipants',
                                    'retrievecodeeventcontent','retrievetheeventforthiscode','checkinadelegate','checkoutadelegate','retrievecodeidentitycontent',
                                    'listUserAllEventEnlistmentVerificationCodes','selfenrollingthiseventdelegate','updatethiseventselfenrolleddelegateinfo',
                                    'unenrolselfenrolledeventdelegate','listThisEnlistmentVerificationOffenceCodes','retrievetheactiveterminalfeedbackforthiscode',
                                    'activatefeedbackservicecode','activateengagementservicecode','activatefeedbackandengagementservicecode',
                                    'retrievetheactiveterminalfeedbackforthiscode','retrievetheactivesinglewebfeedbackforthiscode','retrievetheactivedomainwebfeedbackforthiscode'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
	/**
         * This is the function that list a particular enlistment verification code
         */
        public function actionlistThisEnlistmentVerificationCodes(){
            
             $enlistment_id= $_REQUEST['enlistment_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:enlistmentid and feedback_type=:type';
            $criteria->params = array(':enlistmentid'=>$enlistment_id,':type'=>"generic");
            $enlistments = EnlistmentVerificationCode::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        
        /**
         * This is the function that list a particular enlistment verification offence code
         */
        public function actionlistThisEnlistmentVerificationOffenceCodes(){
            
             $enlistment_id= $_REQUEST['enlistment_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:enlistmentid and feedback_type=:type';
            $criteria->params = array(':enlistmentid'=>$enlistment_id,':type'=>"offence");
            $enlistments = EnlistmentVerificationCode::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that updates the information of a verification code
         */
        public function actionupdateenlistmentverificationcode(){
            
            $_id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($_id);
            $model->enlistment_id = $_REQUEST['enlistment_id'];
            if($_REQUEST['code_type'] == "one_time"){
                $model->type = $_REQUEST['code_type'];
                $model->viewership =strtolower('same_viewer');
            }else{
                $model->type = $_REQUEST['code_type'];
                $model->viewership = $_REQUEST['viewership'];
            }
           // $model->date_of_expiry = date("Y-m-d H:i:s",strtotime($_REQUEST['date_of_expiry']));
            if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                $model->is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
            }else{
                $model->is_paid_for_by_code_consumer=0;
            }
             if(isset($_REQUEST['is_post_consumption'])){
                $model->is_post_consumption = $_REQUEST['is_post_consumption'];
            }else{
                $model->is_post_consumption=0;
            }
            if(isset($_REQUEST['is_for_public'])){
                $model->is_for_public = $_REQUEST['is_for_public'];
                $model->enlistment_authorized_viewers_email = NULL;
            }else{
                $model->is_for_public=0;
                $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
            }
            if(isset($_REQUEST['verify_public_with_parameter'])){
                $model->verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
            }else{
                $model->verify_public_with_parameter=NULL;
            }
             if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_bvn_in_second_level_auth=0;
            }
             if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
            }else{
                $model->verify_receiver_with_nin_second_level_auth=0;
            }
             if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_pvc_in_second_level_auth=0;
            }
             if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
            }else{
                $model->verify_receiver_registered_mobile_number_in_second_level_auth=0;
            }
            if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_passport_number_in_second_level_auth=0;
            }
            if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_driving_license_in_second_level_auth=0;
            }
            if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
            }else{
                $model->verify_receiver_with_pension_pin_in_second_level_auth=0;
            }
             if(isset($_REQUEST['is_verification_required'])){
                $model->is_verification_required = 0;
            }else{
                $model->is_verification_required=1;
            }
             if(isset($_REQUEST['feedback_display_medium'])){
                $model->feedback_display_medium = $_REQUEST['feedback_display_medium'];
               $model->feedback_display_medium_status = "inactive";
                
            }else{
                $model->feedback_display_medium = "all";
                $model->feedback_display_medium_status = "inactive";
            }
            
            if($_REQUEST['day_to_expiry'] == "" || $_REQUEST['day_to_expiry'] == NULL){
                $day_to_expiry = $model->getTheCurrentExpiryDate($_id);
            }else{
               $day_to_expiry =  $model->getTheExpirationDateOfThisVerificationCode($_REQUEST['day_to_expiry']);
            }
          if($this->isThisEnlistmentCodeActive($_REQUEST['date_of_expiry'])){
              $model->date_of_expiry = $day_to_expiry;
              if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Enlistment Verification code is updated succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
            }
              
          }else{
               header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"This code had expired and therefore it cannot be updated. You may however wish to generate a new verification code for this enlistment"
                        ));
              
          }
            
            
        }
        
        
        
         /**
         * This is the function that retrieves information about user enlistments verification code
         */
        public function actionretrieveenlistmentcodeinfo(){
            $enlistment_id = $_REQUEST['enlistment_id'];
            $code_id = $_REQUEST['id'];
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$enlistment_id);
            $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
            //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:listid';
            $criteria->params = array(':listid'=>$code_id);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
             //get the name of the unit/branch
            $unit = $this->getThisLocationUnitName($enlistment['unit_id']);
            
            if($enlistment_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "unit"=>$unit
                                    
                    
                            ));
                       
                         }
            
        }
        
        
           /**
         * This is the function that determines if an enlistment code is still valid
         */
        public function isThisEnlistmentCodeActive($date_of_expiry){
            $model = new EnlistmentVerificationCode;
            return $model->isThisEnlistmentCodeActive($date_of_expiry);
        }
        
        
           /**
         * This is the function that determines if an enlistment code is still valid
         */
        public function thistimediff($date_of_expiry){
            $model = new EnlistmentVerificationCode;
            return $model->thistimediff($date_of_expiry);
        }
        
        
        /**
         * This is the function that retrieves the content of a code
         */
        public function actionretrievecodemessagecontent(){
           $model = new EnlistmentVerificationCode;
           $user_id = Yii::app()->user->id;
            
            $code = $_REQUEST['code'];
            $message_type = $_REQUEST['message_type'];
           
           if($model->isCodeExist($code)){
               
               if($model->isCodeForThisMessageType($code,$message_type)){
                    //check if code had expired
               if($model->isCodeExpired($code)==false){
                   if($model->isThisCodeStillValidForConsumption($code,$user_id)){
                       //get the authentication attributes for this message
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>"$code");
                    $verification = EnlistmentVerificationCode::model()->find($criteria);
                    
                     if($verification===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code"=>$verification
                                    
                    
                            ));
                       
                         }
                       
                   }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Code Validity: This code is no longer valid for consumption. Please request for a new one from the other party and try again"
                        ));
                       
                   }
                
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Expired Code: This code had expired. Please request for a new one from the other party and try again"
                        ));
               }
                   
                   
                   
               }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Wrong application of Code: This code is not enlisted against the '$message_type' message type. Please ask the other party for the message type this code was meant for"
                        ));
                   
               }
              
               
           }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This code does not exist. Please check the code and try again"
                        ));
               
           }
            
        }
        
        
        /**
         * This is the function that authenticates a code user and retrieves the code message
         */
        public function actionretrievethemessageforthiscode(){
            
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            
            $code_id = $_REQUEST['code_id'];
            $code = $_REQUEST['code'];
            $is_bvn = $_REQUEST['is_bvn'];
            $is_nin = $_REQUEST['is_nin'];
            $is_pvc = $_REQUEST['is_pvc'];
            $is_passport = $_REQUEST['is_passport'];
            $is_license = $_REQUEST['is_license'];
            $is_mobile = $_REQUEST['is_mobile'];
            $is_pension = $_REQUEST['is_pension'];
            $is_noauth = $_REQUEST['is_noauth'];
            
            if($is_noauth !=1){
                
                if($is_bvn ==1){
                $userbvn = $_REQUEST['userbvn'];
            }else{
              $userbvn=null;  
            }
            if($is_nin ==1){
                $usernin = $_REQUEST['usernin'];
            }else{
               $usernin = null; 
            }
            if($is_pvc ==1){
                $userpvc = $_REQUEST['userpvc'];
            }else{
               $userpvc = null; 
            }
             if($is_passport ==1){
                $userpassport = $_REQUEST['userpassport'];
            }else{
                $userpassport=null;
            }
             if($is_license ==1){
                $userlicense = $_REQUEST['userlicense'];
            }else{
                $userlicense = null;
            }
            if($is_mobile ==1){
                $usermobile = $_REQUEST['usermobile'];
            }else{
                $usermobile = null;
            }
            if($is_pension ==1){
                $userpension = $_REQUEST['userpension'];
            }else{
                $userpension =null;
            }
            if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                if($model->isTheCodeUserAuthenticationValid($user_id,$code_id,$is_bvn,$is_nin,$is_pvc,$is_passport,$is_license,$is_mobile,$is_pension,$userbvn,$usernin,$userpvc,$userpassport,$userlicense,$usermobile,$userpension)){
                //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                     $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                    if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"One or more of the authentication numbers you provided is not correct"
                        ));
                }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise"
                        ));
                
            }
            
                
                
                
            }else{
                 if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                          //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                     if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
                     
                 }else{
                      header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise"
                        ));
                     
                 }
             
            }
            
            
            
        }
        
        
        /**
         * This is the function that determines if a user is legible to consume a code
         */
        public function isThisUserLegibleToConsumeThisCode($user_id,$code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisUserLegibleToConsumeThisCode($user_id,$code_id);
        }
        
        
        /**
         * This is the function that records a code comsumption activity
         */
        public function recordThisCodeConsumptionActivity($user_id,$code_id){
            $model = new VerificationCodeConsumedByUser;
            return $model->recordThisCodeConsumptionActivity($user_id,$code_id);
        }
        
        
        /**
         * This is the function that list a all enlistment verification code
         */
        public function actionlistAllEnlistmentVerificationCodes(){
                                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='enlistment_id=:enlistmentid';
            //$criteria->params = array(':enlistmentid'=>$enlistment_id);
            $enlistments = EnlistmentVerificationCode::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that retrieves the content of a product code
         */
        public function actionretrievecodeproductcontent(){
           $model = new EnlistmentVerificationCode;
           $user_id = Yii::app()->user->id;
            
            $code = $_REQUEST['code'];
            $item_type = $_REQUEST['item_type'];
           
           if($model->isCodeExist($code)){
               
               if($model->isCodeForThisMessageType($code,$item_type)){
                    //check if code had expired
               if($model->isCodeExpired($code)==false){
                   if($model->isThisCodeStillValidForConsumption($code,$user_id)){
                       //get the authentication attributes for this message
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>"$code");
                    $verification = EnlistmentVerificationCode::model()->find($criteria);
                    
                     if($verification===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code"=>$verification
                                    
                    
                            ));
                       
                         }
                       
                   }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Code Validity: This code is no longer valid for consumption. Please request for a new one from the other party and try again"
                        ));
                       
                   }
                
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Expired Code: This code had expired. Please request for a new one from the other party and try again"
                        ));
               }
                   
                   
                   
               }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Wrong application of Code: This code is not enlisted against the '$item_type' message type. Please ask the other party for the message type this code was meant for"
                        ));
                   
               }
              
               
           }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This code does not exist. Please check the code and try again"
                        ));
               
           }
            
        }
        
        
        
         /**
         * This is the function that authenticates a code user and retrieves the code message
         */
        public function actionretrievetheproductforthiscode(){
            
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            
            $code_id = $_REQUEST['code_id'];
            $code = $_REQUEST['code'];
            $is_bvn = $_REQUEST['is_bvn'];
            $is_nin = $_REQUEST['is_nin'];
            $is_pvc = $_REQUEST['is_pvc'];
            $is_passport = $_REQUEST['is_passport'];
            $is_license = $_REQUEST['is_license'];
            $is_mobile = $_REQUEST['is_mobile'];
            $is_pension = $_REQUEST['is_pension'];
            $is_noauth = $_REQUEST['is_noauth'];
            
            if($is_noauth !=1){
                
                if($is_bvn ==1){
                $userbvn = $_REQUEST['userbvn'];
            }else{
              $userbvn=null;  
            }
            if($is_nin ==1){
                $usernin = $_REQUEST['usernin'];
            }else{
               $usernin = null; 
            }
            if($is_pvc ==1){
                $userpvc = $_REQUEST['userpvc'];
            }else{
               $userpvc = null; 
            }
             if($is_passport ==1){
                $userpassport = $_REQUEST['userpassport'];
            }else{
                $userpassport=null;
            }
             if($is_license ==1){
                $userlicense = $_REQUEST['userlicense'];
            }else{
                $userlicense = null;
            }
            if($is_mobile ==1){
                $usermobile = $_REQUEST['usermobile'];
            }else{
                $usermobile = null;
            }
            if($is_pension ==1){
                $userpension = $_REQUEST['userpension'];
            }else{
                $userpension =null;
            }
            if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                if($model->isTheCodeUserAuthenticationValid($user_id,$code_id,$is_bvn,$is_nin,$is_pvc,$is_passport,$is_license,$is_mobile,$is_pension,$userbvn,$usernin,$userpvc,$userpassport,$userlicense,$usermobile,$userpension)){
                //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                     $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                    
                    //get the applicable feedback template
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid and status=:status';
                    $criteria->params = array(':codeid'=>$code_id,':status'=>"active");
                    $feedback = FeedbackTemplate::model()->find($criteria); 
                    
                    if($model->isThisUserPermittedToCheckinDelegatesInThisEvent($user_id,$code['enlistment_id'])){
                        $delegate_check_in = 1;
                    }else{
                        $delegate_check_in=0;
                    }
                    
                     if($model->isThisUserPermittedToCheckOutDelegatesInThisEvent($user_id,$code['enlistment_id'])){
                        $delegate_check_out = 1;
                    }else{
                        $delegate_check_out=0;
                    }
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                    if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback,
                                    "can_check_in"=>$delegate_check_in,
                                    "can_check_out"=>$delegate_check_out
                                    
                    
                            ));
                       
                         }
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"One or more of the authentication numbers you provided is not correct"
                        ));
                }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise"
                        ));
                
            }
            
                
                
                
            }else{
                 if($model->isThisUserLegibleToConsumeThisCode($user_id,$code_id)){
                          //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                    
                     //get the applicable feedback template
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid and status=:status';
                    $criteria->params = array(':codeid'=>$code_id,':status'=>"active");
                    $feedback = FeedbackTemplate::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisCodeConsumptionActivity($user_id,$code_id);
            
            
                     if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback
                                   
                                    
                    
                            ));
                       
                         }
                     
               }else{
                      header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"You are not legible to consume this code. Please contact the person that gave you the code if you strongly feel otherwise",
                            
                                ));
                     
                 }
              
            }
            
            
            
        }
        
        
        /**
         * This is the function that sets an engagement limit for a code
         */
        public function actionsettingengagementlimit(){
            
            $model = new EnlistmentVerificationCode;
            
            $code_id = $_REQUEST['code_id'];
            
            if(isset($_REQUEST['is_limitless'])){
                $maximum_engagement_required = NULL;
            }else{
                $maximum_engagement_required = $_REQUEST['maximum_engagement_required'];
            }
             if(isset($_REQUEST['is_multiple_engagement_schedules_allowed'])){
                 $is_multiple_engagement_schedules_allowed = $_REQUEST['is_multiple_engagement_schedules_allowed'];
             }else{
                 $is_multiple_engagement_schedules_allowed= 0;
             }
            
            if($model->isTheSettingOfThisEngagementASuccess($code_id,$maximum_engagement_required,$is_multiple_engagement_schedules_allowed)){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This engagement limit is successfully set for the code"
                        ));
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue while setting the engagement limit. Please try again or contact customer service for assistance"
                        ));
                
            }
        }
        
        
        /**
         * This is the function that retrieves information about consumed user enlistments verification code
         */
        public function actionretrieconsumedenlistmentcodeinfo(){
            //$enlistment_id = $_REQUEST['enlistment_id'];
            $code_id = $_REQUEST['id'];
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code_id);
            $consumed = VerificationCodeConsumedByUser::model()->find($criteria); 
            
            
             //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:listid';
            $criteria->params = array(':listid'=>$consumed['verification_code_id']);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code['enlistment_id']);
            $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
            //get the name of the unit/branch
           $unit = $this->getThisLocationUnitName($enlistment['unit_id']);
            
            if($consumed===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that gets the name of a unit
         */
        public function getThisLocationUnitName($unit_id){
            $model = new LocationUnit;
            return $model->getThisLocationUnitName($unit_id);
        } 
        
        
        
         /**
         * This is the function that retrieves information about consumed user enlistments verification code
         */
        public function actionretrievemessageconsumedenlistmentcodeinfo(){
            //$enlistment_id = $_REQUEST['enlistment_id'];
            $code_id = $_REQUEST['id'];
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code_id);
            $consumed = VerificationCodeConsumedByUser::model()->find($criteria); 
            
            
             //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:listid';
            $criteria->params = array(':listid'=>$consumed['verification_code_id']);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code['enlistment_id']);
            $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
           
            
            if($consumed===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that list all product enlistment codes
         */
        public function actionlistThisEnlistmentAllVerificationCodes(){
            
            $enlistment_id = $_REQUEST['enlistment_id'];
            
             //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:listid';
            $criteria->params = array(':listid'=>$enlistment_id);
            $codes = EnlistmentVerificationCode::model()->findAll($criteria); 
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "codes" =>$codes
                                                                        
                    
                            ));
                       
                         }
        }
        
        
        
         /**
         * This is the function that list all domain event enlistment codes
         */
        public function actionlistDomainAllEventEnlistmentVerificationCodes(){
            
          $user_id = Yii::app()->user->id;
          //get this user domain
          $domain_id = $this->getTheDomainIdOfThisUser($user_id);
          
            //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
             $criteria->condition='(generated_by=:userid and is_self_delegate_enrollment=:isself) and (category =:cat and is_delegate_enrolled=:isenrolled)';
            $criteria->params = array(':userid'=>$user_id,':cat'=>"event",':isenrolled'=>1,':isself'=>0);
            $codes = EnlistmentVerificationCode::model()->findAll($criteria); 
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$codes
                                                                        
                    
                            ));
                       
                         }
        }
        
         /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
        
        
        /**
         * This is the function that enrolls a delegate for an event
         */
        public function actionenrollingthiseventdelegate(){
            
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['enlistment_type'];
            $item_type = strtolower('event'); 
            if($_REQUEST['city'] == ""){
                    $model->city_id = NULL;
                }else{
                    $model->city_id = $_REQUEST['city'];
                }
                
            $model->delegate_name = $_REQUEST['delegate_name'];
            $model->delegate_job_title = $_REQUEST['delegate_job_title'];
            $model->delegate_staff_number = $_REQUEST['delegate_staff_number'];
            $model->delegate_id_card_number = $_REQUEST['delegate_id_card_number'];
            $model->category = strtolower('event'); 
            $model->generated_by = $user_id;
            $model->generator_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            
            
       if($this->isThisEventAvailableForDelegateEnrollment($_REQUEST['event_code'])){
           if($this->isPermittedToEnrollDelegatesForThisEvent($_REQUEST['event_code'],$user_id)){
              $model->enlistment_id = $this->getThisEventEnlistmentId($_REQUEST['event_code']);
             if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $model->is_paid_for_by_code_consumer = 0;
                $model->is_for_public = 0;
                $model->verify_public_with_parameter = NULL;
                $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $model->is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $model->is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $model->is_for_public = $_REQUEST['is_for_public'];
                    $model->verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $model->enlistment_authorized_viewers_email = NULL;
                    $model->is_verification_required = 0;
                }else{
                   $model->is_for_public = 0;
                    $model->verify_public_with_parameter = NULL;
                     $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                   // $day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }
            }
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['delegate_passport_photo']['name'] != ""){
                    if($model->isUserPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['delegate_passport_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['delegate_id_frontview_image']['name'] != ""){
                    if($model->isCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['delegate_id_frontview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['delegate_id_backview_image']['name'] != ""){
                    if($model->isCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['delegate_id_backview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
           if($icon_error_counter ==0){
                if($model->validate()){
                     $model->delegate_passport_photo = $model->moveTheUserPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->delegate_id_frontview_image = $model->moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->delegate_id_backview_image = $model->moveTheCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                if($location_invoice_id>0){
                    $model->verification_code = $model->generateThisEnlistmentVerificationCode($model->city_id,$model->enlistment_id,$nature,$domain_id,$user_id,$platform,$item_type,$model->type,$model->viewership,$day_to_expiry=0);
                     if($model->save()){
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the event delegate verification code: '$model->verification_code'. This code is the delegate's pass to the event. It is not transferable"
                        ));
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was probably a validation issue. Please check your input data and tr again"
                        ));
                    } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
                    
                    
                }else{
                     $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                    
                }
               
              
                    
                    
                    
                }else{
                     $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                    
                }
                
            
            
                  
                  
              }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"You do not have the privilege to enroll delegates for this event"
                        ));
                  
              }
                
             
                
                
            }else{
                
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This event is not available for delegate enrollment. It is possible the event had taken place or it does not exist. Please check with the event organizer(s)"
                        ));
                
            }
            
            
          
        }
        
        
        /**
         * This is the function that confirms if an event code exist and it is available for delegate enrollment
         */
        public function isThisEventAvailableForDelegateEnrollment($event_code){
            $model = new UserEnlistmentRequest;
            return $model->isThisEventAvailableForDelegateEnrollment($event_code);
        }
        
        
        /**
         * This is the function that confirms if a user is permitted to enroll delegates to an event
         */
        public function isPermittedToEnrollDelegatesForThisEvent($event_code,$user_id){
            $model = new UserEnlistmentRequest;
            return $model->isPermittedToEnrollDelegatesForThisEvent($event_code,$user_id);
        }
        
        
         /**
         * This is the function that retrieves the enlis id of an event
         */
        public function getThisEventEnlistmentId($event_code){
            $model = new UserEnlistmentRequest;
            return $model->getThisEventEnlistmentId($event_code);
        }
        
        
         /**
     * This is the function that confirms if a domain has a live transaction
     */  
     public function isDomainWithLiveTransaction($domain_id){
         $model = new DomainTransactions;
         return $model->isDomainWithLiveTransaction($domain_id);
     }
     
     
     /**
      * This is the function that adds a new domain transaction 
      */
     public function newDomainTransactionTreeAdded($domain_id){
         $model = new DomainTransactions;
         return $model->newDomainTransactionTreeAdded($domain_id);
     }
     
     /**
      * This is the function that returns a live domain transaction
      */
     public function getTheLiveDomainTransId($domain_id){
         $model = new DomainTransactions;
         return $model->getTheLiveDomainTransId($domain_id);
     }
     
        
   
           /**
         * This is the function that retrieves the pending invoice id of a user's location
         */
        public function getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id){
            $model = new Invoice;
            return $model->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
        }
        
        /**
         * This is the function that updates an event delegate info
         */
        public function actionupdatethiseventdelegateinfo(){
            
             $_id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['enlistment_type'];
            $item_type = strtolower('event'); 
            if($_REQUEST['city'] == ""){
                    $model->city_id = NULL;
                }else{
                    $model->city_id = $_REQUEST['city'];
                }
                
            $model->delegate_name = $_REQUEST['delegate_name'];
            $model->delegate_job_title = $_REQUEST['delegate_job_title'];
            $model->delegate_staff_number = $_REQUEST['delegate_staff_number'];
            $model->delegate_id_card_number = $_REQUEST['delegate_id_card_number'];
            $model->category = strtolower('event'); 
            $model->generated_by = $user_id;
            $model->generator_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            
            //get the event code of this event
            $event_code = $this->getThisEventCode($_REQUEST['event_id']);
            
            
       if($this->isThisEventAvailableForDelegateEnrollment($event_code)){
           if($this->isPermittedToEnrollDelegatesForThisEvent($event_code,$user_id)){
              $model->enlistment_id = $this->getThisEventEnlistmentId($event_code);
             if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $model->is_paid_for_by_code_consumer = 0;
                $model->is_for_public = 0;
                $model->verify_public_with_parameter = NULL;
                $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($event_code);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($event_code);
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $model->is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $model->is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $model->is_for_public = $_REQUEST['is_for_public'];
                    $model->verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $model->enlistment_authorized_viewers_email = NULL;
                    $model->is_verification_required = 0;
                }else{
                   $model->is_for_public = 0;
                    $model->verify_public_with_parameter = NULL;
                     $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($event_code);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    //$day_to_expiry = $_REQUEST['day_to_expiry'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($event_code);
                }
            }
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['delegate_passport_photo']['name'] != ""){
                    if($model->isUserPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['delegate_passport_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = $model->retrieveTheExistingDelegatePassportViewImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['delegate_id_frontview_image']['name'] != ""){
                    if($model->isCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['delegate_id_frontview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = $model->retrieveTheExistingDelegateFrontViewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['delegate_id_backview_image']['name'] != ""){
                    if($model->isCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['delegate_id_backview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = $model->retrieveTheExistingDelegateBackViewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
           if($icon_error_counter ==0){
                if($model->validate()){
                     $model->delegate_passport_photo = $model->moveTheUserPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->delegate_id_frontview_image = $model->moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->delegate_id_backview_image = $model->moveTheCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                if($location_invoice_id>0){
                    $model->verification_code = $_REQUEST['verification_code'];
                     if($model->save()){
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This event delegate information is updated successfully"
                        ));
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was probably a validation issue. Please check your input data and tr again"
                        ));
                    } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
                    
                    
                }else{
                     $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                    
                }
               
              
                    
                    
                    
                }else{
                     $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                    
                }
                
            
            
                  
                  
              }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"You do not have the privilege to enroll delegates for this event"
                        ));
                  
              }
                
             
                
                
            }else{
                
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This event is not available for delegate enrollment. It is possible the event had taken place or it does not exist. Please check with the event organizer(s)"
                        ));
                
            }
            
        }
        
        
        /**
         * This is the functiion that gets an event code given its is
         */
        public function getThisEventCode($event_id){
            $model= new UserEnlistmentRequest;
            return $model->getThisEventCode($event_id);
        }
        
        
        /**
         * This is the function that unenroll an event delegate
         */
        public function actionunenrolaneventdelegate(){
             $_id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($_id);
            
            if($model->isTheUnenrollmentOfDelegatesAllowedForEvent($_id)){
                $model->is_delegate_enrolled = 0;
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This event delegate had been unenrolled successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was probably a validation issue hence the attempt to unenrol this delegate from this event failed"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Delegate unenrollment is no longer allowed  for this event"
                        ));
            }
        }
        
        /**
         * This is the function that retrieves events participants
         */
        public function actionretrieveeventparticipants(){
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            
            if($model->isThisEventCodeValid($_REQUEST['event_code'])){
                if($model->isThisEventWithParticipants($_REQUEST['event_code'])){
                    if($model->isUserPermittedToEnrolDelegatesForThisEvent($_REQUEST['event_code'],$user_id)){
                         $enlistment_id = $this->getThisEventEnlistmentId($_REQUEST['event_code']);
                        
                         $criteria = new CDbCriteria();
                         $criteria->select = '*';
                         $criteria->condition='enlistment_id=:listid and is_delegate_checkedin=:checked';
                         $criteria->params = array(':listid'=>$enlistment_id,':checked'=>1);
                         $participants= EnlistmentVerificationCode::model()->findAll($criteria);
                        
                         if($participants===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                            }else {
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "participant" =>$participants,
                          
                            ));
                       
                         }
                        
                        
                    }
              
                }
                
            }
            
        }
        
        
        /**
         * This is the function that list all domain event participants
         
        public function actionlistAllEventParticipants(){
            
          $user_id = Yii::app()->user->id;
          //get this user domain
          $domain_id = $this->getTheDomainIdOfThisUser($user_id);
          
          $event_id = $this->getThisEventEnlistmentId($_REQUEST['event_code']);
          
                   
            //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:listid and (generator_domain_id =:domainid and is_delegate_checkedin=:checkedin)';
            $criteria->params = array(':listid'=>$event_id,':domainid'=>$domain_id,':checkedin'=>1);
            $codes = EnlistmentVerificationCode::model()->findAll($criteria); 
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "participant" =>$codes
                                                                        
                    
                            ));
                       
                         }
        }
        
         * 
         */
        
        
        /**
         * This is the function that retrieves events participants
         */
        public function actionlistAllEventParticipants(){
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            
             $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            if($model->isThisEventCodeValid($_REQUEST['event_code'])){
                if($model->isThisEventWithParticipants($_REQUEST['event_code'])){
                    if($model->isUserPermittedToEnrolDelegatesForThisEvent($_REQUEST['event_code'],$user_id)){
                         $enlistment_id = $this->getThisEventEnlistmentId($_REQUEST['event_code']);
                        
                          //retrieve verification code information
                         $criteria = new CDbCriteria();
                         $criteria->select = '*';
                         $criteria->condition='enlistment_id=:listid and (generator_domain_id =:domainid and is_delegate_checkedin=:checkedin)';
                         $criteria->params = array(':listid'=>$enlistment_id,':domainid'=>$domain_id,':checkedin'=>1);
                         $participants = EnlistmentVerificationCode::model()->findAll($criteria); 
                        
                         if($participants===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                            }else {
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "participant" =>$participants,
                          
                            ));
                       
                         }
                        
                        
                    }
              
                }
                
            }
            
        }
        
        
        
        
         /**
         * This is the function that retrieves the content of an event code
         */
        public function actionretrievecodeeventcontent(){
           $model = new EnlistmentVerificationCode;
           $user_id = Yii::app()->user->id;
            
            $event_code = $_REQUEST['event'];
            $delegate_code = $_REQUEST['delegate'];
            $item_type = $_REQUEST['item_type'];
           
           if($model->isThisEventCodeValid($event_code)){
               
            if($model->isThisDelegateCodeValid($delegate_code)){
             if($model->isDelegateCodeForThisEvent($event_code,$delegate_code,$item_type)){
                    //check if code had expired
               if($model->isDelegateCodeExpired($delegate_code)==false){
                   if($model->isThisDelegateCodeStillValidForConsumption($delegate_code,$user_id)){
                       //get the authentication attributes for this message
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>"$delegate_code");
                    $delegate = EnlistmentVerificationCode::model()->find($criteria);
                    
                    
                    //retriev the event details
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id and event_code=:event';
                    $criteria->params = array(':id'=>$delegate['enlistment_id'],':event'=>"$event_code");
                    $event = UserEnlistmentRequest::model()->find($criteria);
                    
                     if($event_code===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code"=>$delegate,
                                    "event"=>$event
                                    
                    
                            ));
                       
                         }
                       
                   }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Code Validity: This code is no longer valid for consumption. Please request for a new one from the other party and try again"
                        ));
                       
                   }
                
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Expired Code: This code had expired. Please request for a new one from the other party and try again"
                        ));
               }
                   
                   
                   
               }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Wrong application of Code: This code is not enlisted against the '$item_type' message type. Please ask the other party for the message type this code was meant for"
                        ));
                   
               }
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This delegate code does not exist. Please check the code and try again"
                        ));
                   
               }
               
               
              
               
           }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This event code does not exist. Please check the code and try again"
                        ));
               
           }
            
        }
        
        
        /**
         * This is the function that checks in a delegate
         */
        public function actioncheckinadelegate(){
            $user_id=Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            $code_id = $_REQUEST['code_id'];
            $model= EnlistmentVerificationCode::model()->findByPk($code_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code_id);
            $delegate = EnlistmentVerificationCode::model()->find($criteria);
            
            if($delegate['is_delegate_checkedin'] == 0){
                $model->is_delegate_checkedin = 1;
                $model->checkedin_time = new CDbExpression('NOW()');
                $model->checkedin_by=$user_id;
                $model->checkedin_domain_id=$domain_id;
                
                if($model->save()){
                    
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This delegate is successfully checked-in"
                        ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was a validation issue with this request. Kindly check your input data and try again"
                        ));
                }
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"This delegate had already been checked-in to this event"
                        ));
            }
        }
        
        
        
         /**
         * This is the function that checks in a delegate
         */
        public function actioncheckoutadelegate(){
            $user_id=Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            $code_id = $_REQUEST['code_id'];
            $model= EnlistmentVerificationCode::model()->findByPk($code_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code_id);
            $delegate = EnlistmentVerificationCode::model()->find($criteria);
            
            if($delegate['is_delegate_checkedout'] == 0){
                $model->is_delegate_checkedout = 1;
                $model->checkedout_time = new CDbExpression('NOW()');
                $model->checkedout_by=$user_id;
                $model->checkedout_domain_id=$domain_id;
                
                if($model->save()){
                    
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This delegate is successfully checked-out"
                        ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was a validation issue with this request. Kindly check your input data and try again"
                        ));
                }
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"This delegate had already been checked-out from this event"
                        ));
            }
        }
        
        
        /**
         * This is the function that retrieves the content of an identification code
         */
        public function actionretrievecodeidentitycontent(){
          $model = new EnlistmentVerificationCode;
           $user_id = Yii::app()->user->id;
            
            $code = $_REQUEST['code'];
            $item_type = $_REQUEST['item_type'];
           
           if($model->isCodeExist($code)){
               
               if($model->isCodeForThisMessageType($code,$item_type)){
                    //check if code had expired
               if($model->isCodeExpired($code)==false){
                   if($model->isThisCodeStillValidForConsumption($code,$user_id)){
                       //get the authentication attributes for this message
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>"$code");
                    $verification = EnlistmentVerificationCode::model()->find($criteria);
                    
                    //get the identity enlistment
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$verification['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria);
                    
                     if($verification===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code"=>$verification,
                                    "enlistment"=>$enlistment
                                    
                    
                            ));
                       
                         }
                       
                   }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Code Validity: This code is no longer valid for consumption. Please request for a new one from the other party and try again"
                        ));
                       
                   }
                
                   
               }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Expired Code: This code had expired. Please request for a new one from the other party and try again"
                        ));
               }
                   
                   
                   
               }else{
                   header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Wrong application of Code: This code is not enlisted against the '$item_type' message type. Please ask the other party for the message type this code was meant for"
                        ));
                   
               }
              
               
           }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>"Sorry: This code does not exist. Please check the code and try again"
                        ));
               
           }
            
        }
        
        
        /**
         * This is the function that allows for self enrolment as delegate to an event
         */
        public function actionlistUserAllEventEnlistmentVerificationCodes(){
           $user_id = Yii::app()->user->id;
          //get this user domain
          $domain_id = $this->getTheDomainIdOfThisUser($user_id);
          
          $target = [];
          
            //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(generated_by=:userid and is_self_delegate_enrollment=:isself) and (category =:cat and is_delegate_enrolled=:isenrolled)';
            $criteria->params = array(':userid'=>$user_id,':cat'=>"event",':isenrolled'=>1,':isself'=>1);
            $codes = EnlistmentVerificationCode::model()->findAll($criteria); 
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$codes
                                                                        
                    
                            ));
                       
                         }
        }
       
        
        
        
        /**
         * This is the function that self enrolls a delegate for an event
         */
        public function actionselfenrollingthiseventdelegate(){
            
            $model = new EnlistmentVerificationCode;
            
            $user_id = Yii::app()->user->id;
            //get the domain of the event organizers
          if($this->isThisEventAvailableForDelegateEnrollment($_REQUEST['event_code'])){
              $domain_id = $this->getTheDomainIdOfTheEventOrganizer($_REQUEST['event_code']);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisEventEnlisterDomainPendingLocationInvoice($_REQUEST['event_code'],$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['enlistment_type'];
            $item_type = strtolower('event'); 
            if($_REQUEST['city'] == ""){
                    $model->city_id = NULL;
                }else{
                    $model->city_id = $_REQUEST['city'];
                }
                
            $model->delegate_name = $_REQUEST['delegate_name'];
            $model->delegate_job_title = $_REQUEST['delegate_job_title'];
            $model->delegate_staff_number = $_REQUEST['delegate_staff_number'];
            $model->delegate_id_card_number = $_REQUEST['delegate_id_card_number'];
            $model->category = strtolower('event'); 
            $model->generated_by = $user_id;
            $model->generator_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->is_self_delegate_enrollment = 1;
            
        
           if($this->isSelfServiceEnrollmentSupportedForThisEvent($_REQUEST['event_code'])){
             $model->enlistment_id = $this->getThisEventEnlistmentId($_REQUEST['event_code']);
             if($model->isThisUserAlreadySelfEnrolledToThisEvent($user_id,$model->enlistment_id)==false){
                 if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $model->is_paid_for_by_code_consumer = 0;
                $model->is_for_public = 0;
                $model->verify_public_with_parameter = NULL;
                $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                     $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $model->is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $model->is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $model->is_for_public = $_REQUEST['is_for_public'];
                    $model->verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $model->enlistment_authorized_viewers_email = NULL;
                    $model->is_verification_required = 0;
                }else{
                   $model->is_for_public = 0;
                    $model->verify_public_with_parameter = NULL;
                     $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEvent($_REQUEST['event_code']);
                }
            }
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['delegate_passport_photo']['name'] != ""){
                    if($model->isUserPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['delegate_passport_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['delegate_id_frontview_image']['name'] != ""){
                    if($model->isCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['delegate_id_frontview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['delegate_id_backview_image']['name'] != ""){
                    if($model->isCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['delegate_id_backview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
           if($icon_error_counter ==0){
                if($model->validate()){
                     $model->delegate_passport_photo = $model->moveTheUserPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->delegate_id_frontview_image = $model->moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->delegate_id_backview_image = $model->moveTheCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                if($location_invoice_id>0){
                    $model->verification_code = $model->generateThisEnlistmentVerificationCode($model->city_id,$model->enlistment_id,$nature,$domain_id,$user_id,$platform,$item_type,$model->type,$model->viewership,$dat_to_expiry=0);
                     if($model->save()){
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the event delegate verification code: '$model->verification_code'. This code is the delegate's pass to the event. It is not transferable"
                        ));
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was probably a validation issue. Please check your input data and tr again"
                        ));
                    } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
                    
                    
                }else{
                     $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                    
                }
               
              
                    
                    
                    
                }else{
                     $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                    
                }
                 
                 
             }else{
                  header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"You are already a delegate to this event and cannot enroll again"
                        ));
                            
             }
             
         
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry!, Self delegate enrolment to this event is not permitted"
                        ));
                            
                
                
            }
           
           
       }else{
          
            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This event is currently not available for delegate enrollment. It is possible the event had taken place or it does not exist. Please check with the event organizer(s)"
                        ));                 
           
       }     
       
            
            
          
        }
        
        
        
        
        
        /**
         * This is the function that updates self enrollment information of  a delegate for an event
         */
        public function actionupdatethiseventselfenrolleddelegateinfo(){
            
             $_id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            //get the domain of the event organizers
          if($this->isThisEventAvailableForDelegateEnrollmentGivenEventId($_REQUEST['event_id'])){
              $domain_id = $this->getTheDomainIdOfTheEventOrganizerGivenEventId($_REQUEST['event_id']);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisEventEnlisterDomainPendingLocationInvoiceGivenEventId($_REQUEST['event_id'],$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['enlistment_type'];
            $item_type = strtolower('event'); 
            if($_REQUEST['city'] == ""){
                    $model->city_id = NULL;
                }else{
                    $model->city_id = $_REQUEST['city'];
                }
                
            $model->delegate_name = $_REQUEST['delegate_name'];
            $model->delegate_job_title = $_REQUEST['delegate_job_title'];
            $model->delegate_staff_number = $_REQUEST['delegate_staff_number'];
            $model->delegate_id_card_number = $_REQUEST['delegate_id_card_number'];
            $model->category = strtolower('event'); 
            $model->generated_by = $user_id;
            $model->generator_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->is_self_delegate_enrollment = 1;
            
        
           if($this->isSelfServiceEnrollmentSupportedForThisEventGivenEventId($_REQUEST['event_id'])){
             $model->enlistment_id = $_REQUEST['event_id'];
                if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $model->is_paid_for_by_code_consumer = 0;
                $model->is_for_public = 0;
                $model->verify_public_with_parameter = NULL;
                $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                     $model->date_of_expiry = $this->getTheExpirationDateOfThisEventGivenEventId($_REQUEST['event_id']);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEventGivenEventId($_REQUEST['event_id']);
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $model->is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $model->is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $model->is_for_public = $_REQUEST['is_for_public'];
                    $model->verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $model->enlistment_authorized_viewers_email = NULL;
                    $model->is_verification_required = 0;
                }else{
                   $model->is_for_public = 0;
                    $model->verify_public_with_parameter = NULL;
                     $model->enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $model->is_verification_required = 0;
                    }else{
                        $model->is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $model->verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $model->verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $model->verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $model->verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $model->verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $model->verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $model->verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['type'] == "one_time"){
                    $model->type = "one_time";
                    //$viewership = "same_viewer";
                    $model->viewership = $_REQUEST['viewership'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEventGivenEventId($_REQUEST['event_id']);
                }else{
                     $model->type = $_REQUEST['type'];
                    $model->viewership = $_REQUEST['viewership'];
                    $model->date_of_expiry = $this->getTheExpirationDateOfThisEventGivenEventId($_REQUEST['event_id']);
                }
            }
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['delegate_passport_photo']['name'] != ""){
                    if($model->isUserPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['delegate_passport_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = $model->retrieveTheExistingDelegatePassportViewImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['delegate_id_frontview_image']['name'] != ""){
                    if($model->isCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['delegate_id_frontview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = $model->retrieveTheExistingDelegateFrontViewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['delegate_id_backview_image']['name'] != ""){
                    if($model->isCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['delegate_id_backview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = $model->retrieveTheExistingDelegateBackViewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
           if($icon_error_counter ==0){
                if($model->validate()){
                     $model->delegate_passport_photo = $model->moveTheUserPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->delegate_id_frontview_image = $model->moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->delegate_id_backview_image = $model->moveTheCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                if($location_invoice_id>0){
                    $model->verification_code = $_REQUEST['verification_code'];
                     if($model->save()){
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"The event delegate information is updated successfully."
                        ));
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was probably a validation issue. Please check your input data and tr again"
                        ));
                    } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
                    
                    
                }else{
                     $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                    
                }
               
              
                    
                    
                    
                }else{
                     $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                    
                }
                 
          
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry!, Self delegate enrolment to this event is not permitted"
                        ));
                            
                
                
            }
           
           
       }else{
          
            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This event is currently not available for delegate enrollment. It is possible the event had taken place or it does not exist. Please check with the event organizer(s)"
                        ));                 
           
       }     
       
            
            
          
        }
        
        
        /**
         * This is the function that confirms if self delegate wnrolment is allowed on an event
         */
        public function isSelfServiceEnrollmentSupportedForThisEvent($event_code){
            $model = new UserEnlistmentRequest;
            return $model->isSelfServiceEnrollmentSupportedForThisEvent($event_code);
        }
        
        
         /**
         * This is the function that confirms if self delegate wnrolment is allowed on an event
         */
        public function isSelfServiceEnrollmentSupportedForThisEventGivenEventId($event_id){
            $model = new UserEnlistmentRequest;
            return $model->isSelfServiceEnrollmentSupportedForThisEventGivenEventId($event_id);
        }
        
        
        /**
         * This is the function that gets the event's enlister current invoice is
         */
        public function getThisEventEnlisterDomainPendingLocationInvoice($event_code,$domain_id,$domain_trans_id){
            $model = new Invoice;
            return $model->getThisEventEnlisterDomainPendingLocationInvoice($event_code,$domain_id,$domain_trans_id);
        }
        
        
         /**
         * This is the function that gets the event's enlister current invoice is
         */
        public function getThisEventEnlisterDomainPendingLocationInvoiceGivenEventId($event_id,$domain_id,$domain_trans_id){
            $model = new Invoice;
            return $model->getThisEventEnlisterDomainPendingLocationInvoiceGivenEventId($event_id,$domain_id,$domain_trans_id);
        }
        
        /**
         * This is the function that gets the domain id of the organizers of an event
         */
        public function getTheDomainIdOfTheEventOrganizer($event_code){
            $model = new UserEnlistmentRequest;
            return $model->getTheDomainIdOfTheEventOrganizer($event_code);
        }
        
        /**
         * This is the function that retrieves the date of an event
         */
        public function getTheExpirationDateOfThisEvent($event_code){
            $model = new UserEnlistmentRequest;
            return $model->getTheExpirationDateOfThisEvent($event_code);
        }
        
        
        /**
         * This is the function that retrieves the date of an event
         */
        public function getTheExpirationDateOfThisEventGivenEventId($event_id){
            $model = new UserEnlistmentRequest;
            return $model->getTheExpirationDateOfThisEventGivenEventId($event_id);
        }
        
        
        /**
         * This is the function that confirms if an event code exist and it is available for delegate enrollment
         */
        public function isThisEventAvailableForDelegateEnrollmentGivenEventId($event_id){
            $model = new UserEnlistmentRequest;
            return $model->isThisEventAvailableForDelegateEnrollmentGivenEventId($event_id);
        }
        
        
        /**
         * This is the function that gets the domain id of the organizers of an event
         */
        public function getTheDomainIdOfTheEventOrganizerGivenEventId($event_id){
            $model = new UserEnlistmentRequest;
            return $model->getTheDomainIdOfTheEventOrganizerGivenEventId($event_id);
        }
        
        
        
         /**
         * This is the function that unenroll an event delegate
         */
        public function actionunenrolselfenrolledeventdelegate(){
             $_id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($_id);
            
            if($model->isTheUnenrollmentOfDelegatesAllowedForEvent($_id)){
                $model->is_delegate_enrolled = 0;
                $model->is_self_delegate_enrollment = 0;
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This event delegate had been unenrolled successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was probably a validation issue hence the attempt to unenrol this delegate from this event failed"
                        ));
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Delegate unenrollment is no longer allowed  for this event"
                        ));
            }
        }
        
        
        
        
        
         /**
         * This is the function that records a service code comsumption activity
         */
        public function recordThisServiceCodeConsumptionActivity($code_id,$feedback_display_medium){
            $model = new VerificationCodeConsumedByUser;
            return $model->recordThisServiceCodeConsumptionActivity($code_id,$feedback_display_medium);
        }
        
        
        /**
         * This is the function that activates  feedback service code
         */
        public function actionactivatefeedbackservicecode(){
            
                      
            $id = $_POST['id'];
            $model= EnlistmentVerificationCode::model()->findByPk($id);
            
            if($_REQUEST['feedback_display_medium_status'] == "inactive" or $_REQUEST['feedback_display_medium_status']==""){
                if($_REQUEST['feedback_display_medium'] == "all"){
                    if($model->isTheDeactivationOfAllServiceCodeOfThisEnlistmentASuccess($id)){
                        $model->feedback_display_medium_status = "active";
                        
                        if($model->save()){
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" =>"This service code is activated successfully",
                                   
                            ));
                        }else{
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" =>"This service code could not be activated. There is possibly a data validation issue. Please contact customer service for assistance",
                                   
                            ));
                        }
                    }else{
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" =>"This service code could not be activated.Please contact customer service for assistance",
                                   
                            ));
                    }
                }else{
                    if($model->isTheDeactivationOfTargetMediumOfThisEnlistmentASuccess($id,$_REQUEST['feedback_display_medium'])){
                         $model->feedback_display_medium_status = "active";
                        
                        if($model->save()){
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" =>"This service code is activated successfully",
                                   
                            ));
                        }else{
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" =>"This service code could not be activated. There is possibly a data validation issue. Please contact customer service for assistance",
                                   
                            ));
                        }
                    }else{
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" =>"This service code could not be activated.Please contact customer service for assistance",
                                   
                            ));
                    }
                }
                
                
                
            }else{
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" =>"This service code is already active. Please check your request and try again if needed",
                                   
                            ));
            }
            
        }
        
        
        /**
         * This is the function that retrieves the activated terminal feedback item
         
        public function actionretrievetheactiveterminalfeedbackforthiscode(){
            $model = new EnlistmentVerificationCode;
            //retreive the active and unexpired service code for this enlistment
            $terminal_feedback_code_id = $model->getTheActiveAndUnexpiredEnlistmentServiceCodes($_REQUEST['enlistment_id']);
            
            
            
            
        }
         * 
         */
        
        
        /**
         * This is the function that retrieves details of active feedback item service codes
         */
        public function actionretrievetheactiveterminalfeedbackforthiscode(){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$_REQUEST['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                    

                    //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='(enlistment_id=:enlistid and feedback_display_medium_status=:status) and (feedback_display_medium=:display or feedback_display_medium=:display2)';
                    $criteria->params = array(':enlistid'=>$enlistment['id'],':display'=>"terminal",':status'=>"active",':display2'=>"all");
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                   
                     //get the applicable feedback template
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid and status=:status';
                    $criteria->params = array(':codeid'=>$code['id'],':status'=>"active");
                    $feedback = FeedbackTemplate::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisServiceCodeConsumptionActivity($code['id'],$feedback_display_medium="terminal");
            
            
                     if($enlistment===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback
                                   
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
         /**
         * This is the function that retrieves details of active feedback item service codes
         */
        public function actionretrievetheactivesinglewebfeedbackforthiscode(){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='verification_code=:code';
                    $criteria->params = array(':code'=>$_REQUEST['code']);
                    $code =  EnlistmentVerificationCode::model()->find($criteria); 
                    
                    //get the enlistment details
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$code['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                     
                    if($code['feedback_display_medium'] == "single_web" or $code['feedback_display_medium'] == "all"){
                        
                        //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='(enlistment_id=:enlistid and feedback_display_medium_status=:status) and (feedback_display_medium=:display or feedback_display_medium=:display2)';
                    $criteria->params = array(':enlistid'=>$code['enlistment_id'],':display'=>"single_web",':status'=>"active",':display2'=>"all");
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                   
                     //get the applicable feedback template
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid and status=:status';
                    $criteria->params = array(':codeid'=>$code['id'],':status'=>"active");
                    $feedback = FeedbackTemplate::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisServiceCodeConsumptionActivity($code['id'],$feedback_display_medium="single_web");
            
            
                     if($enlistment===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback,
                                    "medium"=>$code['feedback_display_medium']
                                   
                                    
                    
                            ));
                       
                         }
                        
                    }else{
                        $code = 0;
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "code" =>$code
                                   
                            ));
                    }
                    
            
        }
        
        
        
        /**
         * This is the function that retrieves details of active feedback item service codes
         */
        public function actionretrievetheactivedomainwebfeedbackforthiscode(){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$_REQUEST['enlistment_id']);
                    $enlistment = UserEnlistmentRequest::model()->find($criteria); 
                    

                    //retrieve all the information about the code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='(enlistment_id=:enlistid and feedback_display_medium_status=:status) and (feedback_display_medium=:display or feedback_display_medium=:display2)';
                    $criteria->params = array(':enlistid'=>$enlistment['id'],':display'=>"domain_web",':status'=>"active",':display2'=>"all");
                    $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            
                   
                     //get the applicable feedback template
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='code_id=:codeid and status=:status';
                    $criteria->params = array(':codeid'=>$code['id'],':status'=>"active");
                    $feedback = FeedbackTemplate::model()->find($criteria); 
            
                    //record this code consumption activity
                    $this->recordThisServiceCodeConsumptionActivity($code['id'],$feedback_display_medium="domain_web");
            
            
                     if($enlistment===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    "feedback"=>$feedback
                                   
                                    
                    
                            ));
                       
                         }
            
        }
}
