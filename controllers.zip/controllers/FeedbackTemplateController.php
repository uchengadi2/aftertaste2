<?php

class FeedbackTemplateController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','creatinganewservicecodefeedbacktemplatedesign','listAllTemplatesForACode','enabletemplateforussd',
                                    'activatethisfeedback','deletefeedbacktemplate','updatefeedbacktemplate','listAllFeedbackResponsesFromAFeedbackCode',
                                    'listAllTemplates'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that creates a new feedback template design
         */
        public function actioncreatinganewservicecodefeedbacktemplatedesign(){
            
            $model = new FeedbackTemplate;
            
            if(isset($_REQUEST['is_first_feedback_included'])){
                $model->is_first_feedback_included = $_REQUEST['is_first_feedback_included'];
                $model->first_feedback_type = $_REQUEST['first_feedback_type'];
                $model->first_feedback_question = $_REQUEST['first_feedback_question'];
                $model->first_feedback_name = $_REQUEST['first_feedback_name'];
                $model->first_feedback_purpose = $_REQUEST['first_feedback_purpose'];
                
            }else{
                $model->is_first_feedback_included = 0;
                $model->first_feedback_type = NULL;
                $model->first_feedback_question = NULL;
                $model->first_feedback_name = NULL;
                $model->first_feedback_purpose = NULL;
            }
             if(isset($_REQUEST['is_second_feedback_included'])){
                $model->is_second_feedback_included = $_REQUEST['is_second_feedback_included'];
                $model->second_feedback_type = $_REQUEST['second_feedback_type'];
                $model->second_feedback_question = $_REQUEST['second_feedback_question'];
                $model->second_feedback_name = $_REQUEST['second_feedback_name'];
                $model->second_feedback_purpose = $_REQUEST['second_feedback_purpose'];
                
            }else{
                $model->is_second_feedback_included = 0;
                $model->second_feedback_type = NULL;
                $model->second_feedback_question = NULL;
                $model->second_feedback_name = NULL;
                $model->second_feedback_purpose = NULL;
            }
            
            
            
            if(isset($_REQUEST['is_third_feedback_included'])){
                $model->is_third_feedback_included = $_REQUEST['is_third_feedback_included'];
                $model->third_feedback_type = $_REQUEST['third_feedback_type'];
                $model->third_feedback_question = $_REQUEST['third_feedback_question'];
                $model->third_feedback_name = $_REQUEST['third_feedback_name'];
                $model->third_feedback_purpose = $_REQUEST['third_feedback_purpose'];
                
            }else{
                $model->is_third_feedback_included = 0;
                $model->third_feedback_type = NULL;
                $model->third_feedback_question = NULL;
                $model->third_feedback_name = NULL;
                $model->third_feedback_purpose = NULL;
            }
            
             if(isset($_REQUEST['is_fourth_feedback_included'])){
                $model->is_fourth_feedback_included = $_REQUEST['is_fourth_feedback_included'];
                $model->fourth_feedback_type = $_REQUEST['fourth_feedback_type'];
                $model->fourth_feedback_question = $_REQUEST['fourth_feedback_question'];
                $model->fourth_feedback_name = $_REQUEST['fourth_feedback_name'];
                $model->fourth_feedback_purpose = $_REQUEST['fourth_feedback_purpose'];
                
            }else{
                $model->is_fourth_feedback_included = 0;
                $model->fourth_feedback_type = NULL;
                $model->fourth_feedback_question = NULL;
                $model->fourth_feedback_name = NULL;
                $model->fourth_feedback_purpose = NULL;
            }
            
            if(isset($_REQUEST['is_fifth_feedback_included'])){
                $model->is_fifth_feedback_included = $_REQUEST['is_fifth_feedback_included'];
                $model->fifth_feedback_type = $_REQUEST['fifth_feedback_type'];
                $model->fifth_feedback_question = $_REQUEST['fifth_feedback_question'];
                $model->fifth_feedback_name = $_REQUEST['fifth_feedback_name'];
                $model->fifth_feedback_purpose = $_REQUEST['fifth_feedback_purpose'];
                
            }else{
                $model->is_fifth_feedback_included = 0;
                $model->fifth_feedback_type = NULL;
                $model->fifth_feedback_question = NULL;
                $model->fifth_feedback_name = NULL;
                $model->fifth_feedback_purpose = NULL;
            }
            
            
            //other model fields
            $model->code_id = $_REQUEST['code_id'];
            //$model->status = $_REQUEST['status'];
            $model->status = "inactive";
            $model->template_name = $_REQUEST['template_name'];
            $model->template_label = $_REQUEST['template_label'];
            $model->maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
            $model->is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
            if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                $model->is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
            }else{
                $model->is_multiple_feedback_responses_allowed = 0;
            }
            if($model->isThisTemplateNameAlreadyUsed($model->code_id,$model->template_name)== false){
                
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This feedback template is created succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be created. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This template name had already been used. Please use a different template name"
                        )); 
                
            }
            
        }
        
        
        
        /**
         * This is the function that list all templates for a code
         */
        public function actionlistAllTemplatesForACode(){
            $code_id = $_REQUEST['code_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $templates = FeedbackTemplate::model()->findAll($criteria);
            
             if($templates===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "template" =>$templates,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        /**
         * This is the function that updates a template
         */
        public function actionupdatefeedbacktemplate(){
            
             $_id = $_POST['id'];
            $model= FeedbackTemplate::model()->findByPk($_id);
            
            if(isset($_REQUEST['is_first_feedback_included'])){
                $model->is_first_feedback_included = $_REQUEST['is_first_feedback_included'];
                $model->first_feedback_type = $_REQUEST['first_feedback_type'];
                $model->first_feedback_question = $_REQUEST['first_feedback_question'];
                $model->first_feedback_name = $_REQUEST['first_feedback_name'];
                $model->first_feedback_purpose = $_REQUEST['first_feedback_purpose'];
                
            }else{
                $model->is_first_feedback_included = 0;
                $model->first_feedback_type = NULL;
                $model->first_feedback_question = NULL;
                $model->first_feedback_name = NULL;
                $model->first_feedback_purpose = NULL;
            }
             if(isset($_REQUEST['is_second_feedback_included'])){
                $model->is_second_feedback_included = $_REQUEST['is_second_feedback_included'];
                $model->second_feedback_type = $_REQUEST['second_feedback_type'];
                $model->second_feedback_question = $_REQUEST['second_feedback_question'];
                $model->second_feedback_name = $_REQUEST['second_feedback_name'];
                $model->second_feedback_purpose = $_REQUEST['second_feedback_purpose'];
                
            }else{
                $model->is_second_feedback_included = 0;
                $model->second_feedback_type = NULL;
                $model->second_feedback_question = NULL;
                $model->second_feedback_name = NULL;
                $model->second_feedback_purpose = NULL;
            }
            
            
            
            if(isset($_REQUEST['is_third_feedback_included'])){
                $model->is_third_feedback_included = $_REQUEST['is_third_feedback_included'];
                $model->third_feedback_type = $_REQUEST['third_feedback_type'];
                $model->third_feedback_question = $_REQUEST['third_feedback_question'];
                $model->third_feedback_name = $_REQUEST['third_feedback_name'];
                $model->third_feedback_purpose = $_REQUEST['third_feedback_purpose'];
                
            }else{
                $model->is_third_feedback_included = 0;
                $model->third_feedback_type = NULL;
                $model->third_feedback_question = NULL;
                $model->third_feedback_name = NULL;
                $model->third_feedback_purpose = NULL;
            }
            
             if(isset($_REQUEST['is_fourth_feedback_included'])){
                $model->is_fourth_feedback_included = $_REQUEST['is_fourth_feedback_included'];
                $model->fourth_feedback_type = $_REQUEST['fourth_feedback_type'];
                $model->fourth_feedback_question = $_REQUEST['fourth_feedback_question'];
                $model->fourth_feedback_name = $_REQUEST['fourth_feedback_name'];
                $model->fourth_feedback_purpose = $_REQUEST['fourth_feedback_purpose'];
                
            }else{
                $model->is_fourth_feedback_included = 0;
                $model->fourth_feedback_type = NULL;
                $model->fourth_feedback_question = NULL;
                $model->fourth_feedback_name = NULL;
                $model->fourth_feedback_purpose = NULL;
            }
            
            if(isset($_REQUEST['is_fifth_feedback_included'])){
                $model->is_fifth_feedback_included = $_REQUEST['is_fifth_feedback_included'];
                $model->fifth_feedback_type = $_REQUEST['fifth_feedback_type'];
                $model->fifth_feedback_question = $_REQUEST['fifth_feedback_question'];
                $model->fifth_feedback_name = $_REQUEST['fifth_feedback_name'];
                $model->fifth_feedback_purpose = $_REQUEST['fifth_feedback_purpose'];
                
            }else{
                $model->is_fifth_feedback_included = 0;
                $model->fifth_feedback_type = NULL;
                $model->fifth_feedback_question = NULL;
                $model->fifth_feedback_name = NULL;
                $model->fifth_feedback_purpose = NULL;
            }
            
            
            //other model fields
            $model->code_id = $_REQUEST['code_id'];
            //$model->status = $_REQUEST['status'];
            $model->template_name = $_REQUEST['template_name'];
            $model->template_label = $_REQUEST['template_label'];
            $model->maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
            $model->is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
            if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                $model->is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
            }else{
                $model->is_multiple_feedback_responses_allowed = 0;
            }
            
            //get the existing template name of this feedback templake
            $template_name = $model->getThisFeedbackTemplateName($_id);
            
         if($this->isThisFeedbackTemplateAlreadyWithReponses($_id)== false){
                     if($template_name ==$model->template_name){
              if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This feedback template is updated succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be created. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                
            }else{
               if($model->isThisTemplateNameAlreadyUsed($model->code_id,$model->template_name)== false){
                
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This feedback template is updated succesfully"
                        ));
                
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be created. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                
            }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This template name had already been used. Please use a different template name"
                        )); 
                
            }
         }
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This template could not be updated as it had already started to recieve responses. It is advisable to create a new template instead"
                        ));
                
            }
            
           
                          
           
                
          
        }
        
        
        /**
         * This is the function that deletes feedback template
         */
        public function actiondeletefeedbacktemplate(){
            $_id = $_POST['id'];
            $model= FeedbackTemplate::model()->findByPk($_id);
            
            //get the template name
            $template_name = $model->getThisFeedbackTemplateName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$template_name' template was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        /**
         * This is the function that activates a feedback
         */
        public function actionactivatethisfeedback(){
             $_id = $_POST['id'];
             $code_id = $_POST['code_id'];
             $model= FeedbackTemplate::model()->findByPk($_id);
             
             //deactivate all templates by this code
             if($this->isAllTemplatesByThisCodeDeactivates($code_id)){
                 $model->status = "active";
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This feedback template is activated"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be activated. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                 
             }else{
                  header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be activated. Please contact service desk for assistance"
                        ));  
             }
       
        }
        
        
         /**
              * This is the function that deactivates all templates for a code
              */
             public function isAllTemplatesByThisCodeDeactivates($code_id){
                 $model = new FeedbackTemplate;     
                 $error_counter = 0;
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='code_id=:codeid';
                 $criteria->params = array(':codeid'=>$code_id);
                 $templates = FeedbackTemplate::model()->findAll($criteria);
                 
                 foreach($templates as $template){
                     if($model->isTheDeactivationOfThisTemplateASuccess($template['id']) == false){
                         $error_counter = $error_counter + 1;
                     }
                 }
                 if($error_counter == 0){
                     return true;
                 }else{
                     return false;
                 }
                 
             }
             
             
             /**
              * This is the function that enables a template for ussd
              */
             public function actionenabletemplateforussd(){
                 $_id = $_POST['id'];
                $code_id = $_POST['code_id'];
                $model= FeedbackTemplate::model()->findByPk($_id);
             
                //deactivate all templates by this code
                if($this->isAllTemplatesByThisCodeUssdDeactivates($code_id)){
                    $model->is_ussd_active = 1;
                    if($model->save()){
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This feedback template is enabled for ussd"
                        ));
                
                
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be enabled for ussd. There is possibly some data validation issue. Check your data and try again"
                        ));  
                }
                 
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be enabled for ussd. Please contact service desk for assistance"
                        ));  
                }
             }
             
             
              /**
              * This is the function that deactivates all templates for a ussd
              */
             public function isAllTemplatesByThisCodeUssdDeactivates($code_id){
                 $model = new FeedbackTemplate;  
                 $error_counter = 0;
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='code_id=:codeid';
                 $criteria->params = array(':codeid'=>$code_id);
                 $templates = FeedbackTemplate::model()->findAll($criteria);
                 
                 foreach($templates as $template){
                    if($model->isTheDisablingOfThisUssdTemplateASuccess($template['id']) == false){
                         $error_counter = $error_counter + 1;
                     }
                 }
                 if($error_counter == 0){
                     return true;
                 }else{
                     return false;
                 }
                 
                 
             }
             
             
             /**
              * This is the function that determines if a feedback template has responses
              */
             public function isThisFeedbackTemplateAlreadyWithReponses($template_id){
                 $model = new FeedbacksTemplateResponse;
                 return $model->isThisFeedbackTemplateAlreadyWithReponses($template_id);
             }
             
             
             
       /**
         * This is the function that list all templates
         */
        public function actionlistAllTemplates(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $templates = FeedbackTemplate::model()->findAll($criteria);
            
             if($templates===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "template" =>$templates,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
         /**
         * This is the function that retrieves all responses of a feedback code
         */
        public function actionlistAllFeedbackResponsesFromAFeedbackCode(){
            $code_id = $_REQUEST['code_id'];
            $target = [];
            
            //get the feedbakc template othis code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $templates = FeedbackTemplate::model()->findAll($criteria);
            
            foreach($templates as $template){
                 //get the feedbakc template othis code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='template_id=:tempid';
                    $criteria->params = array(':tempid'=>$template['id']);
                    $feedbacks = FeedbacksTemplateResponse::model()->findAll($criteria);
                    foreach($feedbacks as $feedback){
                        $target[] = $feedback;
                    }
        
            }
       
            if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "feedback" =>$target
                                                                        
                    
                            ));
                       
                         }
        }
        
}
