<?php

class FeedbackTemplateOptionsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','getThisQuestionInTheTemplate','retrievealltheoptionsinaquestion','getTheQuestionWithThisQuestionNumber',
                                    'retrieveallthedetailsaboutthisquestion','retrieveAllTheOptionsOfThisQuestion'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrievequestionoptions'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves all the options in a feedback question
         */
        public function actionretrievequestionoptions(){
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='template_id=:tempid and question_number=:questno';
            $criteria->params = array(':tempid'=>$template_id,':questno'=>$question_number);
            $options = FeedbackTemplateOptions::model()->findAll($criteria); 
            
            if($options===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "option"=>$options,
                                                            
                            ));
                       
                         }
        }
        
        
        
        
        
        /**
         * This is the function that retrieves all the options in a feedback question after authenticity confirmation
         */
        public function actionretrievealltheoptionsinaquestion(){
           $model = new FeedbacksTemplateResponse;
            
            $domain_id = $_REQUEST['domain_id'];
            $user_id = $_REQUEST['user_id'];
            $location = $_REQUEST['location'];
            $project_id = $_REQUEST['project_id'];
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            $unit = $_REQUEST['unit'];
            $total_responses_received = $_REQUEST['total_responses_received'];
            $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
            $issue_type = $_REQUEST['issue_type'];   
            
            
            if($this->isThisDataAuthentic($domain_id,$user_id,$location)){
                $result = true;
            }else{
                $result = false;
            }
            
            //get the name of unit, location and project name
            $unit_name = $this->getThisLocationUnitName($unit);
            
            $location_name = $this->getThisLocationName($location);
            
            $project_name = $this->getThisProjectName($project_id);
            
             $type = $this->getThisProjectType($project_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='template_id=:tempid and question_number=:questno';
            $criteria->params = array(':tempid'=>$template_id,':questno'=>$question_number);
            $options = FeedbackTemplateOptions::model()->findAll($criteria); 
            
            
            if($_REQUEST['type'] == "basic"){
                 
                
               
            
            //calculate the percentage responses of feedback question options
            $percentage_responses = $this->getThePercentageResponsesOfFeedbackQuestionOptions($template_id,$question_number,$total_responses_received,$start_date,$end_date); 
           
             $count = sizeof($percentage_responses);
           
                
            }else if($_REQUEST['type'] == "advance"){
                //get the conditional data
            $univariate_advance_conditional_counter = $_REQUEST['univariate_advance_conditional_counter'];
            $univariate_advance_first_variable_condition = $_REQUEST['univariate_advance_first_variable_condition'];
            $univariate_advance_second_variable_condition = $_REQUEST['univariate_advance_second_variable_condition'];
            $univariate_advance_third_variable_condition = $_REQUEST['univariate_advance_third_variable_condition'];
            $univariate_advance_fourth_variable_condition = $_REQUEST['univariate_advance_fourth_variable_condition'];
            $univariate_advance_fifth_variable_condition = $_REQUEST['univariate_advance_fifth_variable_condition'];
            $univariate_advance_sixth_variable_condition = $_REQUEST['univariate_advance_sixth_variable_condition'];
            $univariate_advance_seventh_variable_condition =$_REQUEST['univariate_advance_seventh_variable_condition'];
            $univariate_advance_eighth_variable_condition = $_REQUEST['univariate_advance_eighth_variable_condition'];
            $univariate_advance_nineth_variable_condition = $_REQUEST['univariate_advance_nineth_variable_condition'];
            $univariate_advance_tenth_variable_condition = $_REQUEST['univariate_advance_tenth_variable_condition'];
            $univariate_advance_first_independent_variable_type = $_REQUEST['univariate_advance_first_independent_variable_type'];
            $univariate_advance_second_independent_variable_type = $_REQUEST['univariate_advance_second_independent_variable_type'];
            $univariate_advance_third_independent_variable_type = $_REQUEST['univariate_advance_third_independent_variable_type'];
            $univariate_advance_fourth_independent_variable_type =$_REQUEST['univariate_advance_fourth_independent_variable_type'];
            $univariate_advance_fifth_independent_variable_type = $_REQUEST['univariate_advance_fifth_independent_variable_type'];
            $univariate_advance_sixth_independent_variable_type = $_REQUEST['univariate_advance_sixth_independent_variable_type'];
            $univariate_advance_seventh_independent_variable_type = $_REQUEST['univariate_advance_seventh_independent_variable_type'];
            $univariate_advance_eighth_independent_variable_type = $_REQUEST['univariate_advance_eighth_independent_variable_type'];
            $univariate_advance_nineth_independent_variable_type = $_REQUEST['univariate_advance_nineth_independent_variable_type'];
            $univariate_advance_tenth_independent_variable_type = $_REQUEST['univariate_advance_tenth_independent_variable_type'];
            $univariate_advance_first_independent_variable_question_number = $_REQUEST['univariate_advance_first_independent_variable_question_number'];
            $univariate_advance_second_independent_variable_question_number = $_REQUEST['univariate_advance_second_independent_variable_question_number'];
            $univariate_advance_third_independent_variable_question_number = $_REQUEST['univariate_advance_third_independent_variable_question_number'];
            $univariate_advance_fourth_independent_variable_question_number =$_REQUEST['univariate_advance_fourth_independent_variable_question_number'];
            $univariate_advance_fifth_independent_variable_question_number = $_REQUEST['univariate_advance_fifth_independent_variable_question_number'];
            $univariate_advance_sixth_independent_variable_question_number = $_REQUEST['univariate_advance_sixth_independent_variable_question_number'];
            $univariate_advance_seventh_independent_variable_question_number = $_REQUEST['univariate_advance_seventh_independent_variable_question_number'];
            $univariate_advance_eighth_independent_variable_question_number = $_REQUEST['univariate_advance_eighth_independent_variable_question_number'];
            $univariate_advance_nineth_independent_variable_question_number =$_REQUEST['univariate_advance_nineth_independent_variable_question_number'];
            $univariate_advance_tenth_independent_variable_question_number = $_REQUEST['univariate_advance_tenth_independent_variable_question_number'];
            $univariate_advance_first_independent_variable_value = $_REQUEST['univariate_advance_first_independent_variable_value'];
            $univariate_advance_second_independent_variable_value = $_REQUEST['univariate_advance_second_independent_variable_value'];
            $univariate_advance_third_independent_variable_value = $_REQUEST['univariate_advance_third_independent_variable_value'];
            $univariate_advance_fourth_independent_variable_value = $_REQUEST['univariate_advance_fourth_independent_variable_value'];
            $univariate_advance_fifth_independent_variable_value = $_REQUEST['univariate_advance_fifth_independent_variable_value'];
            $univariate_advance_sixth_independent_variable_value = $_REQUEST['univariate_advance_sixth_independent_variable_value'];
            $univariate_advance_seventh_independent_variable_value = $_REQUEST['univariate_advance_seventh_independent_variable_value'];
            $univariate_advance_eighth_independent_variable_value = $_REQUEST['univariate_advance_eighth_independent_variable_value'];
            $univariate_advance_nineth_independent_variable_value = $_REQUEST['univariate_advance_nineth_independent_variable_value'];
            $univariate_advance_tenth_independent_variable_value = $_REQUEST['univariate_advance_tenth_independent_variable_value'];
            
            
            if($univariate_advance_conditional_counter == 0){
               if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNoCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithNoConditional($issue_type,$template_id,$question_number);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }          
             
                
                
            }else if ($univariate_advance_conditional_counter == 1){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithOneCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithOneConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 2){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTwoCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithTwoConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
                
                
            }else if($univariate_advance_conditional_counter == 3){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithThreeCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithThreeConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
                
            }else if($univariate_advance_conditional_counter == 4){
                              
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFourCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithFourConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
            }else if($univariate_advance_conditional_counter ==5){
                            
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFiveCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithFiveConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 6){
                               
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSixCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithSixConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 7){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSevenCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithSevenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 8){
                              
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithEightCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithEightConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
               
                
            }else if($univariate_advance_conditional_counter == 9){
                               
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNineCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithNineConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 10){
                               
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTenCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithTenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }     
                
            }
                
                
            }//end of the advance type
            
             
             if($options===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic" => $result,
                                    "option"=>$options,
                                    "count"=>$count,
                                    "project_type"=>$type,
                                    "unit_name"=>$unit_name,
                                    "location_name"=>$location_name,
                                    "project_name"=>$project_name,
                                    "percent"=>$percentage_responses
                                     
                                                            
                            ));
                       
                         }
            
        }
        
        
        
       
        
        /**
         * This is the function that retrieves the percentage responses of a feedback question
         */
        public function getThePercentageResponsesOfFeedbackQuestionOptions($template_id,$question_number,$total_responses_received,$start_date,$end_date){
            $model = new FeedbacksTemplateResponse;
            return $model->getThePercentageResponsesOfFeedbackQuestionOptions($template_id,$question_number,$total_responses_received,$start_date,$end_date);
        }
        
        /**
         * This is the function that gets a unit's name
         */
        public function getThisLocationUnitName($unit_id){
            $model = new LocationUnit;
            return $model->getThisLocationUnitName($unit_id);
        }
        
        /**
         * This is the function that gets the name of a domain location
         */
        public function getThisLocationName($location_id){
            $model = new DomainLocations;
            return $model->getThisLocationName($location_id);
        }
        
        /**
         * This is the function that gets the name of a project or a user enlistment
         */
        public function getThisProjectName($project_id){
            $model = new UserEnlistmentRequest;
            return $model->getThisProjectName($project_id);
        }
        
        
         /**
         * This is the function that retrieves a project type
         */
        public function getThisProjectType($project_id){
            $model = new UserEnlistmentRequest;
            return $model->getThisProjectType($project_id);
        }
        
        
        /**
         * This is the function that retrieves the option for a feedback template question number
         */
        public function actiongetTheQuestionWithThisQuestionNumber(){
            
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='template_id=:tempid and question_number=:questno';
            $criteria->params = array(':tempid'=>$template_id,':questno'=>$question_number);
            $options = FeedbackTemplateOptions::model()->findAll($criteria); 
            
            
        }
        
        
        
        /**
         * This is the function that retrieves all the details about a feedback question after authenticity confirmation
         */
        public function actionretrieveallthedetailsaboutthisquestion(){
            $model = new FeedbacksTemplateResponse;
            
            $domain_id = $_REQUEST['domain_id'];
            $user_id = $_REQUEST['user_id'];
            $location = $_REQUEST['location'];
            $project_id = $_REQUEST['project_id'];
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            //$issue_type = $_REQUEST['issue_type'];
            $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
            
            $issue_type = $this->retrievethistemplateissueType($template_id,$question_number);
            
             if($this->isThisDataAuthentic($domain_id,$user_id,$location)){
                $result = true;
            }else{
                $result = false;
            }
            
             //get this project type
            $type = $this->getThisProjectType($project_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='template_id=:tempid and question_number=:questno';
            $criteria->params = array(':tempid'=>$template_id,':questno'=>$question_number);
            $options = FeedbackTemplateOptions::model()->findAll($criteria); 
            
            if($_REQUEST['type'] == "basic"){
                
             if($model->isIssueTypeWithOptions($issue_type)){
                 //get the total feedback response
                $total_response = $model->getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                //retrieve the total number of each option responses for this issue
                $option_responses = $model->retrieveTheTotalNumberOfResponseForEachOption($issue_type,$template_id,$question_number,$start_date,$end_date);
                
                //get the total feedback available option 
                $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptions($issue_type,$template_id,$question_number);
            }else if($model->isIssueTypeBoolean($issue_type)){
                //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            }else{
                //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            }    
            
             //calculate the percentage responses of feedback question options
            $percentage_responses = $model->getThePercentageResponsesOfFeedbackQuestionOptions($template_id,$question_number,$total_response,$start_date,$end_date);
            
             $count = sizeof($percentage_responses);   
                
            }else if($_REQUEST['type'] == "advance"){
                
                 //get the conditional data
            $univariate_advance_conditional_counter = $_REQUEST['univariate_advance_conditional_counter'];
            $univariate_advance_first_variable_condition = $_REQUEST['univariate_advance_first_variable_condition'];
            $univariate_advance_second_variable_condition = $_REQUEST['univariate_advance_second_variable_condition'];
            $univariate_advance_third_variable_condition = $_REQUEST['univariate_advance_third_variable_condition'];
            $univariate_advance_fourth_variable_condition = $_REQUEST['univariate_advance_fourth_variable_condition'];
            $univariate_advance_fifth_variable_condition = $_REQUEST['univariate_advance_fifth_variable_condition'];
            $univariate_advance_sixth_variable_condition = $_REQUEST['univariate_advance_sixth_variable_condition'];
            $univariate_advance_seventh_variable_condition =$_REQUEST['univariate_advance_seventh_variable_condition'];
            $univariate_advance_eighth_variable_condition = $_REQUEST['univariate_advance_eighth_variable_condition'];
            $univariate_advance_nineth_variable_condition = $_REQUEST['univariate_advance_nineth_variable_condition'];
            $univariate_advance_tenth_variable_condition = $_REQUEST['univariate_advance_tenth_variable_condition'];
            $univariate_advance_first_independent_variable_type = $_REQUEST['univariate_advance_first_independent_variable_type'];
            $univariate_advance_second_independent_variable_type = $_REQUEST['univariate_advance_second_independent_variable_type'];
            $univariate_advance_third_independent_variable_type = $_REQUEST['univariate_advance_third_independent_variable_type'];
            $univariate_advance_fourth_independent_variable_type =$_REQUEST['univariate_advance_fourth_independent_variable_type'];
            $univariate_advance_fifth_independent_variable_type = $_REQUEST['univariate_advance_fifth_independent_variable_type'];
            $univariate_advance_sixth_independent_variable_type = $_REQUEST['univariate_advance_sixth_independent_variable_type'];
            $univariate_advance_seventh_independent_variable_type = $_REQUEST['univariate_advance_seventh_independent_variable_type'];
            $univariate_advance_eighth_independent_variable_type = $_REQUEST['univariate_advance_eighth_independent_variable_type'];
            $univariate_advance_nineth_independent_variable_type = $_REQUEST['univariate_advance_nineth_independent_variable_type'];
            $univariate_advance_tenth_independent_variable_type = $_REQUEST['univariate_advance_tenth_independent_variable_type'];
            $univariate_advance_first_independent_variable_question_number = $_REQUEST['univariate_advance_first_independent_variable_question_number'];
            $univariate_advance_second_independent_variable_question_number = $_REQUEST['univariate_advance_second_independent_variable_question_number'];
            $univariate_advance_third_independent_variable_question_number = $_REQUEST['univariate_advance_third_independent_variable_question_number'];
            $univariate_advance_fourth_independent_variable_question_number =$_REQUEST['univariate_advance_fourth_independent_variable_question_number'];
            $univariate_advance_fifth_independent_variable_question_number = $_REQUEST['univariate_advance_fifth_independent_variable_question_number'];
            $univariate_advance_sixth_independent_variable_question_number = $_REQUEST['univariate_advance_sixth_independent_variable_question_number'];
            $univariate_advance_seventh_independent_variable_question_number = $_REQUEST['univariate_advance_seventh_independent_variable_question_number'];
            $univariate_advance_eighth_independent_variable_question_number = $_REQUEST['univariate_advance_eighth_independent_variable_question_number'];
            $univariate_advance_nineth_independent_variable_question_number =$_REQUEST['univariate_advance_nineth_independent_variable_question_number'];
            $univariate_advance_tenth_independent_variable_question_number = $_REQUEST['univariate_advance_tenth_independent_variable_question_number'];
            $univariate_advance_first_independent_variable_value = $_REQUEST['univariate_advance_first_independent_variable_value'];
            $univariate_advance_second_independent_variable_value = $_REQUEST['univariate_advance_second_independent_variable_value'];
            $univariate_advance_third_independent_variable_value = $_REQUEST['univariate_advance_third_independent_variable_value'];
            $univariate_advance_fourth_independent_variable_value = $_REQUEST['univariate_advance_fourth_independent_variable_value'];
            $univariate_advance_fifth_independent_variable_value = $_REQUEST['univariate_advance_fifth_independent_variable_value'];
            $univariate_advance_sixth_independent_variable_value = $_REQUEST['univariate_advance_sixth_independent_variable_value'];
            $univariate_advance_seventh_independent_variable_value = $_REQUEST['univariate_advance_seventh_independent_variable_value'];
            $univariate_advance_eighth_independent_variable_value = $_REQUEST['univariate_advance_eighth_independent_variable_value'];
            $univariate_advance_nineth_independent_variable_value = $_REQUEST['univariate_advance_nineth_independent_variable_value'];
            $univariate_advance_tenth_independent_variable_value = $_REQUEST['univariate_advance_tenth_independent_variable_value'];
            
            $option_responses = [];
            if($univariate_advance_conditional_counter == 0){
               if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNoCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithNoConditional($issue_type,$template_id,$question_number);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }          
             
                
                
            }else if ($univariate_advance_conditional_counter == 1){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithOneCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithOneConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 2){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTwoCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithTwoConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
                
                
            }else if($univariate_advance_conditional_counter == 3){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithThreeCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithThreeConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
                
            }else if($univariate_advance_conditional_counter == 4){
                              
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFourCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithFourConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
            }else if($univariate_advance_conditional_counter ==5){
                            
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFiveCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithFiveConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 6){
                               
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSixCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithSixConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 7){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSevenCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithSevenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 8){
                              
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithEightCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithEightConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
               
                
            }else if($univariate_advance_conditional_counter == 9){
                               
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNineCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithNineConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 10){
                               
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $percentage_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTenCondtionsInPercentages($total_response,$issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                    $count = sizeof($percentage_responses);
                    //get the total feedback available option 
                    //$option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithTenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }     
                
            }
                
                
            }
            
           
            if($options===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "is_authentic" => $result,
                                    "option"=>$options,
                                    "count"=>$count,
                                    "project_type"=>$type,
                                    "total_responses"=>$total_response,
                                    "data"=>$option_responses,
                                    //"total_option"=>$option_count,
                                    "percent"=>$percentage_responses,
                                    "issue_type"=>$issue_type
                                                            
                            ));
                       
                         }
        }
        
        
       /**
         * This is the function that determines is a location is authentic 
         */
        public function isThisDataAuthentic($domain_id,$user_id,$location){
            $model = new DomainLocations;
            return $model->isThisDataAuthentic($domain_id,$user_id,$location);
        }
        
        
        /**
         * This is the function that retrieves some details about an issue/question
         */
        public function retrievethistemplateissueType($template_id,$question_number){
            $model = new FeedbackTemplate;
            return $model->retrievethistemplateissueType($template_id,$question_number);
        }
        
        
       
        
}
