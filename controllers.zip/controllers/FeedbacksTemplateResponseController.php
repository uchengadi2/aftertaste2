<?php

class FeedbacksTemplateResponseController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','submittinguserfeedback','retrievethefeedbackresponsesofthisproject','retrieveresponsesforeachfeedbackoption',
                                    'retrievethefeedbackresponseswithconditions','retrieveconditionalresponsesforeachfeedbackoption','retrieveprogressreportForThisOption','retrieveprogressreportForThisOptionWithConditions'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','submittinguserfeedback','retrievefeedbackresponsedetails'.'retrievethefeedbackresponsesofthisproject',
                                    'listallresponsesinatemplate'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that captures feedback responses
         */
        public function actionsubmittinguserfeedback(){
            $model = new FeedbacksTemplateResponse;
            
            $user_id = Yii::app()->user->id;
            
            $model->template_id = $_REQUEST['feedback_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->date_provided = new CDbExpression('NOW()');
            $model->trans_refid = $model->getTheReferenceIdForThisFeedbackResponse();
            
            //treating the first feedback question
            if(isset($_REQUEST['first_feedback_response_boolean'])){
                $model->first_feedback_response_boolean = $_REQUEST['first_feedback_response_boolean'];
            }
            if((!empty($_REQUEST['first_feedback_response_text']))){
                $model->first_feedback_response_text = $_REQUEST['first_feedback_response_text'];
            }
            if((!empty($_REQUEST['first_feedback_response_long_text']))){
                $model->first_feedback_response_text = $_REQUEST['first_feedback_response_long_text'];
            }
            if(!empty($_REQUEST['first_feedback_response_integer'])){
                $model->first_feedback_response_integer = $_REQUEST['first_feedback_response_integer'];
            }
           if(!empty($_REQUEST['first_feedback_response_double'])){
                $model->first_feedback_response_double = $_REQUEST['first_feedback_response_double'];
            }
            //capturing single text option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['first_feedback_response_single_option'])){
                $model->first_feedback_response_single_option = $_REQUEST['first_feedback_response_single_option'];
                $response_counter = $response_counter + 1;
                 
            }
            if($response_counter == 0){
                if(!empty($_REQUEST['first_feedback_response_single_option_combo'])){
                    $model->first_feedback_response_single_option = $_REQUEST['first_feedback_response_single_option_combo'];
                   
                }
            }
             
            //capturing single numeric option feedback data
            $response_counter=0;
             if(isset($_REQUEST['first_feedback_response_single_option_number'])){
                $model->first_feedback_response_single_option_number = $_REQUEST['first_feedback_response_single_option_number'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter == 0){
                 if(!empty($_REQUEST['first_feedback_response_single_option_number_combo'])){
                $model->first_feedback_response_single_option_number = $_REQUEST['first_feedback_response_single_option_number_combo'];
            }
            }
            
            
            //capturing the multiple text option feedback data
            $first_multiple_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['first_feedback_response_multiple_option_1'])){
                $first_multiple_response[] = $_REQUEST['first_feedback_response_multiple_option_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_2'])){
                $first_multiple_response[] = $_REQUEST['first_feedback_response_multiple_option_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_3'])){
                $first_multiple_response[] = $_REQUEST['first_feedback_response_multiple_option_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_4'])){
                $first_multiple_response[] = $_REQUEST['first_feedback_response_multiple_option_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_5'])){
                $first_multiple_response[] = $_REQUEST['first_feedback_response_multiple_option_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($first_multiple_response)>0){
                 $model->first_feedback_response_multiple_option = implode("+",$first_multiple_response);
                
             }
             
             //capturing the multple text option data from a combo
             if($response_counter==0){
                  if(!empty($_REQUEST['first_feedback_response_multiple_option_combo'])){
                        $model->first_feedback_response_multiple_option = implode("+",$_REQUEST['first_feedback_response_multiple_option_combo']);
                
                }
             }
            
          
            
             //capturing the multiple numeric option feedback data
            $first_multiple_numeric_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['first_feedback_response_multiple_option_number_1'])){
                $first_multiple_numeric_response[] = $_REQUEST['first_feedback_response_multiple_option_number_1'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_number_2'])){
                $first_multiple_numeric_response[] = $_REQUEST['first_feedback_response_multiple_option_number_2'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_number_3'])){
                $first_multiple_numeric_response[] = $_REQUEST['first_feedback_response_multiple_option_number_3'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_number_4'])){
                $first_multiple_numeric_response[] = $_REQUEST['first_feedback_response_multiple_option_number_4'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['first_feedback_response_multiple_option_number_5'])){
                $first_multiple_numeric_response[] = $_REQUEST['first_feedback_response_multiple_option_number_5'];
                $response_counter = $response_counter +1;
             }
             if(sizeof($first_multiple_numeric_response)>0){
                 $model->first_feedback_response_multiple_option_number = implode(",",$first_multiple_numeric_response);
                
             }
             
             
             //capturing the multple numeric option data from a combo
             if($response_counter == 0){
                  if(!empty($_REQUEST['first_feedback_response_multiple_option_number_combo'])){
                        $model->first_feedback_response_multiple_option_number = implode(',',$_REQUEST['first_feedback_response_multiple_option_number_combo']);
                
                    }
             }
             
           
            
            //treating the second feedback question
            if(isset($_REQUEST['second_feedback_response_boolean'])){
                $model->second_feedback_response_boolean = $_REQUEST['second_feedback_response_boolean'];
            }
            if((!empty($_REQUEST['second_feedback_response_text']))){
                $model->second_feedback_response_text = $_REQUEST['second_feedback_response_text'];
            }
            
            if((!empty($_REQUEST['second_feedback_response_long_text']))){
                $model->second_feedback_response_text = $_REQUEST['second_feedback_response_long_text'];
            }
            if(!empty($_REQUEST['second_feedback_response_integer'])){
                $model->second_feedback_response_integer = $_REQUEST['second_feedback_response_integer'];
            }
           if(!empty($_REQUEST['second_feedback_response_double'])){
                $model->second_feedback_response_double = $_REQUEST['second_feedback_response_double'];
            }
            //capturing single text option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['second_feedback_response_single_option'])){
                $model->second_feedback_response_single_option = $_REQUEST['second_feedback_response_single_option'];
                $response_counter = $response_counter +1;
            }
            if($response_counter ==0){
                if(!empty($_REQUEST['second_feedback_response_single_option_combo'])){
                        $model->second_feedback_response_single_option = $_REQUEST['second_feedback_response_single_option_combo'];
                 }
            }
             
            //capturing single numeric option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['second_feedback_response_single_option_number'])){
                $model->second_feedback_response_single_option_number = $_REQUEST['second_feedback_response_single_option_number'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter == 0){
                 if(!empty($_REQUEST['second_feedback_response_single_option_number_combo'])){
                        $model->second_feedback_response_single_option_number = $_REQUEST['second_feedback_response_single_option_number_combo'];
                }
            }
            
            
            //capturing the multiple text option feedback data
            $second_multiple_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['second_feedback_response_multiple_option_1'])){
                $second_multiple_response[] = $_REQUEST['second_feedback_response_multiple_option_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_2'])){
                $second_multiple_response[] = $_REQUEST['second_feedback_response_multiple_option_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_3'])){
                $second_multiple_response[] = $_REQUEST['second_feedback_response_multiple_option_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_4'])){
                $second_multiple_response[] = $_REQUEST['second_feedback_response_multiple_option_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_5'])){
                $second_multiple_response[] = $_REQUEST['second_feedback_response_multiple_option_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($second_multiple_response)>0){
                 $model->second_feedback_response_multiple_option = implode("+",$second_multiple_response);
                  
             }
             
             //capturing the multple text option data from a combo
             if($response_counter ==0){
                 if(!empty($_REQUEST['second_feedback_response_multiple_option_combo'])){
                        $model->second_feedback_response_multiple_option = implode("+",$_REQUEST['second_feedback_response_multiple_option_combo']);
               
                }
             }
              
            
             //capturing the multiple numeric option feedback data
            $second_multiple_numeric_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['second_feedback_response_multiple_option_number_1'])){
                $second_multiple_numeric_response[] = $_REQUEST['second_feedback_response_multiple_option_number_1'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_number_2'])){
                $second_multiple_numeric_response[] = $_REQUEST['second_feedback_response_multiple_option_number_2'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_number_3'])){
                $second_multiple_numeric_response[] = $_REQUEST['second_feedback_response_multiple_option_number_3'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_number_4'])){
                $second_multiple_numeric_response[] = $_REQUEST['second_feedback_response_multiple_option_number_4'];
                $response_counter = $response_counter +1;
             }
             if(isset($_REQUEST['second_feedback_response_multiple_option_number_5'])){
                $second_multiple_numeric_response[] = $_REQUEST['second_feedback_response_multiple_option_number_5'];
                $response_counter = $response_counter +1;
             }
             if(sizeof($second_multiple_numeric_response)>0){
                $model->second_feedback_response_multiple_option_number = implode(",",$second_multiple_numeric_response);
                $second_testing = $second_multiple_numeric_response;
                 
             }
             
             
             //capturing the multple numeric option data from a combo
             if($response_counter == 0){
                  if(!empty($_REQUEST['second_feedback_response_multiple_option_number_combo'])){
                        $model->second_feedback_response_multiple_option_number = implode(',',$_REQUEST['second_feedback_response_multiple_option_number_combo']);
               
                }
             }
            
            
            
            //treating the third feedback question
            if(isset($_REQUEST['third_feedback_response_boolean'])){
                $model->third_feedback_response_boolean = $_REQUEST['third_feedback_response_boolean'];
            }
            if((!empty($_REQUEST['third_feedback_response_text']))){
                $model->third_feedback_response_text = $_REQUEST['third_feedback_response_text'];
            }
            
             if((!empty($_REQUEST['third_feedback_response_long_text']))){
                $model->third_feedback_response_text = $_REQUEST['third_feedback_response_long_text'];
            }
            if(!empty($_REQUEST['third_feedback_response_integer'])){
                $model->third_feedback_response_integer = $_REQUEST['third_feedback_response_integer'];
            }
           if(!empty($_REQUEST['third_feedback_response_double'])){
                $model->third_feedback_response_double = $_REQUEST['third_feedback_response_double'];
            }
            //capturing single text option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['third_feedback_response_single_option'])){
                $model->third_feedback_response_single_option = $_REQUEST['third_feedback_response_single_option'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter == 0){
                if(!empty($_REQUEST['third_feedback_response_single_option_combo'])){
                    $model->third_feedback_response_single_option = $_REQUEST['third_feedback_response_single_option_combo'];
                }
            }
             
            //capturing single numeric option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['third_feedback_response_single_option_number'])){
                $model->third_feedback_response_single_option_number = $_REQUEST['third_feedback_response_single_option_number'];
                $response_counter = $response_counter +1;
            }
            
            if($response_counter == 0){
                if(!empty($_REQUEST['third_feedback_response_single_option_number_combo'])){
                        $model->third_feedback_response_single_option_number = $_REQUEST['third_feedback_response_single_option_number_combo'];
                }
            }
             
            
            //capturing the multiple text option feedback data
            $third_multiple_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['third_feedback_response_multiple_option_1'])){
                $third_multiple_response[] = $_REQUEST['third_feedback_response_multiple_option_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_2'])){
                $third_multiple_response[] = $_REQUEST['third_feedback_response_multiple_option_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_3'])){
                $third_multiple_response[] = $_REQUEST['third_feedback_response_multiple_option_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_4'])){
                $third_multiple_response[] = $_REQUEST['third_feedback_response_multiple_option_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_5'])){
                $third_multiple_response[] = $_REQUEST['third_feedback_response_multiple_option_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($third_multiple_response)>0){
                 $model->third_feedback_response_multiple_option = implode("+",$third_multiple_response);
                 
             }
             
             //capturing the multple text option data from a combo
             if($response_counter == 0){
                 if(!empty($_REQUEST['third_feedback_response_multiple_option_combo'])){
                        $model->third_feedback_response_multiple_option = implode("+",$_REQUEST['third_feedback_response_multiple_option_combo']);
               
                }
             }
              
            
             //capturing the multiple numeric option feedback data
            $third_multiple_numeric_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['third_feedback_response_multiple_option_number_1'])){
                $third_multiple_numeric_response[] = $_REQUEST['third_feedback_response_multiple_option_number_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_number_2'])){
                $third_multiple_numeric_response[] = $_REQUEST['third_feedback_response_multiple_option_number_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_number_3'])){
                $third_multiple_numeric_response[] = $_REQUEST['third_feedback_response_multiple_option_number_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_number_4'])){
                $third_multiple_numeric_response[] = $_REQUEST['third_feedback_response_multiple_option_number_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['third_feedback_response_multiple_option_number_5'])){
                $third_multiple_numeric_response[] = $_REQUEST['third_feedback_response_multiple_option_number_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($third_multiple_numeric_response)>0){
                 $model->third_feedback_response_multiple_option_number = implode(",",$third_multiple_numeric_response);
                
             }
             
             
             //capturing the multple numeric option data from a combo
             if($response_counter == 0){
                 if(!empty($_REQUEST['third_feedback_response_multiple_option_number_combo'])){
                        $model->third_feedback_response_multiple_option_number = implode(',',$_REQUEST['third_feedback_response_multiple_option_number_combo']);
                
                } 
             }
               
            
           
            //treating the fourth feedback question
            

if(isset($_REQUEST['fourth_feedback_response_boolean'])){
                $model->fourth_feedback_response_boolean = $_REQUEST['fourth_feedback_response_boolean'];
            }
            if((!empty($_REQUEST['fourth_feedback_response_text']))){
                $model->fourth_feedback_response_text = $_REQUEST['fourth_feedback_response_text'];
            }
            
            if((!empty($_REQUEST['fourth_feedback_response_long_text']))){
                $model->fourth_feedback_response_text = $_REQUEST['fourth_feedback_response_long_text'];
            }
            if(!empty($_REQUEST['fourth_feedback_response_integer'])){
                $model->fourth_feedback_response_integer = $_REQUEST['fourth_feedback_response_integer'];
            }
           if(!empty($_REQUEST['fourth_feedback_response_double'])){
                $model->fourth_feedback_response_double = $_REQUEST['fourth_feedback_response_double'];
            }
            //capturing single text option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['fourth_feedback_response_single_option'])){
                $model->fourth_feedback_response_single_option = $_REQUEST['fourth_feedback_response_single_option'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter ==0){
                if(!empty($_REQUEST['fourth_feedback_response_single_option_combo'])){
                     $model->fourth_feedback_response_single_option = $_REQUEST['fourth_feedback_response_single_option_combo'];
                }
            }
             
            //capturing single numeric option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['fourth_feedback_response_single_option_number'])){
                $model->fourth_feedback_response_single_option_number = $_REQUEST['fourth_feedback_response_single_option_number'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter == 0){
                if(!empty($_REQUEST['fourth_feedback_response_single_option_number_combo'])){
                    $model->fourth_feedback_response_single_option_number = $_REQUEST['fourth_feedback_response_single_option_number_combo'];
                }
            }
             
            
            //capturing the multiple text option feedback data
            $fourth_multiple_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_1'])){
                $fourth_multiple_response[] = $_REQUEST['fourth_feedback_response_multiple_option_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_2'])){
                $fourth_multiple_response[] = $_REQUEST['fourth_feedback_response_multiple_option_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_3'])){
                $fourth_multiple_response[] = $_REQUEST['fourth_feedback_response_multiple_option_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_4'])){
                $fourth_multiple_response[] = $_REQUEST['fourth_feedback_response_multiple_option_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_5'])){
                $fourth_multiple_response[] = $_REQUEST['fourth_feedback_response_multiple_option_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($fourth_multiple_response)>0){
                 $model->fourth_feedback_response_multiple_option = implode("+",$fourth_multiple_response);
                 
             }
             
             //capturing the multple text option data from a combo
             if($response_counter ==0){
                 if(!empty($_REQUEST['fourth_feedback_response_multiple_option_combo'])){
                        $model->fourth_feedback_response_multiple_option = implode("+",$_REQUEST['fourth_feedback_response_multiple_option_combo']);
                
                }
             }
              
            
             //capturing the multiple numeric option feedback data
            $fourth_multiple_numeric_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_number_1'])){
                $fourth_multiple_numeric_response[] = $_REQUEST['fourth_feedback_response_multiple_option_number_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_number_2'])){
                $fourth_multiple_numeric_response[] = $_REQUEST['fourth_feedback_response_multiple_option_number_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_number_3'])){
                $fourth_multiple_numeric_response[] = $_REQUEST['fourth_feedback_response_multiple_option_number_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_number_4'])){
                $fourth_multiple_numeric_response[] = $_REQUEST['fourth_feedback_response_multiple_option_number_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fourth_feedback_response_multiple_option_number_5'])){
                $fourth_multiple_numeric_response[] = $_REQUEST['fourth_feedback_response_multiple_option_number_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($fourth_multiple_numeric_response)>0){
                 $model->fourth_feedback_response_multiple_option_number = implode(",",$fourth_multiple_numeric_response);
                 
             }
             
             
             //capturing the multple numeric option data from a combo
             if($response_counter == 0){
                 if(!empty($_REQUEST['fourth_feedback_response_multiple_option_number_combo'])){
                        $model->fourth_feedback_response_multiple_option_number = implode(',',$_REQUEST['fourth_feedback_response_multiple_option_number_combo']);
                
				
               }
             }
              	
            
            
            //treating the fifth feedback question
            if(isset($_REQUEST['fifth_feedback_response_boolean'])){
                $model->fifth_feedback_response_boolean = $_REQUEST['fifth_feedback_response_boolean'];
            }
            if((!empty($_REQUEST['fifth_feedback_response_text']))){
                $model->fifth_feedback_response_text = $_REQUEST['fifth_feedback_response_text'];
            }
            
            if((!empty($_REQUEST['fifth_feedback_response_long_text']))){
                $model->fifth_feedback_response_text = $_REQUEST['fifth_feedback_response_long_text'];
            }
            if(!empty($_REQUEST['fifth_feedback_response_integer'])){
                $model->fifth_feedback_response_integer = $_REQUEST['fifth_feedback_response_integer'];
            }
           if(!empty($_REQUEST['fifth_feedback_response_double'])){
                $model->fifth_feedback_response_double = $_REQUEST['fifth_feedback_response_double'];
            }
            //capturing single text option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['fifth_feedback_response_single_option'])){
                $model->fifth_feedback_response_single_option = $_REQUEST['fifth_feedback_response_single_option'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter ==0){
                if(!empty($_REQUEST['fifth_feedback_response_single_option_combo'])){
                     $model->fifth_feedback_response_single_option = $_REQUEST['fifth_feedback_response_single_option_combo'];
                }
            }
             
            //capturing single numeric option feedback data
            $response_counter = 0;
             if(isset($_REQUEST['fifth_feedback_response_single_option_number'])){
                $model->fifth_feedback_response_single_option_number = $_REQUEST['fifth_feedback_response_single_option_number'];
                $response_counter = $response_counter + 1;
            }
            if($response_counter == 0){
                if(!empty($_REQUEST['fifth_feedback_response_single_option_number_combo'])){
                    $model->fifth_feedback_response_single_option_number = $_REQUEST['fifth_feedback_response_single_option_number_combo'];
                }
            }
             
            
            //capturing the multiple text option feedback data
            $fifth_multiple_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_1'])){
                $fifth_multiple_response[] = $_REQUEST['fifth_feedback_response_multiple_option_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_2'])){
                $fifth_multiple_response[] = $_REQUEST['fifth_feedback_response_multiple_option_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_3'])){
                $fifth_multiple_response[] = $_REQUEST['fifth_feedback_response_multiple_option_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_4'])){
                $fifth_multiple_response[] = $_REQUEST['fifth_feedback_response_multiple_option_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_5'])){
                $fifth_multiple_response[] = $_REQUEST['fifth_feedback_response_multiple_option_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($fifth_multiple_response)>0){
                 $model->fifth_feedback_response_multiple_option = implode("+",$fifth_multiple_response);
                 
             }
             
             //capturing the multple text option data from a combo
             if($response_counter ==0){
                 if(!empty($_REQUEST['fifth_feedback_response_multiple_option_combo'])){
                        $model->fifth_feedback_response_multiple_option = implode("+",$_REQUEST['fifth_feedback_response_multiple_option_combo']);
                
                }
             }
              
            
             //capturing the multiple numeric option feedback data
            $fifth_multiple_numeric_response = [];
            $response_counter = 0;
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_number_1'])){
                $fifth_multiple_numeric_response[] = $_REQUEST['fifth_feedback_response_multiple_option_number_1'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_number_2'])){
                $fifth_multiple_numeric_response[] = $_REQUEST['fifth_feedback_response_multiple_option_number_2'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_number_3'])){
                $fifth_multiple_numeric_response[] = $_REQUEST['fifth_feedback_response_multiple_option_number_3'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_number_4'])){
                $fifth_multiple_numeric_response[] = $_REQUEST['fifth_feedback_response_multiple_option_number_4'];
                $response_counter = $response_counter + 1;
             }
             if(isset($_REQUEST['fifth_feedback_response_multiple_option_number_5'])){
                $fifth_multiple_numeric_response[] = $_REQUEST['fifth_feedback_response_multiple_option_number_5'];
                $response_counter = $response_counter + 1;
             }
             if(sizeof($fifth_multiple_numeric_response)>0){
                 $model->fifth_feedback_response_multiple_option_number = implode(",",$fifth_multiple_numeric_response);
                 
             }
             
             
             //capturing the multple numeric option data from a combo
             if($response_counter == 0){
                 if(!empty($_REQUEST['fifth_feedback_response_multiple_option_number_combo'])){
                        $model->fifth_feedback_response_multiple_option_number = implode(',',$_REQUEST['fifth_feedback_response_multiple_option_number_combo']);
                
				
               }
             }
          
              
            
            if($model->isFeedbackResponseLimitReached($_REQUEST['maximum_feedback_required'],$model->template_id)== false){
                
                if($model->isThisUserLegibleToProvideFeedbackResponse($user_id,$model->template_id,$_REQUEST['is_multiple_feedback_responses_allowed'])){
                    
                       if($model->save()){
                            if($model->isRegisteringTheResponseOptionsASuccess($model)){
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" =>"As a customer-focused organization,your feedback is very valuable to us. Thank you very much",
                           
                                ));
                
                                
                            }else{
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" =>"Sorry, there was an issue trying to register your response. Please try again",
                             
                                
                                ));  
                                
                            }
                            
                
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
                    }
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"This feedback was not received. It is possible you are not legible to provide feedback on this product or service"
                        ));  
                }
                
                
                
            }else{
                
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"No more feedback is allowed on this product, service or service outlet using this feedback template as the limit had already been reached"
                        ));
            }
            
        }
        
        
        
        /**
         * This is the function that retrieves feedback response details
         */
        public function actionretrievefeedbackresponsedetails(){
            
            $user_id = Yii::app()->user->id;
                      
            $response_id = $_REQUEST['response_id'];
            $template_id = $_REQUEST['template_id'];
            //get the feedback response details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$response_id);
            $response = FeedbacksTemplateResponse::model()->find($criteria); 
            
            //get the feedback template details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$template_id);
            $template = FeedbackTemplate::model()->find($criteria); 
            
            //get the feedback template details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$template['code_id']);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            if($response===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "template" =>$template,
                                    "response"=>$response,
                                    "code"=>$code
                          
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that retrieves a template responses based on some given parameters
         */
        public function actionretrievethefeedbackresponsesofthisproject(){
           
            $model = new FeedbacksTemplateResponse;
            $project_id = $_REQUEST['project'];
            $location=$_REQUEST['location'];
            $unit = $_REQUEST['unit'];
            $issue_type =$_REQUEST['issue_type'];
            $template_id = $_REQUEST['template'];
            $question_number = $_REQUEST['issue_code'];
            $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date_modified']));
            $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date_modified']));
            $display_type = $_REQUEST['display_type'];
            
           
             if($model->isIssueTypeWithOptions($issue_type)){
                 //get the total feedback response
                $total_response = $model->getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                //retrieve the total number of each option responses for this issue
                $option_responses = $model->retrieveTheTotalNumberOfResponseForEachOption($issue_type,$template_id,$question_number,$start_date,$end_date);
                
                //get the total feedback available option 
                $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptions($issue_type,$template_id,$question_number);
            }else if($model->isIssueTypeBoolean($issue_type)){
                //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            }else{
                //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            }          
             
            //calculate the percentage responses of feedback question options
            $percentage_responses = $model->getThePercentageResponsesOfFeedbackQuestionOptions($template_id,$question_number,$total_response,$start_date,$end_date);
       
         
           
          $responses = 0;
            
             if($responses===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "total_responses"=>$total_response,
                                    "data"=>$option_responses,
                                    "total_option"=>$option_count,
                                    "percent"=>$percentage_responses,
                                    "total_option"=>sizeof($percentage_responses)
                                        
                                  
                          
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that retrieves data for analysis
         */
        public function actionretrieveresponsesforeachfeedbackoption(){
            $model = new FeedbacksTemplateResponse;
            
            $project_id = $_REQUEST['project_id'];
            $issue_type = $_REQUEST['issue_type'];
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            $start_date =date("Y-m-d H:i:s", strtotime($_REQUEST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_REQUEST['end_date']));
            
         if($model->isIssueTypeWithOptions($issue_type)){
                $data = $model->retrieveRelevantResponsesForEachOption($issue_type,$template_id,$question_number,$start_date,$end_date);
            }else if($model->isIssueTypeBoolean($issue_type)){
                //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            }else{
                //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            }
            
            if($data===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "data"=>$data,
                                  
                          
                            ));
                       
                         }
            
        }
        
        /**
         * This is the functtion that retrieves option responses with conditions
         */
        public function actionretrievethefeedbackresponseswithconditions(){
            
            $model = new FeedbacksTemplateResponse;
            $project_id = $_REQUEST['project'];
            $location=$_REQUEST['location'];
            $unit = $_REQUEST['unit'];
            $issue_type =$_REQUEST['issue_type'];
            $template_id = $_REQUEST['template'];
            $question_number = $_REQUEST['advanced_primary_issue_code'];
            $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date_modified']));
            $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date_modified']));
            $display_type = $_REQUEST['display_type'];
            //get the conditional data
            $univariate_advance_conditional_counter = $_REQUEST['univariate_advance_conditional_counter'];
            $univariate_advance_first_variable_condition = $_REQUEST['univariate_advance_first_variable_condition'];
            $univariate_advance_second_variable_condition = $_REQUEST['univariate_advance_second_variable_condition'];
            $univariate_advance_third_variable_condition = $_REQUEST['univariate_advance_third_variable_condition'];
            $univariate_advance_fourth_variable_condition = $_REQUEST['univariate_advance_fourth_variable_condition'];
            $univariate_advance_fifth_variable_condition = $_REQUEST['univariate_advance_fifth_variable_condition'];
            $univariate_advance_sixth_variable_condition = $_REQUEST['univariate_advance_sixth_variable_condition'];
            $univariate_advance_seventh_variable_condition =$_REQUEST['univariate_advance_seventh_variable_condition'];
            $univariate_advance_eighth_variable_condition = $_REQUEST['univariate_advance_eighth_variable_condition'];
            $univariate_advance_nineth_variable_condition = $_REQUEST['univariate_advance_nineth_variable_condition'];
            $univariate_advance_tenth_variable_condition = $_REQUEST['univariate_advance_tenth_variable_condition'];
            $univariate_advance_first_independent_variable_type = $_REQUEST['univariate_advance_first_independent_variable_type'];
            $univariate_advance_second_independent_variable_type = $_REQUEST['univariate_advance_second_independent_variable_type'];
            $univariate_advance_third_independent_variable_type = $_REQUEST['univariate_advance_third_independent_variable_type'];
            $univariate_advance_fourth_independent_variable_type =$_REQUEST['univariate_advance_fourth_independent_variable_type'];
            $univariate_advance_fifth_independent_variable_type = $_REQUEST['univariate_advance_fifth_independent_variable_type'];
            $univariate_advance_sixth_independent_variable_type = $_REQUEST['univariate_advance_sixth_independent_variable_type'];
            $univariate_advance_seventh_independent_variable_type = $_REQUEST['univariate_advance_seventh_independent_variable_type'];
            $univariate_advance_eighth_independent_variable_type = $_REQUEST['univariate_advance_eighth_independent_variable_type'];
            $univariate_advance_nineth_independent_variable_type = $_REQUEST['univariate_advance_nineth_independent_variable_type'];
            $univariate_advance_tenth_independent_variable_type = $_REQUEST['univariate_advance_tenth_independent_variable_type'];
            $univariate_advance_first_independent_variable_question_number = $_REQUEST['univariate_advance_first_independent_variable_question_number'];
            $univariate_advance_second_independent_variable_question_number = $_REQUEST['univariate_advance_second_independent_variable_question_number'];
            $univariate_advance_third_independent_variable_question_number = $_REQUEST['univariate_advance_third_independent_variable_question_number'];
            $univariate_advance_fourth_independent_variable_question_number =$_REQUEST['univariate_advance_fourth_independent_variable_question_number'];
            $univariate_advance_fifth_independent_variable_question_number = $_REQUEST['univariate_advance_fifth_independent_variable_question_number'];
            $univariate_advance_sixth_independent_variable_question_number = $_REQUEST['univariate_advance_sixth_independent_variable_question_number'];
            $univariate_advance_seventh_independent_variable_question_number = $_REQUEST['univariate_advance_seventh_independent_variable_question_number'];
            $univariate_advance_eighth_independent_variable_question_number = $_REQUEST['univariate_advance_eighth_independent_variable_question_number'];
            $univariate_advance_nineth_independent_variable_question_number =$_REQUEST['univariate_advance_nineth_independent_variable_question_number'];
            $univariate_advance_tenth_independent_variable_question_number = $_REQUEST['univariate_advance_tenth_independent_variable_question_number'];
            $univariate_advance_first_independent_variable_value = $_REQUEST['univariate_advance_first_independent_variable_value'];
            $univariate_advance_second_independent_variable_value = $_REQUEST['univariate_advance_second_independent_variable_value'];
            $univariate_advance_third_independent_variable_value = $_REQUEST['univariate_advance_third_independent_variable_value'];
            $univariate_advance_fourth_independent_variable_value = $_REQUEST['univariate_advance_fourth_independent_variable_value'];
            $univariate_advance_fifth_independent_variable_value = $_REQUEST['univariate_advance_fifth_independent_variable_value'];
            $univariate_advance_sixth_independent_variable_value = $_REQUEST['univariate_advance_sixth_independent_variable_value'];
            $univariate_advance_seventh_independent_variable_value = $_REQUEST['univariate_advance_seventh_independent_variable_value'];
            $univariate_advance_eighth_independent_variable_value = $_REQUEST['univariate_advance_eighth_independent_variable_value'];
            $univariate_advance_nineth_independent_variable_value = $_REQUEST['univariate_advance_nineth_independent_variable_value'];
            $univariate_advance_tenth_independent_variable_value = $_REQUEST['univariate_advance_tenth_independent_variable_value'];
            
            if($univariate_advance_conditional_counter == 0){
               if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithNoConditional($issue_type,$template_id,$question_number);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }          
             
                
                
            }else if ($univariate_advance_conditional_counter == 1){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithOneConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 2){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithTwoConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
                
                
            }else if($univariate_advance_conditional_counter == 3){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithThreeConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
                
            }else if($univariate_advance_conditional_counter == 4){
                              
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithFourConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
            }else if($univariate_advance_conditional_counter ==5){
                            
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithFiveConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 6){
                               
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithSixConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 7){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithSevenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 8){
                              
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithEightConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
               
                
            }else if($univariate_advance_conditional_counter == 9){
                               
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithNineConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }      
                
            }else if($univariate_advance_conditional_counter == 10){
                               
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response
                    $total_response = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                    //retrieve the total number of each option responses for this issue
                    $option_responses = $model->retrieveTheTotalNumberOfConditionalResponseForEachOptionWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                
                    //get the total feedback available option 
                    $option_count = $model->getTheTotalNumberOfFeedbackAvailableOptionsWithTenConditional($issue_type,$template_id,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                     //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }     
                
            }
            
           
             
       
         
           
          $responses = 0;
            
             if($responses===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "total_responses"=>$total_response,
                                    "data"=>$option_responses,
                                    "total_option"=>$option_count
                                        
                                  
                          
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that retrieves data for analysis with condition
         */
        public function actionretrieveconditionalresponsesforeachfeedbackoption(){
            $model = new FeedbacksTemplateResponse;
            
            $project_id = $_REQUEST['project_id'];
            $issue_type = $_REQUEST['issue_type'];
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            $start_date =date("Y-m-d H:i:s", strtotime($_REQUEST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_REQUEST['end_date']));
            
            //get the conditional data
            $univariate_advance_conditional_counter = $_REQUEST['univariate_advance_conditional_counter'];
            $univariate_advance_first_variable_condition = $_REQUEST['univariate_advance_first_variable_condition'];
            $univariate_advance_second_variable_condition = $_REQUEST['univariate_advance_second_variable_condition'];
            $univariate_advance_third_variable_condition = $_REQUEST['univariate_advance_third_variable_condition'];
            $univariate_advance_fourth_variable_condition = $_REQUEST['univariate_advance_fourth_variable_condition'];
            $univariate_advance_fifth_variable_condition = $_REQUEST['univariate_advance_fifth_variable_condition'];
            $univariate_advance_sixth_variable_condition = $_REQUEST['univariate_advance_sixth_variable_condition'];
            $univariate_advance_seventh_variable_condition =$_REQUEST['univariate_advance_seventh_variable_condition'];
            $univariate_advance_eighth_variable_condition = $_REQUEST['univariate_advance_eighth_variable_condition'];
            $univariate_advance_nineth_variable_condition = $_REQUEST['univariate_advance_nineth_variable_condition'];
            $univariate_advance_tenth_variable_condition = $_REQUEST['univariate_advance_tenth_variable_condition'];
            $univariate_advance_first_independent_variable_type = $_REQUEST['univariate_advance_first_independent_variable_type'];
            $univariate_advance_second_independent_variable_type = $_REQUEST['univariate_advance_second_independent_variable_type'];
            $univariate_advance_third_independent_variable_type = $_REQUEST['univariate_advance_third_independent_variable_type'];
            $univariate_advance_fourth_independent_variable_type =$_REQUEST['univariate_advance_fourth_independent_variable_type'];
            $univariate_advance_fifth_independent_variable_type = $_REQUEST['univariate_advance_fifth_independent_variable_type'];
            $univariate_advance_sixth_independent_variable_type = $_REQUEST['univariate_advance_sixth_independent_variable_type'];
            $univariate_advance_seventh_independent_variable_type = $_REQUEST['univariate_advance_seventh_independent_variable_type'];
            $univariate_advance_eighth_independent_variable_type = $_REQUEST['univariate_advance_eighth_independent_variable_type'];
            $univariate_advance_nineth_independent_variable_type = $_REQUEST['univariate_advance_nineth_independent_variable_type'];
            $univariate_advance_tenth_independent_variable_type = $_REQUEST['univariate_advance_tenth_independent_variable_type'];
            $univariate_advance_first_independent_variable_question_number = $_REQUEST['univariate_advance_first_independent_variable_question_number'];
            $univariate_advance_second_independent_variable_question_number = $_REQUEST['univariate_advance_second_independent_variable_question_number'];
            $univariate_advance_third_independent_variable_question_number = $_REQUEST['univariate_advance_third_independent_variable_question_number'];
            $univariate_advance_fourth_independent_variable_question_number =$_REQUEST['univariate_advance_fourth_independent_variable_question_number'];
            $univariate_advance_fifth_independent_variable_question_number = $_REQUEST['univariate_advance_fifth_independent_variable_question_number'];
            $univariate_advance_sixth_independent_variable_question_number = $_REQUEST['univariate_advance_sixth_independent_variable_question_number'];
            $univariate_advance_seventh_independent_variable_question_number = $_REQUEST['univariate_advance_seventh_independent_variable_question_number'];
            $univariate_advance_eighth_independent_variable_question_number = $_REQUEST['univariate_advance_eighth_independent_variable_question_number'];
            $univariate_advance_nineth_independent_variable_question_number =$_REQUEST['univariate_advance_nineth_independent_variable_question_number'];
            $univariate_advance_tenth_independent_variable_question_number = $_REQUEST['univariate_advance_tenth_independent_variable_question_number'];
            $univariate_advance_first_independent_variable_value = $_REQUEST['univariate_advance_first_independent_variable_value'];
            $univariate_advance_second_independent_variable_value = $_REQUEST['univariate_advance_second_independent_variable_value'];
            $univariate_advance_third_independent_variable_value = $_REQUEST['univariate_advance_third_independent_variable_value'];
            $univariate_advance_fourth_independent_variable_value = $_REQUEST['univariate_advance_fourth_independent_variable_value'];
            $univariate_advance_fifth_independent_variable_value = $_REQUEST['univariate_advance_fifth_independent_variable_value'];
            $univariate_advance_sixth_independent_variable_value = $_REQUEST['univariate_advance_sixth_independent_variable_value'];
            $univariate_advance_seventh_independent_variable_value = $_REQUEST['univariate_advance_seventh_independent_variable_value'];
            $univariate_advance_eighth_independent_variable_value = $_REQUEST['univariate_advance_eighth_independent_variable_value'];
            $univariate_advance_nineth_independent_variable_value = $_REQUEST['univariate_advance_nineth_independent_variable_value'];
            $univariate_advance_tenth_independent_variable_value = $_REQUEST['univariate_advance_tenth_independent_variable_value'];
            
            
             if($univariate_advance_conditional_counter == 0){
               if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithNoConditional($issue_type,$template_id,$question_number,$start_date,$end_date);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if ($univariate_advance_conditional_counter == 1){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithOneConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 2){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithTwoConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
                
            }else if($univariate_advance_conditional_counter == 3){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithThreeConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
                
            }else if($univariate_advance_conditional_counter == 4){
                              
                 if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithFourConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter ==5){
                              
                 if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithFiveConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 6){
                              
                 if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithSixConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 7){
             
              if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithSevenConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
                
            }else if($univariate_advance_conditional_counter == 8){
           
                if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithEightConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
               
                
            }else if($univariate_advance_conditional_counter == 9){
                             
                if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithNineConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 10){
                               
                 if($model->isIssueTypeWithOptions($issue_type)){
                    $data = $model->retrieveRelevantConditionalResponsesForEachOptionWithTenConditional($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }
            
         
            
            if($data===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "data"=>$data,
                                  
                          
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that returns the percentage of an option
         */
        public function actionretrieveprogressreportForThisOption(){
            $model = new FeedbacksTemplateResponse;
            $option_id = $_REQUEST['option_id'];
            //$total_responses_received = $_REQUEST['total_responses_received'];
            $option = $_REQUEST['option'];
            $issue_type = $_REQUEST['issue_type'];
            $question_number = $_REQUEST['question_number'];
            $template_id = $_REQUEST['template_id'];
            $start_date =date("Y-m-d H:i:s", strtotime($_REQUEST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_REQUEST['end_date']));
            $total_responses_received = $this->getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
            
            
           
           
            //get the percentage of response of this option
           $data = $model->getThePercentageResponseOfThisOption($option_id,$template_id,$total_responses_received,$start_date,$end_date);
            
            if($data===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "data"=>$data,
                                    "option"=>$option
                                  
                          
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that retrieves the total response of a feedback question
         */
        public function getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date){
            $model = new FeedbacksTemplateResponse;
            return $model->getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
        }
        
        
        
        
        /**
         * This is the function that returns the percentage of an option with conditions
         */
        public function actionretrieveprogressreportForThisOptionWithConditions(){
            $model = new FeedbacksTemplateResponse;
            $option_id = $_REQUEST['option_id'];
            //$total_responses_received = $_REQUEST['total_responses_received'];
            $option = $_REQUEST['option'];
            $issue_type = $_REQUEST['issue_type'];
            $question_number = $_REQUEST['question_number'];
            $template_id = $_REQUEST['template_id'];
            $start_date =date("Y-m-d H:i:s", strtotime($_REQUEST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_REQUEST['end_date']));
                    
            
            //get the conditional data
            $univariate_advance_conditional_counter = $_REQUEST['univariate_advance_conditional_counter'];
            $univariate_advance_first_variable_condition = $_REQUEST['univariate_advance_first_variable_condition'];
            $univariate_advance_second_variable_condition = $_REQUEST['univariate_advance_second_variable_condition'];
            $univariate_advance_third_variable_condition = $_REQUEST['univariate_advance_third_variable_condition'];
            $univariate_advance_fourth_variable_condition = $_REQUEST['univariate_advance_fourth_variable_condition'];
            $univariate_advance_fifth_variable_condition = $_REQUEST['univariate_advance_fifth_variable_condition'];
            $univariate_advance_sixth_variable_condition = $_REQUEST['univariate_advance_sixth_variable_condition'];
            $univariate_advance_seventh_variable_condition =$_REQUEST['univariate_advance_seventh_variable_condition'];
            $univariate_advance_eighth_variable_condition = $_REQUEST['univariate_advance_eighth_variable_condition'];
            $univariate_advance_nineth_variable_condition = $_REQUEST['univariate_advance_nineth_variable_condition'];
            $univariate_advance_tenth_variable_condition = $_REQUEST['univariate_advance_tenth_variable_condition'];
            $univariate_advance_first_independent_variable_type = $_REQUEST['univariate_advance_first_independent_variable_type'];
            $univariate_advance_second_independent_variable_type = $_REQUEST['univariate_advance_second_independent_variable_type'];
            $univariate_advance_third_independent_variable_type = $_REQUEST['univariate_advance_third_independent_variable_type'];
            $univariate_advance_fourth_independent_variable_type =$_REQUEST['univariate_advance_fourth_independent_variable_type'];
            $univariate_advance_fifth_independent_variable_type = $_REQUEST['univariate_advance_fifth_independent_variable_type'];
            $univariate_advance_sixth_independent_variable_type = $_REQUEST['univariate_advance_sixth_independent_variable_type'];
            $univariate_advance_seventh_independent_variable_type = $_REQUEST['univariate_advance_seventh_independent_variable_type'];
            $univariate_advance_eighth_independent_variable_type = $_REQUEST['univariate_advance_eighth_independent_variable_type'];
            $univariate_advance_nineth_independent_variable_type = $_REQUEST['univariate_advance_nineth_independent_variable_type'];
            $univariate_advance_tenth_independent_variable_type = $_REQUEST['univariate_advance_tenth_independent_variable_type'];
            $univariate_advance_first_independent_variable_question_number = $_REQUEST['univariate_advance_first_independent_variable_question_number'];
            $univariate_advance_second_independent_variable_question_number = $_REQUEST['univariate_advance_second_independent_variable_question_number'];
            $univariate_advance_third_independent_variable_question_number = $_REQUEST['univariate_advance_third_independent_variable_question_number'];
            $univariate_advance_fourth_independent_variable_question_number =$_REQUEST['univariate_advance_fourth_independent_variable_question_number'];
            $univariate_advance_fifth_independent_variable_question_number = $_REQUEST['univariate_advance_fifth_independent_variable_question_number'];
            $univariate_advance_sixth_independent_variable_question_number = $_REQUEST['univariate_advance_sixth_independent_variable_question_number'];
            $univariate_advance_seventh_independent_variable_question_number = $_REQUEST['univariate_advance_seventh_independent_variable_question_number'];
            $univariate_advance_eighth_independent_variable_question_number = $_REQUEST['univariate_advance_eighth_independent_variable_question_number'];
            $univariate_advance_nineth_independent_variable_question_number =$_REQUEST['univariate_advance_nineth_independent_variable_question_number'];
            $univariate_advance_tenth_independent_variable_question_number = $_REQUEST['univariate_advance_tenth_independent_variable_question_number'];
            $univariate_advance_first_independent_variable_value = $_REQUEST['univariate_advance_first_independent_variable_value'];
            $univariate_advance_second_independent_variable_value = $_REQUEST['univariate_advance_second_independent_variable_value'];
            $univariate_advance_third_independent_variable_value = $_REQUEST['univariate_advance_third_independent_variable_value'];
            $univariate_advance_fourth_independent_variable_value = $_REQUEST['univariate_advance_fourth_independent_variable_value'];
            $univariate_advance_fifth_independent_variable_value = $_REQUEST['univariate_advance_fifth_independent_variable_value'];
            $univariate_advance_sixth_independent_variable_value = $_REQUEST['univariate_advance_sixth_independent_variable_value'];
            $univariate_advance_seventh_independent_variable_value = $_REQUEST['univariate_advance_seventh_independent_variable_value'];
            $univariate_advance_eighth_independent_variable_value = $_REQUEST['univariate_advance_eighth_independent_variable_value'];
            $univariate_advance_nineth_independent_variable_value = $_REQUEST['univariate_advance_nineth_independent_variable_value'];
            $univariate_advance_tenth_independent_variable_value = $_REQUEST['univariate_advance_tenth_independent_variable_value'];
            
            
             if($univariate_advance_conditional_counter == 0){
               if($model->isIssueTypeWithOptions($issue_type)){
                   //get the total feedback response with no conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date);                
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithNoCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if ($univariate_advance_conditional_counter == 1){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response with one condition
                    $total_responses_received= $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithOneCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithOneCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 2){
                                
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response with two conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTwoCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithTwoCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
                
            }else if($univariate_advance_conditional_counter == 3){
                                
                 if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response with three conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithThreeCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value); 
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithThreeCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
                
            }else if($univariate_advance_conditional_counter == 4){
                              
                 if($model->isIssueTypeWithOptions($issue_type)){
                     //get the total feedback response with four conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFourCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithFourCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter ==5){
                              
                 if($model->isIssueTypeWithOptions($issue_type)){
                     //get the total feedback response with five conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithFiveCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithFiveCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 6){
                              
                 if($model->isIssueTypeWithOptions($issue_type)){
                     //get the total feedback response with six conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSixCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithSixCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 7){
             
              if($model->isIssueTypeWithOptions($issue_type)){
                  //get the total feedback response with seven conditions
                $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithSevenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithSevenCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
                
            }else if($univariate_advance_conditional_counter == 8){
           
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response with eight conditions
                $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithEightCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithEightCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
               
                
            }else if($univariate_advance_conditional_counter == 9){
                             
                if($model->isIssueTypeWithOptions($issue_type)){
                    //get the total feedback response with nine conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithNineCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithNineCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }else if($univariate_advance_conditional_counter == 10){
                               
                 if($model->isIssueTypeWithOptions($issue_type)){
                     //get the total feedback response with ten conditions
                    $total_responses_received = $model->getTheTotalConditionalResponseOnThisFeedbackIssueWithTenCondtions($issue_type,$template_id,$question_number,$start_date,$end_date,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
                    $data = $model->getThePercentageResponsesOfFeedbackQuestionOptionsWithTenCondition($option_id,$template_id,$total_responses_received,$start_date,$end_date,$question_number,$univariate_advance_first_variable_condition,$univariate_advance_first_independent_variable_type,$univariate_advance_first_independent_variable_question_number,$univariate_advance_first_independent_variable_value,$univariate_advance_second_variable_condition,$univariate_advance_second_independent_variable_type,$univariate_advance_second_independent_variable_question_number,$univariate_advance_second_independent_variable_value,$univariate_advance_third_variable_condition,$univariate_advance_third_independent_variable_type,$univariate_advance_third_independent_variable_question_number,$univariate_advance_third_independent_variable_value,$univariate_advance_fourth_variable_condition,$univariate_advance_fourth_independent_variable_type,$univariate_advance_fourth_independent_variable_question_number,$univariate_advance_fourth_independent_variable_value,$univariate_advance_fifth_variable_condition,$univariate_advance_fifth_independent_variable_type,$univariate_advance_fifth_independent_variable_question_number,$univariate_advance_fifth_independent_variable_value,$univariate_advance_sixth_variable_condition,$univariate_advance_sixth_independent_variable_type,$univariate_advance_sixth_independent_variable_question_number,$univariate_advance_sixth_independent_variable_value,$univariate_advance_seventh_variable_condition,$univariate_advance_seventh_independent_variable_type,$univariate_advance_seventh_independent_variable_question_number,$univariate_advance_seventh_independent_variable_value,$univariate_advance_eighth_variable_condition,$univariate_advance_eighth_independent_variable_type,$univariate_advance_eighth_independent_variable_question_number,$univariate_advance_eighth_independent_variable_value,$univariate_advance_nineth_variable_condition,$univariate_advance_nineth_independent_variable_type,$univariate_advance_nineth_independent_variable_question_number,$univariate_advance_nineth_independent_variable_value,$univariate_advance_tenth_variable_condition,$univariate_advance_tenth_independent_variable_type,$univariate_advance_tenth_independent_variable_question_number,$univariate_advance_tenth_independent_variable_value);
               }else if($model->isIssueTypeBoolean($issue_type)){
                    //$data = $model->retrieveRelevantResponsesForBooleanIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }else{
                    //$data = $model->retrieveRelevantResponsesForNumericIssue($issue_type,$template_id,$question_number,$start_date,$end_date);
                }
                
            }
           
            //get the percentage of response of this option
            //$data = $model->getThePercentageResponseOfThisOption($option_id,$template_id,$total_responses_received,$start_date,$end_date);
            
            if($data===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "data"=>$data,
                                    "total_responses_received"=>$total_responses_received
                                  
                          
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that retrieves all reponses in a feedback template
         */
        public function actionlistallresponsesinatemplate(){
            
            $model = new FeedbacksTemplateResponse;
            
            $template_id = $_REQUEST['template_id'];
            $start_date = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_REQUEST['end_date']));   
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="template_id=:tempid and (date_provided BETWEEN '$start_date' and '$end_date')";
            $criteria->params = array(':tempid'=>$template_id);
            $response = FeedbacksTemplateResponse::model()->findAll($criteria); 
            
             if($response===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "response"=>$response,
                                                            
                            ));
                       
                         }
                    
                    
            
            
        }
}
