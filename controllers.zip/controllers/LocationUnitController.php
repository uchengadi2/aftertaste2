<?php

class LocationUnitController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','modifylocationunit','addnewlocationunit','removelocationunit','listDomainAllLocationUnits',
                                    'listalllocationunits','listallunits'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that adds a new location unit
         */
        public function actionaddnewlocationunit(){
            
            $model = new LocationUnit;
            
            $model->name = $_POST['name'];
            $model->location_id = $_POST['location_id'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['has_own_terminal'])){
                $model->has_own_terminal = $_POST['has_own_terminal'];
            }else{
                 $model->has_own_terminal=0;
            }
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            $icon_error_counter = 0;
                if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;     
                   $icon_size = 0;
             
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                          
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' location unit or branch was added successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: Check your file fields for correctness";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                           $msg = "Your icon file type is not correct. Please ensure you are using a .jpg or .png image type";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
 
        }
        
        
        
        /**
         * This is the function that modifies a location unit
         */
        public function actionmodifylocationunit(){
             $_id = $_POST['id'];
             $model = LocationUnit::model()->findByPk($_id); 
             
            $model->name = $_POST['name'];
            $model->location_id = $_POST['location_id'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['has_own_terminal'])){
                $model->has_own_terminal = $_POST['has_own_terminal'];
            }else{
                 $model->has_own_terminal=0;
            }
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
            $icon_error_counter = 0;
                if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveTheExistingIconImage($_id);     
                   $icon_size = 0;
             
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                          
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' location unit or branch was successfully modified";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: Check your file fields for correctness";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                           $msg = "Your icon file type is not correct. Please ensure you are using a .jpg or .png image type";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
     
        }
	
        
        
        /**
         * This is the function that removesa location unit/department
         */
        public function actionremovelocationunit(){
            $_id = $_POST['id'];
            $model= LocationUnit::model()->findByPk($_id);
            
            //get the country name
            $location_name = $model->getThisLocationUnitName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$location_name' unit or branch was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
        }
        
        
        /**
         * This is the function that list all location units of a domain
         */
        public function actionlistDomainAllLocationUnits(){
            $model = new LocationUnit;
            $user_id = Yii::app()->user->id;
             //get the domain id of this user
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $targets = [];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $units = LocationUnit::model()->findAll($criteria);
             
             foreach($units as $unit){
                 if($this->isThisLocationUnitForThisDomain($unit['location_id'],$domain_id)){
                     $targets[] = $unit;
                 }
             }
             
             
              if($targets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "unit" => $targets
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that determines if a location unit is for a domain
         */
        public function isThisLocationUnitForThisDomain($location_id,$domain_id){
            $model = new DomainLocations;
            return $model->isThisLocationUnitForThisDomain($location_id,$domain_id);
        }
        
        
        /**
         * This is the function that list all location units
         */
        public function actionlistalllocationunits(){
            $model = new LocationUnit;
            
            $location_id = $_REQUEST['location_id'];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='location_id=:locid';
             $criteria->params = array(':locid'=>$location_id);
             $units= LocationUnit::model()->findAll($criteria);
             
              if($units===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "unit" => $units
                          
                           
                           
                          
                       ));
                       
                }
             
        }
        
        
        
        /**
         * This is the function that list all units
         */
        public function actionlistallunits(){
            $model = new LocationUnit;
            
                       
             $criteria = new CDbCriteria();
             $criteria->select = '*';
            $units= LocationUnit::model()->findAll($criteria);
             
              if($units===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "unit" => $units
                          
                           
                           
                          
                       ));
                       
                }
             
        }
}
