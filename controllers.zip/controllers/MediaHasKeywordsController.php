<?php

class MediaHasKeywordsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','getAllMediaWithDomainKeywords'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','getAllMediaWithDomainKeywords','getmedianame',
                                    'addNewKeywordParameterToMedia','updateKeywordParameterToMedia','getmedianameandkeyword',
                                    'deleteonemediaparameter'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the module that adds a new keyword to a media
         */
        public function actionaddNewKeywordParameterToMedia(){
            
            $model=new MediaHasKeywords;
            
            $model->media_id = $_POST['media_id'];
            $model->keyword_id = $_POST['keyword'];
            //get the name of this media
            $media_name = $this->getThisMediaName($model->media_id);
            if(isset($_POST['actor'])){
                $model->actor_id = $_POST['actor'];
            }
            if(isset($_POST['designation'])){
                $model->designation_id = $_POST['designation'];
            }
            if(isset($_POST['context'])){
                $model->context_id = $_POST['context'];
            }
            if(isset($_POST['frame_start_time'])){
                $model->frame_start_time = $_POST['frame_start_time'];
            }
            if(isset($_POST['frame_end_time'])){
                $model->frame_end_time = $_POST['frame_end_time'];
            }
            $model->create_user_id=Yii::app()->user->id;
            $model->create_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "Another keyword parameter added to the '$media_name' document";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error adding keyword parameter to the'$media_name' document ";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
        }
        
        /**
         * This is the function that updates the keyword parameters for a media
         */
        public function actionupdateKeywordParameterToMedia(){
            
            $_id = $_POST['id'];
            $model=  MediaHasKeywords::model()->findByPk($_id);
            
            $model->media_id = $_POST['media_id'];
            $model->keyword_id = $_POST['keyword_id'];
            //get the name of this media
            $media_name = $this->getThisMediaName($model->media_id);
            if(is_numeric($_POST['actor'])){
                $model->actor_id = $_POST['actor'];
            }else{
                $model->actor_id = $_POST['actor_id'];
            }
            if(is_numeric($_POST['designation'])){
                $model->designation_id = $_POST['designation'];
            }else{
                $model->designation_id = $_POST['designation_id'];
            }
            if(is_numeric($_POST['context'])){
                $model->context_id = $_POST['context'];
            }else{
                $model->context_id = $_POST['context_id'];
            }
            if(isset($_POST['frame_start_time'])){
                $model->frame_start_time = $_POST['frame_start_time'];
            }
            if(isset($_POST['frame_end_time'])){
                $model->frame_end_time = $_POST['frame_end_time'];
            }
            $model->update_user_id=Yii::app()->user->id;
            $model->update_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "Keyword parameters for '$media_name' document was updated successfully";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Keyword parameters for '$media_name' document was not updated";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
        }
        
        
        /**
         * This is the function that retrieves the media name and the keyword  in a media
         */
        public function actiongetmedianameandkeyword(){
            
            $id = $_REQUEST['id'];
            
            //get the media id for this media content
            $media_id = $this->getThisMediaId($id);
            
            //get the keyword id for this media content
            $keyword_id = $this->getTheKeywordId($id);
            
            //get the actor id for this media content
            $actor_id = $this->getTheActorId($id);
            
            //get the designation id for this media content
            $designation_id = $this->getTheDesignationId($id);
            
            //get the context id for this media content
            $context_id = $this->getTheContextId($id);
            
            //retrieve the media name
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$media_id);
            $media= Resources::model()->find($criteria);
            
            //retrieve the keyword 
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$keyword_id);
            $keyword= Keywords::model()->find($criteria);
            
             //retrieve the actor 
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$actor_id);
            $actor= Actors::model()->find($criteria);
            
             //retrieve the designation
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$designation_id);
            $designation= Designations::model()->find($criteria);
            
             //retrieve the context
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$context_id);
            $context= Contexts::model()->find($criteria);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "media" => $media,
                           "keyword"=>$keyword,
                           "actor"=>$actor,
                           "designation"=>$designation,
                           "context"=>$context
           
                          
                       ));
            
        }
        
        
        /**
         * get the media id given the media parameter id
         */
        public function getThisMediaId($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $media= MediaHasKeywords::model()->find($criteria);
            
            return $media['media_id'];
            
        }
        
        
         /**
         * get the keyword id given the media parameter id
         */
        public function getTheKeywordId($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $keyword= MediaHasKeywords::model()->find($criteria);
            
            return $keyword['keyword_id'];
            
        }
        
        
        /**
         * get the actor id given the media parameter id
         */
        public function getTheActorId($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $actor= MediaHasKeywords::model()->find($criteria);
            
            return $actor['actor_id'];
            
        }
        
        
        /**
         * get the designation id given the media parameter id
         */
        public function getTheDesignationId($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $designation= MediaHasKeywords::model()->find($criteria);
            
            return $designation['designation_id'];
            
        }
        
        
        /**
         * get the context id given the media parameter id
         */
        public function getTheContextId($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $context= MediaHasKeywords::model()->find($criteria);
            
            return $context['context_id'];
            
        }
        
        
        
        /**
         * This is the function that gets a media name
         */
        public function actiongetmedianame(){
            
             $media_id = $_POST['id'];
             
             //get the name of this media
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$media_id);
            $media= Resources::model()->find($criteria);
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "media" => $media
                          
                           
                           
                          
                       ));
             
        }
        
           
            /**
             * This is the function that deletes one media parameter item from a media
             */
        public function actiondeleteonemediaparameter(){
            
             $_id = $_POST['id'];
            $model=MediaHasKeywords::model()->findByPk($_id);
            //get the media id
            $media_id = $this->getThisMediaId($_id);
            //get the media name
            
            $media_name = $this->getThisMediaName($media_id);
            
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "one of '$media_name' document parameters is removed successfully"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "Validation Error: None of '$media_name' document parameters was deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
        }
            
        
      /**
       * This is the function that gets the media name
       */  
        public function getThisMediaName($id){
            
             //get the name of this media
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $media= Resources::model()->find($criteria);
            
            return $media['name'];
        }

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new MediaHasKeywords;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['MediaHasKeywords']))
		{
			$model->attributes=$_POST['MediaHasKeywords'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	
        /**
         * get all the keywords for this media
         */
        public function actiongetAllMediaWithDomainKeywords(){
            
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $media_id = $_REQUEST['id'];
            //$media_id = 2;
          
            
           //spool all the keywords for this media
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='media_id=:id';
            $criteria->params = array(':id'=>$media_id);
            $media= MediaHasKeywords::model()->findAll($criteria);
            
                if($media===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "media" => $media
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        
        
        
        
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return MediaHasKeywords the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=MediaHasKeywords::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param MediaHasKeywords $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='media-has-keywords-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
