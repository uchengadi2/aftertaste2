<?php

class PaymentController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrieveSoonToExpireToolboxes','retrieveTheEndDateForThisToolboxInThisDomain',
                                    'ListAllToolboxesForRenewal','retrieveSoonToExpireToolboxes','retrieveTheEndDateForThisToolboxInThisDomain',
                                    'ListSingleOrderItemsInCart'.'retrieveDomainDueRemittance','retrieveToolboxForRenewalInfoOnThatDomain',
                                    'isEndOfDateDeclaredForThisServiceToThisDomain','isThisToolboxServiceToThisDomainAlreadyExpired',
                                    'generateTheRandomNumber','generateTheInvoiceNumberForPayment','generateTheNeededOrderNumber','renewThisToolboxForThisDomain',
                                    'renewThisToolboxForThisDomain','obtainTheVatForThisPurchase','isPayeeDomainVatLegibleOnThisPurchase',
                                    'retrieveOrderForRenewalInfoOnThatDomain','makePaymentForThisOrderForThisDomain','retrieveAllPaymentForConfirmation',
                                    'retrieveAllToolboxForActivation','retrieveAllExpiredToolboxForDeactivation','retrieveAllToolboxForDeactivation',
                                    'getThisPaymentDetails','confirmThisPayment','getToolboxName','activateThisToolbox','deactivateThisToolbox',
                                    'retrieveDomainDueRemittance','justFunctionTesting','makeDomainDueRemittance','retrieveDomainDuePaymentsForRemittance',
                                    'includeThisPaymentForRemittance','deferThisPaymentForRemittance','processThisRemittance','getTheTotalConsumptionOfOwnToolboxAmount',
                                    'getAllDomainPaymentsId'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that implements a renewal of a toolbox
         */
        public function actionListAllToolboxesForRenewal(){
            
            //the the logged in user id
            $userid = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformRenewalSupport")){
                   //get all the toolboxes that has three months before expiration
            $to_expire = $this->retrieveAllDomainsSoonToExpireToolboxes();
            
            $alltoolboxes = [];
            foreach($to_expire as $expire){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$expire);
               $toolboxes= Resourcegroup::model()->find($criteria);
               $alltoolboxes[] = $toolboxes;
                
            }
            
            if($alltoolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" => $alltoolboxes,
                           
                          
                           
                           
                          
                       ));
                       
                }
                
            }else{
                
                //get all the toolboxes that has three months before expiration
            $to_expire = $this->retrieveSoonToExpireToolboxes($domain_id);
            
            $alltoolboxes = [];
            foreach($to_expire as $expire){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$expire);
               $toolboxes= Resourcegroup::model()->find($criteria);
               $alltoolboxes[] = $toolboxes;
                
            }
            
            if($alltoolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" => $alltoolboxes,
                           
                          
                           
                           
                          
                       ));
                       
                }
            }
            
            
        }
        
        /**
         * This is the function that retrieves soon to expire toolboxes
         */
        public function retrieveSoonToExpireToolboxes($domain_id){
          
            //retrieve the required maximum month to highlight renewal request
            $min_renewal_month = (DOUBLE)$this->retrieveThePlatformMaxRenewalMonthDiffRequired();
            //$min_renewal_month = 3;
            $alltoolboxes = [];
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='category_id=:id';
               $criteria->params = array(':id'=>$domain_id);
               $toolboxes= ResourcegroupHasResourceGroupCategory::model()->findAll($criteria);
               
               foreach($toolboxes as $toolbox){
                  //retrieve the end date of this toolbox in this domain
                  $end_month = $this->retrieveTheEndDateForThisToolboxInThisDomain($domain_id,$toolbox['resourcegroup_id'],$min_renewal_month);
                  if($end_month <=$min_renewal_month){
                      $alltoolboxes[] = $toolbox['resourcegroup_id'];
                  }else{
                      continue;
                  }
                   
               }
               
              return  $alltoolboxes;
               
               
        }
        
        
        /**
         * This is the function that retrieves soon to expire toolboxes
         */
        public function retrieveAllDomainsSoonToExpireToolboxes(){
          
            //retrieve the required maximum month to highlight renewal request
            $min_renewal_month = (DOUBLE)$this->retrieveThePlatformMaxRenewalMonthDiffRequired();
            //$min_renewal_month = 3;
            $alltoolboxes = [];
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               //$criteria->condition='category_id=:id';
               //$criteria->params = array(':id'=>$domain_id);
               $toolboxes= ResourcegroupHasResourceGroupCategory::model()->findAll($criteria);
               
               foreach($toolboxes as $toolbox){
                  
                  //confirm if this toolbox is fit for renewal
                   $end_month = $this->retrieveTheEndDateForThisToolboxInThisDomain($toolbox['category_id'],$toolbox['resourcegroup_id'],$min_renewal_month);
                  if($end_month <=$min_renewal_month){
                      $alltoolboxes[] = $toolbox['resourcegroup_id'];
                  }else{
                      continue;
                  }
                   
               }
               
              return  $alltoolboxes;
               
               
        }
      
       
        
        /**
         * This is the function that will retrieve the expiration month of this toolbox
         */
        public function retrieveTheEndDateForThisToolboxInThisDomain($domain_id,$toolbox,$min_renewal_month){
            
               $today =getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
               $day = $today['mday'];
               $month = $today['mon'];
               $year = $today['year'];
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='category_id=:id and resourcegroup_id=:toolboxid';
               $criteria->params = array(':id'=>$domain_id,':toolboxid'=>$toolbox);
               $date= ResourcegroupHasResourceGroupCategory::model()->find($criteria);
               
               $expiry = getdate(strtotime($date['max_date']));
               if((($expiry['year'] - $year) == 0) and (($expiry['mon'] - $month)<=$min_renewal_month)){
                   $month_diff = $expiry['mon'] - $month;
                   return $month_diff;
                   
               }else{
                   return ($min_renewal_month + 10);
                   
               }
              
        }
        
        /**
         * This is the function that will retrieve the maximum month to effect renewal request
         */
        public function retrieveThePlatformMaxRenewalMonthDiffRequired(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$countryid);
            $renewal_month = PlatformSettings::model()->find($criteria); 
            
            return $renewal_month['max_renewal_activation_number'];
        }
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        
        /**
         * This is the function that retrieves all payment for confirmation
         */
        public function actionretrieveAllPaymentForConfirmation(){
            
            //get the id of the logged in user
            $userid = Yii::app()->user->id;
            
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformPaymentConfirmationSupport")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformPaymentConfirmation")){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='status!=:status';
                $criteria->params = array(':status'=>"confirmed");
                $payment = Payment::model()->findAll($criteria);
                 
            if($payment===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" =>$payment
                          
                           
                           
                          
                       ));
                       
                }
                
            }
            
            
        }
        
        
        /**
         * This is the function that list all toolbox for activation
         */
        public function actionretrieveAllToolboxForActivation(){
          
            //get the logged in user
            $userid = Yii::app()->user->id;
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformToolboxActivationSupport")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformToolboxActivation")){
               
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='toolbox_status=:status';
               $criteria->params = array(':status'=>"inactive");
               $toolbox = ResourcegroupHasResourcegroupcategory::model()->findAll($criteria);
                 
            if($toolbox===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" =>$toolbox
                          
                           
                           
                          
                       ));
                       
                }
               
           }
            
            
        }
        
        /**
         * This is the function to deactivate already expired toolbox
         */
        public function actionretrieveAllExpiredToolboxForDeactivation(){
            
            $today =getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            
            //get all the unconfirmed payments which their last service dates had expired
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status!=:status';
            $criteria->params = array(':status'=>"confirmed");
            $unconfirmed= Payment::model()->findAll($criteria);
                                               
            $all_expired_service = [];
            
            foreach($unconfirmed as $unconfirm){
                
               $expiry = getdate(strtotime($unconfirm['last_service_end_date']));
               if(((($expiry['year'] - $year) <= 0) and (($expiry['mon'] - $month)<=0)) and (($expiry['mday']-$day)<=0)){
                   $all_expired_service[] = $unconfirm['id'];
                   
               }
                
            }
            
            
            $all_expired_service_toolbox = [];
            
            //spool only payments with expired services
            foreach($all_expired_service as $expired){
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='id=:id';
                $criteria1->params = array(':id'=>$expired);
                $details= Payment::model()->find($criteria1);
                
                
                //spool the resource as assigned to a particular domain
                
                $criteria2 = new CDbCriteria();
                $criteria2->select = '*';
                $criteria2->condition='resourcegroup_id=:id and category_id=:category';
                $criteria2->params = array(':id'=>$details['toolbox_id'],':category'=>$details['payee_domain_id']);
                $expired_toolbox_details= ResourcegroupHasResourceGroupCategory::model()->find($criteria2);
                
                $all_expired_service_toolbox[] = $expired_toolbox_details;
                
                
            }
            
            
              
            if($unconfirmed===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" =>$all_expired_service_toolbox
                          
                           
                           
                          
                       ));
                       
                }
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all active toolboxes for deactivation
         */
        public function actionretrieveAllToolboxForDeactivation(){
            
                //get the logged in user
            $userid = Yii::app()->user->id;
           if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformToolboxDeactivationSupport")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformToolboxDeactivation")){
               
               $criteria2 = new CDbCriteria();
                $criteria2->select = '*';
                $criteria2->condition='toolbox_status=:status';
                $criteria2->params = array(':status'=>"active");
                $toolboxes= ResourcegroupHasResourceGroupCategory::model()->findAll($criteria2);
            
                if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" =>$toolboxes
                          
                           
                           
                          
                       ));
                       
                }
               
           }
                
        }
        
        /**
         * This is the function that gets a payment detail
         */
        public function actiongetThisPaymentDetails(){
            
            $order_id = $_REQUEST['order_id'];
            $toolbox_id = $_REQUEST['toolbox_id'];
            $payee = $_REQUEST['paid_by'];
            $payee_domain = $_REQUEST['payee_domain_id'];
            
            //get the order number
            
            $order_number = $this->getOrderNumber($order_id);
            
            //get the toolbox name
            
            $toolbox_name = $this->getToolboxName($toolbox_id);
            
            //get the payee name
            
            $payee_name = $this->getPayeeName($payee);
            
            //get the payee domain name
            
            $domain_name = $this->determineDomainNameGivenItId($payee_domain);
            
            //get the platform base currency
            
            $currency_id = $this->getThePlatformBaseCurrency();
            
            //get the base currency code
            $currency_code = $this->getThisCurrencyCode($currency_id);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "order" =>$order_number,
                           "toolbox"=>$toolbox_name,
                           "payee"=>$payee_name,
                           "domainname"=>$domain_name,
                           "currency_code"=> $currency_code
                          
                           
                           
                          
                       ));
            
            
        }
            
        /**
         * This is the function that gets the order number
         */
        public function getOrderNumber($order_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order_id);
            $order= Order::model()->find($criteria);
            
            return $order['order_number'];
        }
        
        /**
         * This is the function that gets a toolbox name
         * 
         */
        public function getToolboxName($toolbox_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        /**
         * This is the function that gets the payee name
         */
        public function getPayeeName($user_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria);
            
            $name = $user['firstname'].' '. $user['middlename'] . ' '.$user['lastname'];
            
            return $name;
           
            
        }
        
        /**
         * This is the function that retrieves the platform's base currency
         */
        public function getThePlatformBaseCurrency(){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                    // $criteria->condition='country_id=:id';
                   //  $criteria->params = array(':id'=>$country_id);
                     $platform= PlatformSettings::model()->find($criteria);
                     
                     return $platform['platform_default_currency_id'];
            
        }
        
         /**
         * get the  currency code
         */
        public function getThisCurrencyCode($currency_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$currency_id);
            $currency = Currencies::model()->find($criteria); 
            
            return $currency['currency_code'];
        }
        
        
        /**
         * This is the function to effect payment confirmation
         */
        public function actionconfirmThisPayment(){
            
            $payment_id = $_POST['id'];
            $invoice_number = $_POST['invoice'];
            $domain_id = $_POST['payee_domain_id'];
            $toolbox_id = $_POST['toolbox_id'];
            $subscribers = $_POST['subscribers'];
            $number_of_years = $_POST['number_of_years'];
            $store_id = $_POST['store_id'];
            
            $toolboxname = $this->toolboxServiceName($toolbox_id);
            
            $domainname = $this->determineDomainNameGivenItId($domain_id);
            
            
            if(isset($_POST['extendifnecessary'])){
                $extendifnecessary = $_POST['extendifnecessary'];
            }else{
                $extendifnecessary = 0;
            }   
          if($extendifnecessary == 0){
              if($this->isPaymentConfirmed($payment_id)){
                //change the payment status  in the service assignment table
                if($this->isPaymentStatusChangeEffected($domain_id,$toolbox_id,$payment_id)){
                    $msg = "Payment with invoice number $invoice_number is successfully confirmed";
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       ));
                    
                }else{
                    $msg = "Payment with invoice number $invoice_number is successfully confirmed but payment status not changed";
                    $this->sendToTheSupportTeam($domain_id,$toolbox_id,$msg);
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       )); 
                }
               
            }else{
               $msg = "Payment with invoice number $invoice_number could not be confirmed";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg,
                           
                          
                       )); 
            }
              
          }else{
             if($this->isPaymentConfirmed($payment_id)){
                 if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                     if($this->ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years)){
                         if($this->isPaymentStatusChangeEffected($domain_id,$toolbox_id,$payment_id)){
                             //effect changes to any domain group that has this toolbox_id
                             $this->effectChangesToAllGroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id,$number_of_years);
                             //effect changes to any domain subgroup that has this toolbox_id
                             $this->effectChangesToAllSubgroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id,$number_of_years);
                             //effect changes to any domain user that has this toolbox
                             $this->effectChangesToAllUsersInThisDomainWithThisToolbox($toolbox_id,$domain_id,$number_of_years);
                        $msg = "Payment with invoice number $invoice_number is successfully confirmed";
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       ));
                    
                }else{
                    $msg = "Payment with invoice number $invoice_number is successfully confirmed but payment status not changed";
                    $this->sendToTheSupportTeam($domain_id,$toolbox_id,$msg);
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       )); 
                }
                         
                     }else{
                            $msg = "This $toolboxname service cold not be extended. Please contact the Service Desk";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg,
                           
                          
                       )); 
                     }
                     
                 }else{
                     //make assignment here
                     if($this->assignToolboxToDomain($toolbox_id,$domain_id,$subscribers,$store_id,$toolbox_status,$number_of_years)){
                         
                         if($this->isPaymentStatusChangeEffected($domain_id,$toolbox_id,$payment_id)){
                        $msg = "Payment with invoice number $invoice_number is successfully confirmed";
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       ));
                    
                }else{
                    $msg = "Payment with invoice number $invoice_number is successfully confirmed but payment status not changed";
                    $this->sendToTheSupportTeam($domain_id,$toolbox_id,$msg);
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       )); 
                }
                         
                         
                     }else{
                        $msg = "This $toolboxname service cold not be assigned to this domain. Please contact the Service Desk";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg,
                           
                          
                       )); 
                     }
                 }
                 
             }else{
                  $msg = "Payment with invoice number $invoice_number could not be confirmed";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg,
                           
                          
                       )); 
             } 
              
          } 
            
            
            
            
        }
        
        
            /**
             * This is the function that effects changes to domain groups with that toolbox
             */
            public function effectChangesToAllGroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id,$number_of_years){
                
               //get all the groups in this domain that has this toolbox assigned to it
                $groups = $this->getAllGroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id);
                
                //update the min and max value of this toolbox value in the group
                
                foreach($groups as $group){
                    //update the group info
                    $this->updateThisToolboxInfoInThisGroup($toolbox_id,$group,$domain_id,$number_of_years);
                }
                
               return 0;
                
            }
            
            /**
             * This is the function that effects changes to domain users with that toolbox
             */
            public function effectChangesToAllUsersInThisDomainWithThisToolbox($toolbox_id,$domain_id,$number_of_years){
                
               //get all the users in this domain that has this toolbox assigned to it directly
                $users = $this->getAllUsersInThisDomainWithThisToolbox($toolbox_id,$domain_id);
                
                //update the min and max value of this toolbox value in the group
                
                foreach($users as $user){
                    //update the group info
                    $this->updateThisToolboxInfoInThisUser($toolbox_id,$user,$domain_id,$number_of_years);
                }
                
               return 0;
                
            }
            
            
            /**
             * This is the function that gets all users in a domain with this toolbox assigned
             */
            public function getAllUsersInThisDomainWithThisToolbox($toolbox_id,$domain_id){
                
                 //get all users in this domain
                $users = $this->getAllUsersInThisDomain($domain_id);
                
               //declare an array to hold all groups with this toolbox
                $users_with_toolbox = [];
                foreach($users as $user){
                    if($this->isThisUserWithThisToolbox($toolbox_id, $user)){
                        $users_with_toolbox[] = $user;
                    }
                }
                
                return $users_with_toolbox;
            }
            
            
            /**
             * This is the function that gets all users in a domain
             */
            public function getAllUsersInThisDomain($domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $users= User::model()->findAll($criteria);
                
                $all_users = [];
                foreach($users as $user){
                    $all_users[] = $user['id'];
                }
                
                return $all_users;
                
            }
            
            
            
            /**
             * This is the function that determines if a toolbox is directly assigned to a user
             */
            public function isThisUserWithThisToolbox($toolbox_id, $user_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_resourcegroup')
                    ->where("resourcegroup_id = $toolbox_id && user_id=$user_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
            /**
             * This is the function that effects changes to domain subgroups with that toolbox
             */
            public function effectChangesToAllSubgroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id,$number_of_years){
                
                //get all the subgroups in this domain
                $subgroups = $this->getAllSubgroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id);
                
                //update the min date and max date values of this toolbox in this subgroup
                 foreach($subgroups as $group){
                    //update the group info
                    $this->updateThisToolboxInfoInThisSubgroup($toolbox_id,$group,$domain_id,$number_of_years);
                }
                
               return 0;
                
            }
            
            /**
             * This is the function that gets all subgroups in a domain
             */
            public function getAllSubgroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id){
                
                //get all groups in this domain
                $groups = $this->getAllGroupsInThisDomain($domain_id);
                
                $subgroups_with_toolbox = [];
                
                foreach($groups as $group ){
                    //rerieve all subgroups
                    $subgroups = $this->getAllSubgroupsInThisGroup($group);
                    foreach($subgroups as $subgroup){
                        if($this->isThisSubgroupWithThisToolbox($toolbox_id, $subgroup)){
                            $subgroups_with_toolbox[] = $subgroup;
                        }
                    }        
                        
           
                }
                //make the subgroup array unique
                
                return $subgroups_with_toolbox;
            }
            
            
            /**
             * This is the function that confirms if a toolbox is in a subgroup
             * 
             */
            public function isThisSubgroupWithThisToolbox($toolbox_id, $subgroup_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('subgroup_has_resourcegroup')
                    ->where("resourcegroup_id = $toolbox_id && subgroup_id=$subgroup_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            /**
             * This is the function that gets all subgroups in a group
             */
            public function getAllSubgroupsInThisGroup($group_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:id';
                $criteria->params = array(':id'=>$group_id);
                $groups= SubGroup::model()->findAll($criteria);
                
                $all_subgroups = [];
                foreach($groups as $group){
                    $all_subgroups[] = $group['id'];
                }
                
                return $all_subgroups;
                
            }
            
            
            /**
             * This is the function that gets all the groups that has a particular toolbox in domain
             */
            public function getAllGroupsInThisDomainWithThisToolbox($toolbox_id,$domain_id){
                
                //get all groups in this domain
                $groups = $this->getAllGroupsInThisDomain($domain_id);
                
               //declare an array to hold all groups with this toolbox
                $group_with_toolbox = [];
                foreach($groups as $group){
                    if($this->isThisGroupWithThisToolbox($toolbox_id, $group)){
                        $group_with_toolbox[] = $group;
                    }
                }
                
                return $group_with_toolbox;
            }
            
            
            
            /**
             * This is the function that gets all the groups in a domain
             */
            public function getAllGroupsInThisDomain($domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $groups= Group::model()->findAll($criteria);
                
                $all_groups = [];
                foreach($groups as $group){
                    $all_groups[] = $group['id'];
                }
                
                return $all_groups;
            }
            
            /**
             * This is the function that determines if a toolbox is in a group
             */
            public function isThisGroupWithThisToolbox($toolbox_id, $group_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('group_has_resourcegroup')
                    ->where("resourcegroup_id = $toolbox_id && group_id=$group_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
        
            /**
             * This is the function that updates the toolbox info in a group
             */
            public function updateThisToolboxInfoInThisGroup($toolbox_id,$group_id,$domain_id,$number_of_years){
                
                $min_date = $this->getTheMinDateFromTheToolboxInThisDomain($toolbox_id,$domain_id); 
               
                $max_date = $this->getTheMaxDateFromTheToolboxInThisDomain($toolbox_id,$domain_id);
                
                //confirm if the domain end date for this service is higer than the current end date of this service to this group
                if($this->isDomainEndDateForThisServiceIsGreaterThanThatOfThisGroup($toolbox_id,$domain_id,$group_id)){
                   $end_date = $this->getTheRealEndDateOfThisServiceToThisGroup($toolbox_id,$group_id);
                }else{
                    $end_date = $this->getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id);
                }
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('group_has_resourcegroup',
                                  array(
                                   'min_date'=>$min_date,
                                   //'start_date'=>$today,   
                                   'max_date'=>$max_date, 
                                   'end_date'=>$end_date,
                                   //'no_of_subscribers'=>$new_subscribers_base,
                                  // 'number_of_years'=>$new_number_of_years   
                           ),
                        ("resourcegroup_id=$toolbox_id and group_id=$group_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
        
            
            /**
             * This is the function that determines if domain end-date of a service is greater than that of the group
             */
            public function isDomainEndDateForThisServiceIsGreaterThanThatOfThisGroup($toolbox_id,$domain_id,$group_id){
                $domain_end_date = getdate(strtotime($this->getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id)));
                $group_end_date =  getdate(strtotime($this->getTheRealEndDateOfThisServiceToThisGroup($toolbox_id,$group_id))); 
                
                if($domain_end_date['year']>$group_end_date['year']){
                    return true;
                }else if($domain_end_date['year']<$group_end_date['year']){
                    return false;
                }else if($domain_end_date['year']=$group_end_date['year']){
                    if($domain_end_date['mon']>$group_end_date['mon']){
                        return true;
                    }else if($domain_end_date['mon']<$group_end_date['mon']){
                        return false;
                    }else if($domain_end_date['mon'] = $group_end_date['mon']){
                        if($domain_end_date['mday']>$group_end_date['mday']){
                            return true;
                        }else if($domain_end_date['mday']<$group_end_date['mday']){
                            return false;
                            
                        }else if($domain_end_date['mday']=$group_end_date['mday']){
                            return true;
                        }
                    }
                }
            }
            
            
            
            /**
             * This is the function that determines if domain end-date of a service is greater than that of the group
             */
            public function isDomainEndDateForThisServiceIsGreaterThanThatOfThisSubgroup($toolbox_id,$domain_id,$subgroup_id){
                $domain_end_date = getdate(strtotime($this->getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id)));
                $group_end_date =  getdate(strtotime($this->getTheRealEndDateOfThisServiceToThisSubgroup($toolbox_id,$subgroup_id))); 
                
                if($domain_end_date['year']>$group_end_date['year']){
                    return true;
                }else if($domain_end_date['year']<$group_end_date['year']){
                    return false;
                }else if($domain_end_date['year']=$group_end_date['year']){
                    if($domain_end_date['mon']>$group_end_date['mon']){
                        return true;
                    }else if($domain_end_date['mon']<$group_end_date['mon']){
                        return false;
                    }else if($domain_end_date['mon'] = $group_end_date['mon']){
                        if($domain_end_date['mday']>$group_end_date['mday']){
                            return true;
                        }else if($domain_end_date['mday']<$group_end_date['mday']){
                            return false;
                            
                        }else if($domain_end_date['mday']=$group_end_date['mday']){
                            return true;
                        }
                    }
                }
            }
            
            
            
            /**
             * This is the function that determines if domain end-date of a service is greater than that of the group
             */
            public function isDomainEndDateForThisServiceIsGreaterThanThatOfThisUser($toolbox_id,$domain_id,$user_id){
                $domain_end_date = getdate(strtotime($this->getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id)));
                $user_end_date =  getdate(strtotime($this->getTheRealEndDateOfThisServiceToThisUser($toolbox_id,$user_id))); 
                
                if($domain_end_date['year']>$user_end_date['year']){
                    return true;
                }else if($domain_end_date['year']<$user_end_date['year']){
                    return false;
                }else if($domain_end_date['year']=$user_end_date['year']){
                    if($domain_end_date['mon']>$user_end_date['mon']){
                        return true;
                    }else if($domain_end_date['mon']<$user_end_date['mon']){
                        return false;
                    }else if($domain_end_date['mon'] = $user_end_date['mon']){
                        if($domain_end_date['mday']>$user_end_date['mday']){
                            return true;
                        }else if($domain_end_date['mday']<$user_end_date['mday']){
                            return false;
                            
                        }else if($domain_end_date['mday']=$user_end_date['mday']){
                            return true;
                        }
                    }
                }
            }
            
             /**
             * This is the function that is used to get the end date of a toolbox service to a group
             */
            public function getTheRealEndDateOfThisServiceToThisGroup($toolbox_id,$group_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and group_id=:groupid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':groupid'=>$group_id);
                 $date= GroupHasResourcegroup::model()->find($criteria1);
                 
                 return $date['end_date'];
                 
            }
            
            /**
             * This is the function that is used to get the end date of a toolbox service to a subgroup
             */
            public function getTheRealEndDateOfThisServiceToThisSubgroup($toolbox_id,$subgroup_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and subgroup_id=:groupid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':groupid'=>$subgroup_id);
                 $date= SubgroupHasResourcegroup::model()->find($criteria1);
                 
                 return $date['end_date'];
                 
            }
            
            
            /**
             * This is the function that is used to get the end date of a toolbox service to a user
             */
            public function getTheRealEndDateOfThisServiceToThisUser($toolbox_id,$user_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and user_id=:userid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':userid'=>$user_id);
                 $date= UserHasResourcegroup::model()->find($criteria1);
                 
                 return $date['end_date'];
                 
            }
            
             /**
             * This is the function that updates the toolbox info in a subgroup
             */
            public function updateThisToolboxInfoInThisSubgroup($toolbox_id,$subgroup_id,$domain_id,$number_of_years){
                
                $min_date = $this->getTheMinDateFromTheToolboxInThisDomain($toolbox_id,$domain_id); 
                $max_date = $this->getTheMaxDateFromTheToolboxInThisDomain($toolbox_id,$domain_id);
                //confirm if the domain end date for this service is higer than the current end date of this service to this subgroup
                if($this->isDomainEndDateForThisServiceIsGreaterThanThatOfThisSubgroup($toolbox_id,$domain_id,$subgroup_id)){
                   $end_date = $this->getTheRealEndDateOfThisServiceToThisSubgroup($toolbox_id,$subgroup_id);
                }else{
                    $end_date = $this->getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id);
                }
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('subgroup_has_resourcegroup',
                                  array(
                                   'min_date'=>$min_date,
                                   //'start_date'=>$today,   
                                   'max_date'=>$max_date, 
                                   'end_date'=>$end_date,
                                   //'no_of_subscribers'=>$new_subscribers_base,
                                  // 'number_of_years'=>$new_number_of_years   
                           ),
                        ("resourcegroup_id=$toolbox_id and subgroup_id=$subgroup_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            
             /**
             * This is the function that updates the toolbox info in a subgroup
             */
            public function updateThisToolboxInfoInThisUser($toolbox_id,$user_id,$domain_id,$number_of_years){
                
                $min_date = $this->getTheMinDateFromTheToolboxInThisDomain($toolbox_id,$domain_id); 
                $max_date = $this->getTheMaxDateFromTheToolboxInThisDomain($toolbox_id,$domain_id);
                 
                 //confirm if the domain end date for this service is higer than the current end date of this service to this user
                if($this->isDomainEndDateForThisServiceIsGreaterThanThatOfThisUser($toolbox_id,$domain_id,$user_id)){
                   $end_date = $this->getTheRealEndDateOfThisServiceToThisUser($toolbox_id,$user_id);
                }else{
                    $end_date = $this->getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id);
                }
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user_has_resourcegroup',
                                  array(
                                   'min_date'=>$min_date,
                                   //'start_date'=>$today,   
                                   'max_date'=>$max_date, 
                                   'end_date'=>$end_date,
                                   //'no_of_subscribers'=>$new_subscribers_base,
                                  // 'number_of_years'=>$new_number_of_years   
                           ),
                        ("resourcegroup_id=$toolbox_id and user_id=$user_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            
            
            /**
             * This is the function that returns the new expiry date for a service in a domain
             * 
             */
            public function getTheNewExpiryDateForThisServiceToThisDomain($toolbox_id,$domain_id,$number_of_years){
                
                
                 //get the number of years of subscription
              //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                //confirm if service exist for a domain
                if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                    //confirm if end of date is declared for this service to this domain
                    if($this->isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id)){
                        //get the end_date for the service to this domain
                        $end_date = getdate(strtotime($this->getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id)));
                        $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                        if($end_date['year'] -$today['year']<=0 ){
                            if($end_date['mon']- $today['mon']<=0 ){
                                if(($end_date['mday']- $today['mday']<=0 )){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mon']- $today['mon']<=0){
                                   $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years));  
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }
                        }else{
                            $year_diff = $end_date['year'] -$today['year'];
                            if($end_date['mon']- $today['mon']<=0){
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                   $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }
                        }
                       // extend the value of the service by the new date value
                        $new_expiry_date = date("Y-m-d", $new_end_date);
                        
                       return $new_expiry_date;
                        
                    }
                }
                
            }
            
        
            /**
             * This is the function that gets the min date of a toolbox assigned to a domain
             */
            public function getTheMinDateFromTheToolboxInThisDomain($toolbox_id,$domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id and category_id=:catid';
                $criteria->params = array(':id'=>$toolbox_id,':catid'=>$domain_id);
                $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                
                return $date['min_date'];
            }
            
            
            /**
             * This is the function that gets the max date of a toolbox assigned to a domain
             */
            public function getTheMaxDateFromTheToolboxInThisDomain($toolbox_id,$domain_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id and category_id=:catid';
                $criteria->params = array(':id'=>$toolbox_id,':catid'=>$domain_id);
                $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                
                return $date['max_date'];
            }
        /**
         * This is the function that changes the payment status a domain service
         */
        public function isPaymentStatusChangeEffected($domain_id,$toolbox_id,$payment_id){
            
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                         array('payment_id'=>$payment_id
                             ),
                           "category_id=$domain_id && resourcegroup_id=$toolbox_id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that actually confirmed payments
         */
        public function isPaymentConfirmed($id){
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('payment',
                         array('status'=>"confirmed",
                             'payment_confirmed_by'=>Yii::app()->user->id,
                             'date_of_confirmation'=>new CDbExpression('NOW()')),
                           "id=$id"
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function that gets toolbox and payment info
         */
        public function actiongetToolboxName(){
            
            $toolbox_id = $_REQUEST['toolbox_id'];
            $domain_id = $_REQUEST['domain_id'];
            $payment_id = $_REQUEST['payment_id'];
            
           
            //get the toolbox name
            
            $toolbox_name = $this->getToolboxName($toolbox_id);
            
            //get the domain name
            $domain_name = $this->determineDomainNameGivenItId($domain_id);
            
            //payment status of this toolbox 
            $payment_status = $this->getThePaymentStatusOfThisToolbox($payment_id);
            
            //$msg = "Payment with invoice number $invoice_number is successfully confirmed";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolbox" =>$toolbox_name,
                           "domain"=>$domain_name,
                          "payment_status"=>$payment_status
                           
                          
                       ));
            
            
            
        }
        
        /**
         * This is the function that retrieves the payment status of this toolbox
         */
        public function getThePaymentStatusOfThisToolbox($payment_id){
            
                    $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='id=:id';
                     $criteria->params = array(':id'=>$payment_id);
                     $payment= Payment::model()->find($criteria);
                     
                     return $payment['status'];
            
            
        }
        
        /**
         * This is the function that activates a toolbox for a domain
         */
        public function actionactivateThisToolbox(){
            
            $toolbox_id = $_POST['toolbox_id'];
            $domain_id = $_POST['domain_id'];
            
            //domain name is 
            $domainname = $this->determineDomainNameGivenItId($domain_id);
            
            //toolbox name is 
            $toolboxname = $this->getToolboxName($toolbox_id);
            
            if($this->isThisToolboxServiceActivated($toolbox_id,$domain_id)){
                $msg = "'$toolboxname' service is activated for '$domainname' domain";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       ));
                
            }else{
                $msg = "Activation of '$toolboxname' service for '$domainname' domain was not successful  ";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg,
                           
                          
                       )); 
            }
            
        }
        
        /**
         * This is the function that does the actual activation
         */
        public function isThisToolboxServiceActivated($toolbox_id,$domain_id){
            
            //get the numbe of years of subscription
            $number_of_years = $this->getTheNumberOfYearsOfSubscription($toolbox_id,$domain_id);
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            //get the number of years of this subscription
            $year_later = mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years);
            
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                         array('toolbox_status'=>"active",
                              'start_date'=>date("Y-m-d",$today),
                              'min_date'=>date("Y-m-d",$today),
                               'end_date'=>date("Y-m-d",$year_later),
                               'max_date'=>date("Y-m-d",$year_later),
                             'service_activated_by'=>Yii::app()->user->id,
                             'date_of_activation'=>new CDbExpression('NOW()')
                             ),
                             ("resourcegroup_id=$toolbox_id and category_id=$domain_id")
                           
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that gets the year of subscription
         */
        public function getTheNumberOfYearsOfSubscription($toolbox_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='resourcegroup_id=:id and category_id=:categoryid';
            $criteria->params = array(':id'=>$toolbox_id,':categoryid'=>$domain_id);
            $subscription = ResourcegroupHasResourcegroupcategory::model()->find($criteria);
                 
            return $subscription['number_of_years'];
            
        }
        
        /**
         * This is the function that deactivates a toolbox service to a domain
         */
        public function actiondeactivateThisToolbox(){
            
            $toolbox_id = $_POST['toolbox_id'];
            $domain_id = $_POST['domain_id'];
            
             
            //domain name is 
            $domainname = $this->determineDomainNameGivenItId($domain_id);
            
            //toolbox name is 
            $toolboxname = $this->getToolboxName($toolbox_id);
            
            if($this->isThisToolboxServiceDeActivated($toolbox_id,$domain_id)){
                $msg = "'$toolboxname' service is deactivated for '$domainname' domain";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg,
                           
                          
                       ));
                
            }else{
                $msg = "Deactivation of '$toolboxname' service for '$domainname' domain was not successful  ";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg,
                           
                          
                       )); 
            }
            
            
            
        }
        
        /**
         * This is the function that does the actual toolbox service deactivation
         */
        public function isThisToolboxServiceDeActivated($toolbox_id,$domain_id){
            
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                         array('toolbox_status'=>"inactive",
                             'service_deactivated_by'=>Yii::app()->user->id,
                             'date_of_deactivation'=>new CDbExpression('NOW()')
                             ),
                             ("resourcegroup_id=$toolbox_id and category_id=$domain_id")
                           
                     );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that retrieves the current reciepts of a domain 
         */
        public function actionretrieveDomainDueRemittance(){
            
            //get the logged in user
            $user_id = Yii::app()->user->id;
            
            //get this user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //detetmine the beneficiary name
            
            $beneficiary = $this->determineDomainNameGivenItId($domain_id);
            
            //determine the amount accruable from own toolbox consumption
            $total_own_toolbox_amount = $this->getTheTotalConsumptionOfOwnToolboxAmount($domain_id);
            
            //determine the amount of own standalone tools amount
           // $total_standalone_tools_amount = $this->getTheTotalConsumptionOfStandaloneToolAmount($domain_id);
            
            //determine the amount of own standalone task amount
            
           // $total_standalone_task_amount = $this->getTheTotalConsumptionOfStandaloneTaskAmount($domain_id);
            
            //determine the total users of toolboxes
            
            $total_users = $this->getTheTotalUsersOfToolboxes($domain_id);
            
            //determine the total discount granted
            
            $total_discount_granted = $this->getTheTotalDiscountGrantedByDomain($domain_id);
            
            //determine the applicable vats on the consumption of domain services
            $total_applicable_vat = $this->getTheTotalApplicableVat($domain_id);
            
            //determmine the estimated date of remittance
            
            $date_of_remittance = $this->getTheEstimatedDateOfRemittance($domain_id);
            
            //determine the mode of remittance
            
            $mode_of_remittance = $this->getTheModeOfRemittance($domain_id);
            
            //determine the currency of remittance
            $currency_of_remittance = $this->getTheCurrencyOfRemittance();
            
            //determine the amount to be remitted
            
            $amount_to_be_remitted = $this->getTheAmountTobeRemitted($total_own_toolbox_amount,$total_discount_granted);
            
            //get the beneficiary bank number
            
            $beneficiary_bank_name = $this->getTheBeneficiaryBankName($domain_id);
            
            //get the beneficiary account number
            
            $beneficairy_account_number = $this->getTheBeneficiaryAccountNumber($domain_id);
            
            //get the beneficiary account type
            
            $beneficiary_account_type = $this->getTheBeneficiaryAccountType($domain_id);
            
            //get the beneficiary account title
            $beneficairy_account_title = $this->getTheBeneficiaryAccountTitle($domain_id);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domain" =>$beneficiary,
                           "toolboxes_accruable"=>$total_own_toolbox_amount,
                         // "tools_accruable"=>$total_standalone_tools_amount,
                          // "tasks_accruable"=>$total_standalone_task_amount,
                           "total_users"=>$total_users,
                           "vat"=>$total_applicable_vat,
                           "total_discount_granted"=>$total_discount_granted,
                           "remittance_date"=>$date_of_remittance,
                          "remittance_amount"=>$amount_to_be_remitted,
                           "remittance_currency"=>$currency_of_remittance,
                           "remittance_mode"=>$mode_of_remittance,
                           "bank_name"=>$beneficiary_bank_name,
                           "account_title"=>$beneficairy_account_title,
                           "account_type"=>$beneficiary_account_type,
                           "account_number"=>$beneficairy_account_number
                           
                          
                       ));
            
                    
                    
            
        }
        
        /**
         * This is the function that gets the total consumption of own toolboxes
         */
        public function getTheTotalConsumptionOfOwnToolboxAmount($domain_id){
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            
            //get the platform revenue share percentage
            $platform_share = $this->getThePlatformRevenueSharePercentage();
            
            //get the domain share
            
            $domain_share = (double)((100 - $platform_share)/100);
            
            $accruable_toolboxes_amount = $this->getAccruableDomainToolboxesAmountInThisPeriod($month,$year,$day,$domain_id);
            
            $net_platform_revenue = (double)$accruable_toolboxes_amount * (double)$domain_share;
            
            return $net_platform_revenue;
           
        }
        
        
        /**
         * This is the function that gets the platform revenue share
         */
        public function getThePlatformRevenueSharePercentage(){
            
            //retrieve the platform revenue share
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
            return $platform['platform_revenue_share'];
            
        }
        
        /**
         * This is the function that gets the payment holding period
         */
        public function getThePlatformHoldingPeriod(){
            
            //retrieve the platform payment holding period
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
            return $platform['payment_holding_period'];
            
        }
        
        /**
         * This is the function that does the toolboxes net amount additions for a domain within a period
         */
        public function getAccruableDomainToolboxesAmountInThisPeriod($month,$year,$day,$domain_id){
            
            $total_amount =0;
            //get all the payments accruable to this domain
            $payments = $this->getAllDomainPaymentsId($domain_id);
            
            //retrieve the platform holding period
            $holding_period = $this->getThePlatformHoldingPeriod();
            
            foreach($payments as $payment){
              if($this->isPaymentServiceNotPrivateToThisDomain($payment,$domain_id)){
                  if($this->isPaymentWithinTheGivenPeriod($payment,$month,$year,$day,$holding_period)){
                
                 $total_amount = $total_amount + (double)$this->getTheAmountForThisPayment($payment);
               }
              }  
               
                
            }
            return $total_amount;
           
        }
        
        
        /**
         * This is the function that confirms that a payment service is not private to this domain
         */
        public function isPaymentServiceNotPrivateToThisDomain($payment_id,$domain_id){
            
            if($this->isThisPaymentForThisDomainService($payment_id,$domain_id)){
                 //get the service paid for
                $toolbox_service_id = $this->getTheToolboxServicePaidFor($payment_id);
                if($this->isThisServicePrivateToThisDomain($toolbox_service_id,$domain_id)){
                    return false;
                }else{
                    return true;
                }
                
                
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that determines if a service is private to a domain
         */
        public function isThisServicePrivateToThisDomain($toolbox_id,$domain_id){
            
            //retrieve the platform payment holding period
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and domain_id=:domainid';
            $criteria->params = array(':id'=>$toolbox_id,':domainid'=>$domain_id);
            $service = Resourcegroup::model()->find($criteria); 
            
            if($service['visibility']== 'private' || $service['visibility']=='private & public' || $service['visibility']== 'private & restricted_public'){
                return true;
            }else{
                return false;
            }
            
        } 
        
        
        
        /**
         * This is the function that gets all payments made for this domain
         */
        public function getAllDomainPaymentsId($domain_id=14){
            
           
            $all_domain_payment = [];
            $all_payments = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'confirmed');
            $payments = Payment::model()->findAll($criteria); 
            
            foreach($payments as $payment){
                $all_payments[] = $payment['id'];
            }
          
           // return $all_payments;
            
            //determine that the toolbox service in question is for this domain
           foreach($all_payments as $payment){
                if($this->isThisPaymentForThisDomainService($payment,$domain_id)){
                    $all_domain_payment[] = $payment;
                }
           }
          return $all_domain_payment;
          /** header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "all_payment" => $all_domain_payment,
                          
              ));   
           * 
           */          
        }
        
        
        /**
         * This is the function that determines if a payment is for a particular domain service
         */
        public function isThisPaymentForThisDomainService($payment_id,$domain_id){
            
            //get the service paid for
            $toolbox_service_id = $this->getTheToolboxServicePaidFor($payment_id);
            //confirm if this service belongs to this domain
            if($this->isthisDomainTheOwnerOfThisToolboxService($toolbox_service_id,$domain_id)){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that confirms if a domain is the owner of a toolbox service
         */
        public function isthisDomainTheOwnerOfThisToolboxService($toolbox_service_id,$domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_service_id);
            $service = Resourcegroup::model()->find($criteria); 
            
            if($service['domain_id'] == $domain_id){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that returns the id of the toolbox service paid for
         */
        public function getTheToolboxServicePaidFor($payment_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$payment_id);
            $payments = Payment::model()->find($criteria); 
            
            return $payments['toolbox_id'];
        }
        
        /**
         * This is the function that gets the amount for an actual domain payment
         */
        public function getTheAmountForThisPayment($payment_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and status=:status and remit_status=:remit';
            $criteria->params = array(':id'=>$payment_id,':status'=>'confirmed',':remit'=>'unprocessed');
            $payments = Payment::model()->find($criteria); 
            
            return $payments['net_amount'];
        }
        
        /**
         * This is the function that determines if a payment is within a period
         */
        public function isPaymentWithinTheGivenPeriod($payment_id,$month,$year,$day,$holding_period){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(id=:id and status=:status) and (remit_status!=:defer or remit_status!=:process)';
            $criteria->params = array(':id'=>$payment_id,':status'=>'confirmed',':defer'=>'deferred',':process'=>'processed');
            $payments = Payment::model()->find($criteria); 
            
            $payment_date = getdate(strtotime($payments['payment_date']));
            
           if(($payment_date['year']==$year ||$payment_date['year']==($year-1)) && ($payment_date['mon'] == $month ||$payment_date['mon'] == ($month-1)) ){
              //if(($payment_date['mday']+$day)>=$holding_period){
               if($this->isPaymentMatureToBeRemitted($payment_date['mday'],$day, $holding_period)){
                  return true;
              }else{
                  return false;
              } 
               
           }else{
               return false;
           }
            
        }
        
        
        /**
         * This is the function that determines if payment is mature for remission
         */
        public function isPaymentMatureToBeRemitted($payment_day,$today, $holding_period){
            
            $remaining_days = 31 - $payment_day;
                $transaction_period = $remaining_days + $today;
                if($transaction_period >= $holding_period){
                    return true;
                }else{
                    return false;
                }
            
            
        }
        
        
        
        /**
         * This is the function that gets  the total users that subscribed to domain toolboxes in a period
         */
        public function getTheTotalUsersOfToolboxes($domain_id){
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            //get the platform holding period
            
            $holding_period = $this->getThePlatformHoldingPeriod();
                       
            $total_subscribers = $this->getTotalSubscribersOnDomainToolboxesInThisPeriod($month,$year,$day,$holding_period,$domain_id);
           
            return  $total_subscribers;
            
        }
        
        /**
         * This is the function that gets the to subscribers
         */
        public function getTotalSubscribersOnDomainToolboxesInThisPeriod($month,$year,$day,$holding_period,$domain_id){
            
            $total_subscribers =0;
            //get all the payments accruable to this domain
            $payments = $this->getAllDomainPaymentsId($domain_id);
            
            foreach($payments as $payment){
              if($this->isPaymentServiceNotPrivateToThisDomain($payment,$domain_id)){
                  if($this->isPaymentWithinTheGivenPeriod($payment,$month,$year,$day,$holding_period)){
                
                    $total_subscribers = $total_subscribers + $this->getTheTotalSubscribersForThisPayment($payment);
                }
              } 
                
                
            }
            return $total_subscribers;
            
            
        }
        
        /**
         * This is the function that gets the actual total subscribers on a payment period
         */
        public function getTheTotalSubscribersForThisPayment($payment_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and status=:status and remit_status=:remit';
            $criteria->params = array(':id'=>$payment_id,':status'=>'confirmed',':remit'=>'unprocessed');
            $payments = Payment::model()->find($criteria); 
            
            return $payments['subscribers'];
            
        }
        
        /**
         * This is the function that gets the total discount granted by a domain within a period
         */
        public function getTheTotalDiscountGrantedByDomain($domain_id){
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            
             //get the holding period
            $holding_period = $this->getThePlatformHoldingPeriod();
            $total_discount_granted = $this->getTotalDomainDiscountAmountInThisPeriod($month,$year,$day,$holding_period,$domain_id);
            
            
                     
            return $total_discount_granted;          
            
        }
        
        /**
         * This is the function that gets the total domain discount within a period
         */
        public function getTotalDomainDiscountAmountInThisPeriod($month,$year,$day,$holding_period,$domain_id){
            
            $total_discount_amount =0;
            //get all the payments accruable to this domain
            $payments = $this->getAllDomainPaymentsId($domain_id);
            
            foreach($payments as $payment){
               if($this->isPaymentWithinTheGivenPeriod($payment,$month,$year,$day,$holding_period)){
                
                 $total_discount_amount = $total_discount_amount + (double)$this->getTheDomainDiscountForThisPayment($payment);
             }
                
            }
            return $total_discount_amount;
            
        }
        
        
        /**
         * This is the function that retrieves the discount for a payment
         */
        public function getTheDomainDiscountForThisPayment($payment_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and status=:status and remit_status=:remit';
            $criteria->params = array(':id'=>$payment_id,':status'=>'confirmed',':remit'=>'unprocessed');
            $payments = Payment::model()->find($criteria); 
            
            return $payments['discounted_amount'];
        }
        
        
        /**
         * This is the function that retrieves the applicable vat in a period
         */
        public function getTheTotalApplicableVat($domain_id){
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            
            //get the platform holding period
            
            $holding_period = $this->getThePlatformHoldingPeriod();
            $total_vat_applicable = $this->getTotalDomainVatApplicableInThisPeriod($month,$year,$day,$holding_period,$domain_id);
            
                     
            return $total_vat_applicable;          
            
        }
        
        
        /**
         * This is the function that gets the total applicable vats in a period
         */
        public function getTotalDomainVatApplicableInThisPeriod($month,$year,$day,$holding_period,$domain_id){
            
            $total_vat_applicable =0;
            //get all the payments accruable to this domain
            $payments = $this->getAllDomainPaymentsId($domain_id);
            
            foreach($payments as $payment){
               if($this->isPaymentWithinTheGivenPeriod($payment,$month,$year,$day,$holding_period)){
                
                 $total_vat_applicable = $total_vat_applicable + (double)$this->getTheDomainVatForThisPayment($payment);
             }
                
            }
            return $total_vat_applicable;
            
        }
        
        
        /**
         * This is the function thats get applicable vat on a transaction
         */
        public function getTheDomainVatForThisPayment($payment_id){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and status=:status and remit_status=:remit';
            $criteria->params = array(':id'=>$payment_id,':status'=>'confirmed',':remit'=>'unprocessed');
            $payments = Payment::model()->find($criteria); 
            
            return $payments['vat']; 
            
            
        }
        
        
        /**
         * This is the function that retrieves the estimated date of payment to a domain
         */
        public function getTheEstimatedDateOfRemittance($domain_id){
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
          
                $estimated_date = date("d-m-Y",mktime(0, 0, 0, date("m") , date("d"), date("Y")));
                         
               return $estimated_date;
    
        }
        
        
       /**
        * This is the function that provides the mode of remittance
        */
        public function getTheModeOfRemittance($domain_id){
            
            $mode = "Bank Transfer";
            return $mode;
        }
        
        
        /**
         * This is the function that provides the currency of remittance
         */
        public function getTheCurrencyOfRemittance(){
            $currency = "USD($)";
            
            return $currency;
        }
        
        /**
         * This is the function the calculates the total amount to be remitted
         */
        public function getTheAmountTobeRemitted($total_own_toolbox_amount,$total_discount_granted){
            
             //get the platform revenue share percentage
            $platform_share = $this->getThePlatformRevenueSharePercentage();
            
            //get the domain share
            
            $domain_share = (double)((100 - $platform_share)/100);
            
            $applicable_discount = $domain_share * $total_discount_granted;
            
            $total_amount = $total_own_toolbox_amount - $applicable_discount ;
            
            return $total_amount;
        }
        
        
        /**
         * This is the function that provides the beneficiary's bank
         * 
         */
        public function getTheBeneficiaryBankName($domain_id){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $domain = ResourceGroupCategory::model()->find($criteria); 
            
            return $domain['bank_name'];  
            
        }
        
        /**
         * This is the function that beneficiary's account number
         */
        public function getTheBeneficiaryAccountNumber($domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $domain = ResourceGroupCategory::model()->find($criteria); 
            
            return $domain['account_number'];  
        }
        
        
        /**
         * This is the function that gets the beneficiary's account type
         */
        public function getTheBeneficiaryAccountType($domain_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $domain = ResourceGroupCategory::model()->find($criteria); 
            
            return $domain['account_type'];  
            
        }
        
        
        /**
         * This is the function that gets the beneficiary's account title
         */
        public function getTheBeneficiaryAccountTitle($domain_id){
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $domain = ResourceGroupCategory::model()->find($criteria); 
            
            return $domain['account_title'];  
            
            
        }
        
       /**
        * This is the function that process payment for remittance to the domain
        */ 
        public function actionmakeDomainDueRemittance(){
            
            $domain_id = $_REQUEST['domain_id'];
            
            //detetmine the beneficiary name
            
            $beneficiary = $this->determineDomainNameGivenItId($domain_id);
            
            //determine the amount accruable from own toolbox consumption
            $total_own_toolbox_amount = $this->getTheTotalConsumptionOfOwnToolboxAmount($domain_id);
            
            //determine the amount of own standalone tools amount
           // $total_standalone_tools_amount = $this->getTheTotalConsumptionOfStandaloneToolAmount($domain_id);
            
            //determine the amount of own standalone task amount
            
           // $total_standalone_task_amount = $this->getTheTotalConsumptionOfStandaloneTaskAmount($domain_id);
            
            //determine the total users of toolboxes
            
            $total_users = $this->getTheTotalUsersOfToolboxes($domain_id);
            
            //determine the total discount granted
            
            $total_discount_granted = $this->getTheTotalDiscountGrantedByDomain($domain_id);
            
            //determine the applicable vats on the consumption of domain services
            $total_applicable_vat = $this->getTheTotalApplicableVat($domain_id);
            
            //determmine the estimated date of remittance
            
            $date_of_remittance = $this->getTheEstimatedDateOfRemittance($domain_id);
            
            //determine the mode of remittance
            
            $mode_of_remittance = $this->getTheModeOfRemittance($domain_id);
            
            //determine the currency of remittance
            $currency_of_remittance = $this->getTheCurrencyOfRemittance();
            
            //determine the amount to be remitted
            
           $amount_to_be_remitted = $this->getTheAmountTobeRemitted($total_own_toolbox_amount,$total_discount_granted);
            
            //get the beneficiary bank number
            
            $beneficiary_bank_name = $this->getTheBeneficiaryBankName($domain_id);
            
            //get the beneficiary account number
            
            $beneficairy_account_number = $this->getTheBeneficiaryAccountNumber($domain_id);
            
            //get the beneficiary account type
            
            $beneficiary_account_type = $this->getTheBeneficiaryAccountType($domain_id);
            
            //get the beneficiary account title
            $beneficairy_account_title = $this->getTheBeneficiaryAccountTitle($domain_id);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domain" =>$beneficiary,
                           "toolboxes_accruable"=>$total_own_toolbox_amount,
                         // "tools_accruable"=>$total_standalone_tools_amount,
                          // "tasks_accruable"=>$total_standalone_task_amount,
                           "total_users"=>$total_users,
                           "vat"=>$total_applicable_vat,
                           "total_discount_granted"=>$total_discount_granted,
                           "remittance_date"=>$date_of_remittance,
                          "remittance_amount"=>$amount_to_be_remitted,
                           "remittance_currency"=>$currency_of_remittance,
                           "remittance_mode"=>$mode_of_remittance,
                           "bank_name"=>$beneficiary_bank_name,
                           "account_title"=>$beneficairy_account_title,
                           "account_type"=>$beneficiary_account_type,
                           "account_number"=>$beneficairy_account_number
                           
                          
                       ));
            
                    
            
        }
        
        /**
         * This is the function that retrieves all confirmed but unprocessed payment due for remittance
         */
        public function actionretrieveDomainDuePaymentsForRemittance(){
            
           $domain_id = $_REQUEST['domain_id'];
            
            //$domain_id = 1;
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            //get all the payments accruable to this domain
            $payments = $this->getAllDomainPaymentsId($domain_id);
            
            //retrieve the platform holding period
            $holding_period = $this->getThePlatformHoldingPeriod();
            
            $due_for_remittance = [];
            
            foreach($payments as $payment){
               if($this->isPaymentWithinTheGivenPeriod($payment,$month,$year,$day,$holding_period)){
                
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='id=:id and status=:status';
                 $criteria->params = array(':id'=>$payment,':status'=>'confirmed');
                 $payments = Payment::model()->find($criteria); 
                 
                 $due_for_remittance[] = $payments;
                 
               }
                
            }
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "payment" =>$due_for_remittance
                         
                          
                       ));
            
            
        }
        
        
        /**
         * This is the function that defers a payment for remittance
         */
        public function actiondeferThisPaymentForRemittance(){
            
            $domain_id = $_POST['payee_domain_id'];
            $toolbox_id = $_POST['toolbox_id'];
            $order_id = $_POST['order_id'];
            $payment_id  = $_POST['id'];
            $reason = $_POST['reason_for_deferment'];
            
            $toolboxname = $this->getToolboxname($toolbox_id);
            
            if($this->isRemittanceDeferredOnThisPayment($payment_id,$reason)){
                $msg = "'$toolboxname' item is deferred in this currenct remittance cycle";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg
                         
                          
                       ));
                
            }else{
                $msg = "Could not defer the '$toolboxname' item from the current remittance cycle";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg
                         
                          
                       ));
            }
            
            
            
        }
        
        
        /**
         * This is a function that includes a payment for remittance
         */
        public function actionincludeThisPaymentForRemittance(){
            
            $domain_id = $_POST['payee_domain_id'];
            $toolbox_id = $_POST['toolbox_id'];
            $order_id = $_POST['order_id'];
            $payment_id  = $_POST['id'];
            $reason = $_POST['reason_for_undeferment'];
            
            $toolboxname = $this->getToolboxname($toolbox_id);
            
            if($this->isThisPaymentAlreadyIncludedInRemitance($payment_id,$reason)){
                $msg = "'$toolboxname' item is included in the current remittance cycle";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg
                         
                          
                       ));
                
            }else{
                $msg = "Could not include the '$toolboxname' item in the current remittance cycle";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg
                         
                          
                       ));
            }
            
            
            
        }
        
        /**
         * This is the function that make the deferment of remittance of payment
         */
        public function isRemittanceDeferredOnThisPayment($payment_id,$reason){
            
            if($this->isPaymentNotAlreadyProcessed($payment_id)){
                if($this->isThisPaymentNotAlreadyDeferred($payment_id)){
                    
                    if($this->effectTheDefermentOfThisPayment($payment_id,$reason)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
        
       
        /**
         * This is the function that confirms if payment had not already been processed
         */
        public function isPaymentNotAlreadyProcessed($payment_id){
            
             $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('payment')
                    ->where("id = $payment_id and remit_status = 'processed'");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that confirms if a payment had not already been defered
         */
        public function isThisPaymentNotAlreadyDeferred($payment_id){
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('payment')
                    ->where("id = $payment_id and remit_status = 'deferred'");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that effect the deferment of payment
         */
        public function effectTheDefermentOfThisPayment($payment_id,$reason){
            
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('payment',
                                  array(
                                    'remit_status'=>"deferred",
                                     'reason_for_deferment'=>$reason,
                                      'deferment_effected_by'=>Yii::app()->user->id,
                                      'date_of_deferment'=>new CDbExpression('NOW()')
                                  
                           ),
                        ("id=$payment_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
         
       
        
            /**
             * This is the function that includes a payment in remittance
             */
            public function isThisPaymentAlreadyIncludedInRemitance($payment_id,$reason){
                
                if($this->isPaymentNotAlreadyProcessed($payment_id)){
                if($this->isThisPaymentNotAlreadyIncluded($payment_id)){
                    
                    if($this->effectTheInclusionOfThisPaymentInRemittance($payment_id,$reason)){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
                
            }
            
            
            /**
             * This is the function that confirms if a payment is already part of the current remittance
             */
            public function isThisPaymentNotAlreadyIncluded($payment_id){
                
                $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('payment')
                    ->where("id = $payment_id and remit_status = 'unprocessed'");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            /**
             * This is the function that does the actual inclusion of payment in remittance
             */
            public function effectTheInclusionOfThisPaymentInRemittance($payment_id,$reason){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('payment',
                                  array(
                                    'remit_status'=>"unprocessed",
                                      'reason_for_undeferment'=>$reason,
                                      'undeferment_effected_by'=>Yii::app()->user->id,
                                      'date_of_undeferment'=>new CDbExpression('NOW()')
                                  
                           ),
                        ("id=$payment_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
        
        
        /**
         * This is the function that process remittance
         */
        public function actionprocessThisRemittance(){
            
            $domain_id = $_POST['domain_id'];
            
           $domainname = $this->determineDomainNameGivenItId($domain_id);
           //generate a remittance code
            $remittance_code = $this->generateRemittanceCode($domain_id);
            
            if($this->isRemitanceToThisDomainSuccessful($domain_id,$remittance_code)){
               
                $msg = "'$domainname' current remittance successfully processed.You can commence manual payment transfer process using this remittance code '$remittance_code'";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>$msg
                         
                          
                       ));
                
            }else{
                $msg = "Could not process the current remittance to '$domainname'. Please contact the payment support team";
                $this->sendToPaymentSupportTeam($msg);
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" =>$msg
                         
                          
                       ));
            } 
            
            
        }
        
        /**
         * This is the function that sends remittance error message to payment support team
         */
        public function sendToTheSupportTeam($domain_id,$toolbox_id,$msg){
            
            //send the message to payment support team
        }
        
        
        /**
         * This is the function that effects the remittance payment to a beneficiary
         */
        public function isRemitanceToThisDomainSuccessful($domain_id,$remittance_code){
           
            $transaction_counter = 0;
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
           //get all the payments accruable to this domain
            $payments = $this->getAllDomainPaymentsId($domain_id);
            
            //retrieve the platform holding period
            $holding_period = $this->getThePlatformHoldingPeriod();
            
            foreach($payments as $payment){
               if($this->isPaymentWithinTheGivenPeriod($payment,$month,$year,$day,$holding_period)){
                   if($this->isPaymentPartOfTheRemittance($payment)){
                       $transaction_counter = $transaction_counter + $this->processThisPaymentForRemittance($payment);
                       //write the remittance code against this payment
                       $this->saveThisRemittanceCodeAgainstThisPayment($payment,$remittance_code);
                   }
                 
             }
                
            }
            if($transaction_counter >0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        /**
         * This is the function that determines if a payment is remittance ready
         */
        public function isPaymentPartOfTheRemittance($payment_id){
            
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('payment')
                    ->where("id = $payment_id && remit_status='unprocessed'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
        }
        
        /**
         * This is the function that does the actual processing of data for remittance
         */
        public function processThisPaymentForRemittance($payment_id){
            
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('payment',
                                  array(
                                    'remit_status'=>"processed",
                                     'remittance_effected_by'=>Yii::app()->user->id,
                                      'date_remittance_processed'=>new CDbExpression('NOW()')
                                  
                           ),
                        ("id=$payment_id")
			
                        );
                return $result;
            
        }
        
        /**
         * This is the function that saves remittance code
         */
        public function saveThisRemittanceCodeAgainstThisPayment($payment_id,$remittance_code){
            
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('payment',
                                  array(
                                    'remittance_code'=>$remittance_code,
                        
                           ),
                        ("id=$payment_id")
			
                        );
                return $result;
            
        }
        
        /**
         * This is the function that generates remittance code
         */
        public function generateRemittanceCode($domain_id){
            
            $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            
            $user_id = Yii::app()->user->id;
            //get the domain country name first three letters
                $domain_country_first_three_letters = rtrim(strtoupper($this->getTheDomainCountryNameFirstFourLetters($domain_id)));
                
                //get the a substring of the domain name
                $domain_name_sub = rtrim(strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id)));
                
                                              
                //generate a random number
                $random_number = $this->generateTheRandomNumber();
                
               //get the first four letters of the user processing this remittance
                $username = rtrim(strtoupper($this->getTheFirstFourLettersOfAUserLastname($user_id)));
                
                $remittance_code = "$domain_country_first_three_letters-$today-$domain_name_sub-$random_number-$username";
                
                //confirm if this $remittance_number already exist
               if($this->isThisRemittanceCodeNotAlreadyTaken($remittance_code)){
                    return $remittance_code; 
                  
               }else{
                   $remittance_code = "$domain_name_sub-$random_number-$domain_country_first_three_letters-$today-$username";
                   return $remittance_code;
                }
        }
        
        
        /**
         * This is the function that provides the first four letters of a users lastname
         */
        public function getTheFirstFourLettersOfAUserLastname($user_id){
            
            //return the first four letters of a user's lastname
            return substr($this->getThisUserLastname($user_id), 0, 4);
       
        }
        
        /**
         * This is the function that verifies the existence of remittance code
         */
        public function isThisRemittanceCodeNotAlreadyTaken($remittance_code){
            
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('payment')
                    ->where("remittance_code = '$remittance_code'");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                    }else{
                    return false;
                }
        }
        
        /**
         * This is the function that gets the lastname of a user
         */
        public function getThisUserLastname($user_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$user_id);
                $user = User::model()->find($criteria);
                
                return $user['lastname'];
        }
        /**
             * This is the function that gets the first four letters of the buyer domain country
             */
            public function getTheDomainCountryNameFirstFourLetters($domain_id){
                //get the domain country
                $country = $this->getTheCountryIdOfThisDomain($domain_id);
                
                return substr($this->getThisCountryName($country), 0, 3);
                
                
            }
            
            /**
             * This is the function that gets a country id of a domain
             */
            public function getTheCountryIdOfThisDomain($domain_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $domain = ResourceGroupCategory::model()->find($criteria);
                
                return $domain['country_id'];
            }
            
            /**
             * This is the function that gets a country name
             */
            public function getThisCountryName($country_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$country_id);
                $domain = Country::model()->find($criteria);
                
                return $domain['name'];
            }
            
            /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstThreeLetters($domain_id){
                //get the domain name
                $domainname = $this->determineDomainNameGivenItId($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
            
            
            /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
        /**
         * function testing function
         */
        public function actionjustFunctionTesting(){
            
            $domain_id = 1;
            $remittance_code = $this->generateRemittanceCode($domain_id);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "remittance_code" =>$remittance_code
                         
                          
                       ));
            
            
        }
        
        
         /**
             * This is the function that assigns toolbox service to a domain
             */
            public function assignToolboxToDomain($toolbox_id,$domain_id,$subscribers,$store_id,$toolbox_status,$number_of_years){
                //get the number of years for this subscription
                //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                $userid = Yii::app()->user->id;
                $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                $year_later = mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years);
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('resourcegroup_has_resourcegroupcategory',
                                  array(
                                    'resourcegroup_id'=>$toolbox_id,
                                    'category_id'=>$domain_id,
                                    'toolbox_status'=>$toolbox_status, 
                                    'no_of_subscribers'=>$subscribers, 
                                   'store_id'=>$store_id,
                                     'start_date'=>date("Y-m-d",$today),
                                     'min_date'=>date("Y-m-d",$today),
                                    'end_date'=>date("Y-m-d",$year_later),
                                    'max_date'=>date("Y-m-d",$year_later),
                                   'date_assigned'=>new CDbExpression('NOW()'),
                                   'assigned_by'=>$userid,
                                   'number_of_years'=> $number_of_years 
                               
		
                            )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
        
            
             /**
             * This is the function that extends the time to live of a service to a domain
             */
            public function ExtendThisServiceToThisDomain($toolbox_id,$domain_id,$subscribers,$number_of_years){
                
              //get the number of years of subscription
              //$number_of_years = $this->getTheNumberOfYearsForThisSubscription($toolbox_id, $order_id);
                //confirm if service exist for a domain
                if($this->isThisServiceToDomainAvailable($toolbox_id,$domain_id)){
                    //confirm if end of date is declared for this service to this domain
                    if($this->isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id)){
                        //get the end_date for the service to this domain
                        $end_date = getdate(strtotime($this->getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id)));
                        $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                        if($end_date['year'] -$today['year']<=0 ){
                            if($end_date['mon']- $today['mon']<=0 ){
                                if(($end_date['mday']- $today['mday']<=0 )){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mon']- $today['mon']<=0){
                                   $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years));  
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years));
                                }
                            }
                        }else{
                            $year_diff = $end_date['year'] -$today['year'];
                            if($end_date['mon']- $today['mon']<=0){
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                   $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")-1  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon']-1;
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d"), date("Y")+$number_of_years+$year_diff));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff  , date("d")+$day_diff, date("Y")+$number_of_years+$year_diff)); 
                                }
                            }
                        }
                       // extend the value of the service by the new date value
                        $new_expiry_date = date("Y-m-d", $new_end_date);
                        if($this->extendThisServiceToDomain($toolbox_id,$domain_id,$new_expiry_date,$subscribers,$number_of_years)){
                            return true;
                        }else{
                            return false;
                        }
                        
                    }
                }
                
                
                
            }
            
            
             /**
             * This is the function that writes the new extended expiry date value to server
             */
            public function extendThisServiceToDomain($toolbox_id,$domain_id,$new_expiry_date,$subscribers,$number_of_years ){
                
                $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                //get the existing number of years of subscription
                $existing_number_of_years = $this->getTheExistingNumberOfYearsForThisSubscription($toolbox_id, $domain_id);
                $existing_subscribers = $this->getTheExistingSubscribersForThisSubscription($toolbox_id, $domain_id);
                $new_number_of_years = $existing_number_of_years + $number_of_years;
                $new_subscribers_base = $subscribers + $existing_subscribers;
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('resourcegroup_has_resourcegroupcategory',
                                  array(
                                   'min_date'=>$today,
                                   'start_date'=>$today,   
                                   'max_date'=>$new_expiry_date, 
                                   'end_date'=>$new_expiry_date,
                                   'no_of_subscribers'=>$new_subscribers_base,
                                   'number_of_years'=>$new_number_of_years   
                           ),
                        ("resourcegroup_id=$toolbox_id and category_id=$domain_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
            /**
             * This is the function that gets the existing number of years
             */
            public function getTheExistingNumberOfYearsForThisSubscription($toolbox_id, $domain_id){
                
                $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $date['number_of_years'];
                
            }
            
            /**
             * This is the function that gets the existing subscriber's base
             */
            public function getTheExistingSubscribersForThisSubscription($toolbox_id, $domain_id){
                $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $date['no_of_subscribers'];
                
            }
            
             /**
             * This is the function that determines if this service is actually available to this domain
             */
            public function isThisServiceToDomainAvailable($toolbox_id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup_has_resourcegroupcategory')
                    ->where("resourcegroup_id = $toolbox_id and category_id=$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
             /**
             * This is the function that determines if end of date is declared for a service to a domains
             */
            public function isEndOfDateDeclaredForThisServiceToThisDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
            
                if(strtotime($date['max_date'])>0 || $date['max_date']!== NULL){
                   return true;
                 }else{
                     return false;
                 
                } 
                
            }
            
            
             /**
             * This is the function that is used to get the max date of a toolbox service to a domain
             */
            public function getTheEndDateOfThisServiceToThisToDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $date['max_date'];
                 
            }
            
            
             /**
             * This is the function that is used to get the end date of a toolbox service to a domain
             */
            public function getTheRealEndDateOfThisServiceToThisDomain($toolbox_id,$domain_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='resourcegroup_id=:toolboxid and category_id=:domainid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id,':domainid'=>$domain_id);
                 $date= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                 
                 return $date['end_date'];
                 
            }
            
            /**
             * This is the function that returns the name of a toolbox
             */
            public function toolboxServiceName($toolbox_id){
                
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='id=:toolboxid';
                 $criteria1->params = array(':toolboxid'=>$toolbox_id);
                 $toolbox= Resourcegroup::model()->find($criteria1);
                 
                 return $toolbox['name'];
                
            }
            
            
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }    
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Payment the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Payment::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Payment $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='payment-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
