<?php

class PhysicalBoxHolderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllDomainPhysicalBoxWithDomain','RejectTheAssignmentOfThisDomainOwnPhysicalBox',
                                    'ConfirmTheAssignmentOfThisDomainOwnPhysicalBox','AssignThisDomainOwnPhysicalBox','ReturnThisDomainOwnPhysicalBox',
                                    'isDomainVerifierPermittedOnThePlatform','isDomainVerifierRequired','getTheBoxDetail','RejectTheReturnOfThisDomainOwnPhysicalBox',
                                    'ConfirmTheReturnOfThisDomainOwnPhysicalBox','ReturnThisOtherDomainPhysicalBox','AssignThisOtherDomainPhysicalBox',
                                    'RejectTheAssignmentOfThisOtherDomainPhysicalBox','ConfirmTheAssignmentOfThisOtherDomainPhysicalBox','listAllOtherDomainPhysicalBoxWithDomain',
                                    'listAllReassignedPhysicalBoxInDomain','listAllReturnedPhysicalBoxFromOtherDomain','listAllReturnedPhysicalBoxFromOtherDomain','listAllDomainOffStationPhysicalBoxes',
                                    'RecallThisPhysicalBox','getTheBoxDetailDuringConsumption','ReturnThisOwnDomainBoxAtConsumption','ReturnThisOtherDomainBoxAtConsumption',
                                    'AssignThisBoxAtConsumption','AssignThisDomainOwnPhysicalBoxAtConsumption','UnitTester'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
       /**
        * This is the function that list all own physical boxes and folders that is with domain 
        */ 
        public function actionlistAllDomainPhysicalBoxWithDomain(){
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id=:domainid and is_recall_initiated=:recalled) and (is_returned=:returned and is_return_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':returned'=>false,':initiated'=>true);
           $boxes = PhysicalBoxHolder::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)){
                    $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach( $all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxHolder::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes,
                          
                        ));
                       
                }
            
            
        }
        
        
         /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        
         /**
         * This is the function that deternines if a batch belongs to a domain
         */
       public function isBoxOwnByThisDomain($id,$domain_id){
           
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $id && domain_id =$domain_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
       }
       
       
        /**
      * This is the function that determines if domain verifier is required for a domain
      */
     public function actionisDomainVerifierRequired(){
         
          $user_id = Yii::app()->user->id;
          $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
         
          if($this->isInitiatorVerifierRequired($domain_id)){
              
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "verify" => true
                        ));
          }else{
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "verify" => false
                        )); 
          }
     }
     
       
            /**
      * This is the function that determines if initiator verifier is required by a domain
      */
     public function isInitiatorVerifierRequired($domain_id){
         
         if($this->isDomainVerifierPermittedOnThePlatform()){
             if($this->isDomainInitiatorExemptedFromVerification($domain_id)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
            return false; 
         }
     }
     
      /**
      * This is the function that determines if domains initiators should be verified
      */
     public function isDomainVerifierPermittedOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $settings = PlatformSettings::model()->find($criteria);
            
            if($settings['enable_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
      /**
      * This is the fucntion that determines if domain is exempted from having a verifier 
      */
     public function isDomainInitiatorExemptedFromVerification($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$id,':status'=>'active');
            $policy = DomainPolicy::model()->find($criteria);
            
            if($policy['exempt_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     /**
         * This is the function that retrieves a document's name
         */
        public function actiongetTheBoxDetail(){
            
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $returneeid = $_POST['return_initiated_by'];
                    
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
             //get the device name
             $criteria3 = new CDbCriteria();
             $criteria3->select = '*';
             $criteria3->condition='id=:id';
             $criteria3->params = array(':id'=>$box['physical_box_storage_device_type_id']);
             $device = StorageDevice::model()->find($criteria3);  
             
             
              //get the storage room
             $criteria4 = new CDbCriteria();
             $criteria4->select = '*';
             $criteria4->condition='id=:id';
             $criteria4->params = array(':id'=>$box['physical_box_location_room_id']);
             $room = StorageRoom::model()->find($criteria4);  
             
             
             //get the storage location
             $criteria5 = new CDbCriteria();
             $criteria5->select = '*';
             $criteria5->condition='id=:id';
             $criteria5->params = array(':id'=>$box['physical_box_location_id']);
             $location = Location::model()->find($criteria5);  
             
             //get the  user id of the document holder
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$id);
             $holder = PhysicalBoxHolder::model()->find($criteria6);  
             
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$holder['user_id']);
             $holdername = User::model()->find($criteria7);
             $name = $holdername['firstname']. ' ' . $holdername['lastname'];
             
             //get the domain name of the document
             //get the document name 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$box['domain_id']);
             $domain = Resourcegroupcategory::model()->find($criteria); 
             
             //get the name of the user that initiated the return
             $criteria8 = new CDbCriteria();
             $criteria8->select = '*';
             $criteria8->condition='id=:id';
             $criteria8->params = array(':id'=>$returneeid);
             $returneename = User::model()->find($criteria8);
             $returnee_name = $returneename['firstname']. ' ' . $returneename['lastname'];
             
              //get the returnee domain
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$returneename['domain_id']);
             $returnee_domain = Resourcegroupcategory::model()->find($criteria);  
             
             if($box===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box"=>$box['name'],
                            "device"=>$device['label'],
                            "room"=>$room['name'],
                            "location"=>$location['name'],
                           "holder"=>$name,
                           "currentholder"=>$returnee_name,
                           "ownerdomainid"=>$box['domain_id'],
                           "domainname"=>$domain['name'],
                           "holderdomain"=>$returnee_domain['name']
                    ));
                       
                }
            
            
        }
     
        
        /**
         * This is the function that retrieves a document's name
         */
        public function actiongetTheBoxDetailDuringConsumption(){
            
            //get the user id
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $box_id = $_POST['box_id'];
            $returneeid = $user_id;
                    
             //get the box name
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$box_id);
             $box = Resourcegroup::model()->find($criteria2);  
             
             //get the device name
             $criteria3 = new CDbCriteria();
             $criteria3->select = '*';
             $criteria3->condition='id=:id';
             $criteria3->params = array(':id'=>$box['physical_box_storage_device_type_id']);
             $device = StorageDevice::model()->find($criteria3);  
             
             
              //get the storage room
             $criteria4 = new CDbCriteria();
             $criteria4->select = '*';
             $criteria4->condition='id=:id';
             $criteria4->params = array(':id'=>$box['physical_box_location_room_id']);
             $room = StorageRoom::model()->find($criteria4);  
             
             
             //get the storage location
             $criteria5 = new CDbCriteria();
             $criteria5->select = '*';
             $criteria5->condition='id=:id';
             $criteria5->params = array(':id'=>$box['physical_box_location_id']);
             $location = Location::model()->find($criteria5);  
             
             $document_assigned_but_not_returned = $this->isThisPhysicalBoxAssignedToThisUserButItsYetReturned($box_id,$user_id,$domain_id);
             
             $never_with_physical_document =$this->isUserNotTheCurrentHolderOfThisPhysicalBox($box_id,$user_id,$domain_id);
             
             $requested_but_not_yet_assigned = $this->isBoxRequestedByUserButNotYetAssigned($box_id,$user_id,$domain_id);
             
             $idd = $this->getTheIdOfThisPhysicallyHeldBox($box_id,$user_id,$domain_id);   
             
             //confirm if the request for this document is no longer concellable
             $cancellable = $this->isThisBoxRequestStillCancellable($box_id,$user_id);
             
             //get the name of this user
             $criteria7 = new CDbCriteria();
             $criteria7->select = '*';
             $criteria7->condition='id=:id';
             $criteria7->params = array(':id'=>$user_id);
             $holdername = User::model()->find($criteria7);
             $name = $holdername['firstname']. ' ' . $holdername['lastname'];
             
             //get the domain name of the document
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$box['domain_id']);
             $domain = Resourcegroupcategory::model()->find($criteria); 
             
                         
             //get the name of the user that initiated the return
             $criteria8 = new CDbCriteria();
             $criteria8->select = '*';
             $criteria8->condition='id=:id';
             $criteria8->params = array(':id'=>$returneeid);
             $returneename = User::model()->find($criteria8);
             $returnee_name = $returneename['firstname']. ' ' . $returneename['lastname'];
             
              //get the returnee domain
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$returneename['domain_id']);
             $returnee_domain = Resourcegroupcategory::model()->find($criteria);  
             
             if($box===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box"=>$box['name'],
                            "device"=>$device['label'],
                            "room"=>$room['name'],
                            "location"=>$location['name'],
                           "holder"=>$name,
                           "currentholder"=>$returnee_name,
                           "ownerdomainid"=>$box['domain_id'],
                           "domainname"=>$domain['name'],
                           "holderdomain"=>$returnee_domain['name'],
                           "assigned_but_not_returned"=>$document_assigned_but_not_returned,
                           "never_with_physical"=>$never_with_physical_document,
                           "requested_but_not_assigned"=>$requested_but_not_yet_assigned,
                           "idd"=>$idd,
                           "cancellable"=>$cancellable,
                           "owner"=>true
                    ));
                       
                }
            
    }
    
    
    /**
         * This is the function that confirms if assignment is done but its yet to be returned
         */
        public function isThisPhysicalBoxAssignedToThisUserButItsYetReturned($box_id,$user_id,$domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_holder')
                    ->where("(is_returned = 0 && is_assigned =1) && (box_id=$box_id && user_id=$user_id)");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
        }
        
        
        /**
         * This is the function that confirms if  this user was never the current holder of this physical box
         */
        public function isUserNotTheCurrentHolderOfThisPhysicalBox($box_id,$user_id,$domain_id){
            
            if($this->isThisUserNotTheCurrentHolderOfThisBox($box_id,$user_id,$domain_id)){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        /**
         * This is the function that confirms that this user is not current holder of this box
         */
        public function isThisUserNotTheCurrentHolderOfThisBox($box_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='box_id=:doc and (is_returned=:returned or is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$box_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalBoxHolder::model()->find($criteria6);  
             
             if($holder['user_id'] == $user_id){
                 return false;
             }else{
                 return true;
             }
            
        }
        
        
        /**
         * This is the function that confirms if box is requested but not yet assigned to the user
         */
        public function isBoxRequestedByUserButNotYetAssigned($box_id,$user_id,$domain_id){
            
           if($this->isThisRequestNotYetAssigned($box_id,$user_id,$domain_id)){
                   return true;
               }else{
                   return false;
               }
     
            
        }
        
        /**
         * This is the function that confirms if a request is not assigned to a user
         */
        public function isThisRequestNotYetAssigned($box_id,$user_id,$domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_holder')
                    ->where("(is_returned = 0 && is_assigned =0) && (box_id=$box_id && user_id=$user_id)");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
            
        }
        
              
        /**
         * This is the function that derive the id of the current physical holder of this box if its the user in question
         */
        public function getTheIdOfThisPhysicallyHeldBox($box_id,$user_id,$domain_id){
            
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(box_id=:doc and user_id=:userid) and (is_returned=:returned and is_assigned=:assigned)';
             $criteria6->params = array(':doc'=>$box_id,':userid'=>$user_id,':returned'=>false,':assigned'=>true);
             $holder = PhysicalBoxHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
                 
             }else{
                 return 0;
             }
        }
     
        /**
         * This is the function that initiates the return of own domain physical box 
         */
        public function actionReturnThisDomainOwnPhysicalBox(){
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $box_name = $this->getThisBoxName($box_id);
            
            if($this->isThisBoxReturnRequestInitiated($id) == false){
                if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisReturnInitiationSuccessful($id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$box_name' box & folder was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the return of '$box_name' box & folder. It is possible you are no longer in possession of this physical box & folder"
                        ));
                }
                
            }else{
                if($this->isReturnOfThisBoxToStorageSuccessful($id)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$box_name' box & folder to storage was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the return of '$box_name' box & folder"
                        ));
                }
                
            }
            
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Return of '$box_name' box & folder had already been initiated and it's awaiting confirmation"
                        ));
            }
            
        }
        
        
         /**
         * This is the function that gets a document name
         */
        public function getThisBoxName($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $box = Resourcegroup::model()->find($criteria); 
             
             return $box['name'];
            
        }
        
        
          /**
      * This is the function that determines if document return initiation is in place
      */
     public function isThisBoxReturnRequestInitiated($id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalBoxHolder::model()->find($criteria);  
             
             if($doc['is_return_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
         
     }
        
     
       /**
         * This is the function that ensures the successful initiation of document returns
         */
        public function isThisReturnInitiationSuccessful($id){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_return_initiated'=>1, 
                                    'return_initiated_by'=>Yii::app()->user->id,  
                                    'return_initiated_date'=>new CDbExpression('NOW()'),
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
     
        
          /**
         * This is the function that ensures that physical document return is confirmed returned
         */
        public function isReturnOfThisBoxToStorageSuccessful($id){
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_return_accepted'=>1, 
                                    'return_accepted_by'=>Yii::app()->user->id,  
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_returned'=>1,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            
        }
      
        
        /**
         * This is the function rejects the initiation of the own physical box return
         */
        public function actionRejectTheReturnOfThisDomainOwnPhysicalBox(){
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $box_name = $this->getThisBoxName($box_id);
            if($this->isThisBoxReturnRequestInitiated($id)){
               if($this->isRejectionOfTheReturnOfThisBoxSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Return of '$box_name' box & folder to storage is rejected successfully"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$box_name' box & folder  to storage could not be rejected"
                        ));
            } 
                
            }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$box_name' box & folder  to storage was never initiated"
                        )); 
            }
            
        }
        
        
           
      /**
      * This is the function that effects the rejection of return of document to storgae
      */
     public function isRejectionOfTheReturnOfThisBoxSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_return_accepted'=>0, 
                                    'return_accepted_by'=>Yii::app()->user->id,  
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_returned'=>0,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
     
     
        /**
         * This is the function that confirms the initiation of the own physical box return
         */
        public function actionConfirmTheReturnOfThisDomainOwnPhysicalBox(){
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $box_name = $this->getThisBoxName($box_id);
            if($this->isThisBoxReturnRequestInitiated($id)){
                if($this->isConfirmationOfTheReturnOfThisBoxSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Return of '$box_name' box & folder  to storage is confirmed"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$box_name' box & folder  to storage could not be confirmed"
                        ));
            }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Return of '$box_name'box & folder  to storage was never initiated"
                        ));
                
            }
            
            
        }
        
        
        /**
      * This is the function that effects the return of physical document to storage
      */
     public function isConfirmationOfTheReturnOfThisBoxSuccessful($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_return_accepted'=>1, 
                                    'return_accepted_by'=>Yii::app()->user->id,  
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_returned'=>1,   
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
        
        
        /**
         * This is the function that initiates the assignment of own domain physical boxes & folders
         */
        public function actionAssignThisDomainOwnPhysicalBox(){
            
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days']; 
            
            if(isset($_POST['userid'])){
                $new_custodian = $_POST['userid'];
            }else if(isset($_POST['subgroupid'])){
                
                $new_custodian = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['subgroupid']);
            }else if(isset($_POST['groupid'])){
                $new_custodian = $this->getTheGroupHeadIdOfThisSubgroup($_POST['groupid']);
            }
         
            $box_name = $this->getThisBoxName($box_id);
            if($this->isThisBoxRecallRequestInitiated($id)){
                if($this->isThisBoxAssignmentRequestInitiated($id) == false){
                 if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisBoxAssignmentInitiationSuccessful($id,$new_custodian,$max_period)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$box_name' box & folder was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the assignment of '$box_name' box & folder"
                        ));
                }
                
            }else{
                if($this->isAssignmentOfThisBoxToACustodianSuccessful($id,$new_custodian,$max_period)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$box_name' box & folder to another custodian was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the assignment of '$box_name' box & folder"
                        ));
                }
                
            }
                 
             }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Assignment of '$box_name' box & folder had already been initiated"
                        ));
             }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder could not be assigned as the owner had initiated its recall process"
                        ));
                
            }
             
        }
        
        
        
        /**
      * This is the function that ensures that document assignment is completely successful
      */
     public function isAssignmentOfThisBoxToACustodianSuccessful($id,$new_custodian,$max_period){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_assignment_confirmed'=>1, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>1,
                                     'user_id'=>$new_custodian,
                                     'maximum_holding_period_in_days'=> $max_period 
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
        
        
         /**
      * This is the function that determines if document assignment initiation is already in place
      */
     public function isThisBoxAssignmentRequestInitiated($id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalBoxHolder::model()->find($criteria);  
             
             if($doc['is_assignment_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
         
     }
     
     
      /**
       * This is the function that determines if box & folder assignment initiation is already in place at consumption
      */
     public function isThisBoxAssignmentRequestInitiatedAtConsumption($box_id,$user_id){
           //get the id of the transaction in question
         $id = $this->getTheIdOfThisUnconfirmedInitiatedBoxAssignment($box_id,$user_id);
         
         if($this->isThisUnconfirmedBoxAssignmentInitiationRequestNotRecalled($id)){
             return true;
         }else{
             return false;
         }
 
     }
     
     
     /**
      * This is the function that gets id of the unconfirmed assignment initiation
      */
     public function getTheIdOfThisUnconfirmedInitiatedBoxAssignment($box_id,$user_id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='box_id=:doc and (is_returned=:returned and is_assigned=:assigned) and (is_assignment_initiated=:initiated and assignment_initiated_by=:initiatedby )';
             $criteria6->params = array(':doc'=>$box_id,':returned'=>false,':assigned'=>false,':initiated'=>true,':initiatedby'=>$user_id);
             $holder = PhysicalBoxHolder::model()->find($criteria6);
             
             if($holder['id'] != null){
                 return $holder['id'];
             }else{
                 return 0;
             }
         
     }
     
     
     /**
      * This is the function that confirms an unconfimed assignment had not been recalled
      */
     public function isThisUnconfirmedBoxAssignmentInitiationRequestNotRecalled($id){
         
            if($id == 0){
                return false;
            }else{
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalBoxHolder::model()->find($criteria);  
             
             if($doc['is_recall_initiated'] == 0){
                 return true;
             }else{
                 return false;
             }
            }
             
         
     }
     
      /**
      * This is the function that verifies if document assignment was initiated successfully
      */
     public function isThisBoxAssignmentInitiationSuccessful($id,$new_custodian,$max_period){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_assignment_initiated'=>1, 
                                    'maximum_holding_period_in_days'=>$max_period,  
                                    'assignment_initiated_by'=>Yii::app()->user->id,  
                                    'assignment_initiation_date'=>new CDbExpression('NOW()'),
                                    'maximum_holding_period_in_days'=> $max_period, 
                                    'user_id'=>$new_custodian
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
         
     }
     
     
      /**
      * This is the function that re-assigns document at consumption
      */
     public function actionAssignThisDomainOwnPhysicalBoxAtConsumption(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days']; 
            
            if(isset($_POST['userid'])){
                $new_custodian = $_POST['userid'];
            }else if(isset($_POST['subgroupid'])){
                
                $new_custodian = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['subgroupid']);
            }else if(isset($_POST['groupid'])){
                $new_custodian = $this->getTheGroupHeadIdOfThisGroup($_POST['groupid']);
            }
            
            $box_name = $this->getThisBoxName($box_id);
            if($this->isThisBoxRecallRequestInitiated($id)== false){
             if($this->isThisBoxAssignmentRequestInitiatedAtConsumption($box_id,$user_id) == false){
                if($this->isThisBoxCurrentlyAssignedToThisUser($id,$box_id,$user_id)){
                 if($this->isThisAssignmentInConformityWithDomainPolicy($domain_id)){
                 if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisNewBoxAssignmentInitiationSuccessful($id,$box_id,$new_custodian,$max_period,$domain_id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$box_name' box & folder was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the assignment of '$box_name' box & folder"
                        ));
                }
                
            }else{
                if($this->isNewAssignmentOfThisBoxToACustodianSuccessful($id,$box_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$box_name' box & folder to another custodian was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the assignment of '$box_name' box & folder"
                        ));
                }
            }  
                
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This re-assignment is in violation with your domain policy. Please contact your domain admin"
                        ));
            }
         
             }else{
                   echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the re-assignment of '$box_name' box & folder as you are not the current holder"
                        )); 
                 
             }
             
              }else{
                      header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The assignment of '$box_name' box & folder is already initiated and it is awaiting confirmation"
                        )); 
                     
                 }
                 
              
                 
            
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder could not be re-assigned as the owner had initiated its recall process"
                        ));
                
            }
            
         
         
     }
     
     
      /**
      * This is the function that determines if a document is currently assigned to a user
      */
     public function isThisBoxCurrentlyAssignedToThisUser($id,$box_id,$user_id){
         
         $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('physical_box_holder')
                    ->where("(is_returned = 0 && is_assigned =1) && (box_id=$box_id && user_id=$user_id)");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
     
      /**
      * This is the function that determines assignment domain policy
      */
     public function isThisAssignmentInConformityWithDomainPolicy($domain_id){
         return true;
     }
     
     
      /**
      * This is the function that initiates  new document assignment to a user
      */
     public function isThisNewBoxAssignmentInitiationSuccessful($id,$box_id,$new_custodian,$max_period,$domain_id){
         
         //forcefully return the existing assigned document
         if($this->isThisAssignedBoxForcefullyReturned($id)){
             if($this->thisNewAssignmentIsInitiatedSuccessfully($box_id,$new_custodian,$max_period,$domain_id)){
                 return true;
             }else{
                 return false;
             }
                 
         }
         
         
         
     }
     
     
       /**
      * This is the function that will forcefully initiates and comfirms an assignment based on domain policy 
      */
     public function thisNewAssignmentIsInitiatedAndConfirmedSuccessfully($box_id,$new_custodian,$max_period,$domain_id){
         
         $custodian_domain_id = $this->getTheDomainIdOfThisUser($new_custodian);
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->insert('physical_box_holder',
                   array(
                      'box_id'=>$box_id, 
                      'maximum_holding_period_in_days'=>$max_period, 
                      'assigned_type'=>"reassignment",
                      'user_id'=>$new_custodian,
                      'is_assignment_initiated'=>1,   
                      'assignment_initiation_date'=>new CDbExpression('NOW()'),
                      'assignment_initiated_by'=>$userid,
                      'holder_domain_id'=>$custodian_domain_id,
                       'is_assignment_confirmed'=>1,
                       'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                       'assignment_confirmed_by'=>Yii::app()->user->id,
                       'is_assigned'=>1
                   )
			
                 );
            if($result>0){
                  return true;
            }else{
               return false;
            }
         
     }
     
     
        
     /**
      * This is the function that forcefully return a document
      */
     public function isThisAssignedBoxForcefullyReturned($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_returned'=>1, 
                                    'return_initiated_by'=>Yii::app()->user->id,  
                                    'return_accepted_by'=>Yii::app()->user->id,
                                    'return_initiated_date'=>new CDbExpression('NOW()'),
                                    'return_accepted_date'=>new CDbExpression('NOW()'),
                                    'is_return_initiated'=>1,
                                    'is_return_accepted'=> 1  
                     
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
     }
     
     /**
      * This is the function that initiates the re-assignment of  a document to another user 
      */
     public function thisNewAssignmentIsInitiatedSuccessfully($box_id,$new_custodian,$max_period,$domain_id){
        
         $custodian_domain_id = $this->getTheDomainIdOfThisUser($new_custodian);
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->insert('physical_box_holder',
                   array(
                      'box_id'=>$box_id, 
                      'maximum_holding_period_in_days'=>$max_period, 
                      'assigned_type'=>"reassignment",
                      'user_id'=>$new_custodian,
                      'is_assignment_initiated'=>1,   
                      'assignment_initiation_date'=>new CDbExpression('NOW()'),
                      'assignment_initiated_by'=>Yii::app()->user->id,
                      'holder_domain_id'=>$custodian_domain_id,
                   )
			
                 );
            if($result>0){
                  return true;
            }else{
               return false;
            }
         
     }
     
     
     /**
      * This is the function that completes the initiation and confirmation of batch re-assignment
      */
     public function isNewAssignmentOfThisDocumentToACustodianSuccessful($id,$box_id,$new_custodian,$max_period,$domain_id){
          //forcefully return the existing assigned document
         if($this->isThisAssignedDocumentForcefullyReturned($id)){
             if($this->thisNewAssignmentIsInitiatedAndConfirmedSuccessfully($document_id,$batch_id,$box_id,$new_custodian,$max_period,$domain_id)){
                 return true;
             }else{
                 return false;
             }
         }
         
     }
        
        
        /**
         * This is the function that effects the rejection of own domain physical box assignment
         */
        public function actionRejectTheAssignmentOfThisDomainOwnPhysicalBox(){
            
           $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $box_name = $this->getThisBoxName($box_id);
             if($this->isThisBoxAssignmentRequestInitiated($id)){
                  if($this->isRejectionOfTheAssignmentOfThisBoxSuccessful($id)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Assignment of '$box_name' box & folder  to a custodian is rejected"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$box_name' box & folder  to a custodian could not be rejected"
                        ));
            }
                 
             }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$box_name' box & folder  to a custodian was never initiated"
                        ));
             }
            
            
        }
        
        
         /**
      * This is the function that rejects the assigment of documents to a custodian
      */
     public function isRejectionOfTheAssignmentOfThisBoxSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_assignment_confirmed'=>0, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>0,
                                    //  'user_id'=>$new_custodian
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
         
     }
        
        /**
         * This is the function that effects the confirmation of own domain physical box assignment
         */
        public function actionConfirmTheAssignmentOfThisDomainOwnPhysicalBox(){
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days'];
            
            
           if(isset($_POST['user_id'])){
                $new_custodian = $_POST['user_id'];
            }
            
            $box_name = $this->getThisBoxName($box_id);
            
           if($this->isThisBoxAssignmentRequestInitiated($id)){
                if($this->isConfirmationOfTheAssignmenttOfThisBoxSuccessful($id,$new_custodian,$max_period)){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The Assignment of '$box_name' box & folder  to a custodian is confirmed"
                        ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$box_name' box & folder  to a custodian could not be confirmed"
                        ));
            }
               
           }else{
               header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "The Assignment of '$box_name' box & folder  to a custodian was never initiated"
                        ));
           } 
            
            
        }
        
        
        
        /**
      * This is the function that effects the confirmation of document assignment to a custodian
      */
     public function isConfirmationOfTheAssignmenttOfThisBoxSuccessful($id,$new_custodian,$max_period){
         
        $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_assignment_confirmed'=>1, 
                                    'assignment_confirmed_by'=>Yii::app()->user->id,  
                                    'assignment_confirmed_date'=>new CDbExpression('NOW()'),
                                    'is_assigned'=>1,
                                    'user_id'=>$new_custodian,
                                    'maximum_holding_period_in_days'=> $max_period 
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               } 
         
     }
     
     
     /**
      * This is the function that list all other domain physical boxes & folders with domain
      */
     public function actionlistAllOtherDomainPhysicalBoxWithDomain(){
         
           $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id=:domainid and is_recall_initiated=:recalled) and (is_returned=:returned and is_return_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':returned'=>false,':initiated'=>true);
           $boxes = PhysicalBoxHolder::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id) == false){
                    $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach( $all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxHolder::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes,
                          
                        ));
                       
                }
         
     }
        
     /**
      * This is the function that initiates the return of other domain physical box & folder with domain
      */
     public function actionReturnThisOtherDomainPhysicalBox(){
         
           $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $owner_domain = $_POST['owner_domain_id'];
            
            $box_name = $this->getThisBoxName($box_id);
            
            $domain_name = $this->getThisDomainName($owner_domain);
            
            if($this->isThisBoxReturnRequestInitiated($id)== false){
                              
                if($this->isThisReturnInitiationSuccessful($id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Return of '$box_name' box & folder was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the return of '$box_name' box & folder"
                        ));
                }
       
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Return of '$box_name' box & folder had already been initiated but awaiting confirmation of physical document receipt at '$domain_name' domain"
                        ));
            }
     }
     
     
     /**
      * This is the function that initistes the assignment of other domain physical box & folder with domain
      */
     public function actionAssignThisOtherDomainPhysicalBox(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
          
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            $max_period = $_POST['maximum_holding_period_in_days']; 
            
            if(isset($_POST['userid'])){
                $new_custodian = $_POST['userid'];
            }else if(isset($_POST['subgroupid'])){
                
                $new_custodian = $this->getTheSubgroupHeadIdOfThisSubgroup($_POST['subgroupid']);
            }else if(isset($_POST['groupid'])){
                $new_custodian = $this->getTheGroupHeadIdOfThisSubgroup($_POST['groupid']);
            }
         
            $box_name = $this->getThisBoxName($box_id);
             if($this->isThisBoxRecallRequestInitiated($id)){
                 if($this->isThisBoxAssignmentRequestInitiated($id) == false){
                 if($this->isInitiatorVerifierRequired($domain_id)){
                
                if($this->isThisBoxAssignmentInitiationSuccessful($id,$new_custodian,$max_period)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$box_name' box & folder was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the assignment of '$box_name' box & folder"
                        ));
                }
                
            }else{
                if($this->isAssignmentOfThisBoxToACustodianSuccessful($id,$new_custodian,$max_period)){
                    header('Content-Type: application/json');
                    echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Assignment of '$box_name' box & folder to another custodian was successfully"
                        ));
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not effect the assignment of '$box_name' box & folder"
                        ));
                }
                
            }
                 
             }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Assignment of '$box_name' box & folder had already been initiated"
                        ));
             }
                 
             }else{
                  header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "This '$box_name' box & folder could not be assigned as the owner had initiated its recall process"
                        ));
                 
             }
             
         
     }
     
        /**
      * This is the function that retrieves the head of a subgroup
      */
     public function getTheSubgroupHeadIdOfThisSubgroup($subgroup_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->find($criteria);   
             
             return $subgroup['subgroup_head_id'];
         
         
     }
     
     
     /**
      * This is the function that retrieves the group head id of this group
      */
     public function getTheGroupHeadIdOfThisGroup($group_id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$group_id);
             $group = Group::model()->find($criteria);   
             
             return $group['group_head_id'];
         
         
     }
     
     
       /**
      * This is the function that gets the name of the document owner domain
      */
     public function getThisDomainName($owner_domain){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$owner_domain);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
         
     }
     
     
     
     
     /**
      * This is the function that list all the reassigned physical boxes & folders with domain 
      */
     public function actionlistAllReassignedPhysicalBoxInDomain(){
         
          $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id=:domainid and is_recall_initiated=:recalled) and (is_assigned=:assigned and is_assignment_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':assigned'=>false,':initiated'=>true);
           $boxes = PhysicalBoxHolder::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)){
                    $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach( $all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxHolder::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes,
                          
                        ));
                       
                }
         
         
     }
     
     /**
      * This is the function that list all physical boxes & folders returned by other domains
      */
     public function actionlistAllReturnedPhysicalBoxFromOtherDomain(){
         
         $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='(holder_domain_id!=:domainid and is_recall_initiated=:recalled) and (is_returned=:returned and is_return_initiated=:initiated)';
           $criteria->params = array(':domainid'=>$domain_id, ':recalled'=>false,':returned'=>false,':initiated'=>true);
           $boxes = PhysicalBoxHolder::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)){
                    $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach( $all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxHolder::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes,
                          
                        ));
                       
                }
  
     }
     
     
     
      /**
      * This is the function that list all domain boxes & folder on transit
       * 
       */
    public function actionlistAllDomainOffStationPhysicalBoxes(){
        
         $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           //$domain_id = 2;
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='is_returned=:returned';
           $criteria->params = array(':returned'=>false);
           $boxes = PhysicalBoxHolder::model()->findAll($criteria);
           
           $all_own_boxes = [];
           foreach($boxes as $box){
               if($this->isBoxOwnByThisDomain($box['box_id'],$domain_id)){
                    $all_own_boxes[] = $box['id'];
                   
                 }
           }
           
           $domain_boxes = [];
           
           foreach( $all_own_boxes as $own){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$own);
                $own_doc = PhysicalBoxHolder::model()->find($criteria);
               
                $domain_boxes[] =  $own_doc;
           }
                 
           if($boxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "box" => $domain_boxes,
                          
                        ));
                       
                }
        
    }
    
    
    /**
      * This is the function that effects the recall of a domain's document
      */
     public function actionRecallThisPhysicalBox(){
         
            $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $box_id = $_POST['box_id'];
            $id = $_POST['id'];
            
            $box_name = $this->getThisBoxName($box_id);
            
            if($this->isThisBoxRecallRequestInitiated($id)== false){
                            
                if($this->isThisRecallInitiationSuccessful($id)){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Recall of '$box_name' box & folder was initiated successfully"
                        ));
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Could not initiate the recall of '$box_name' box & folder"
                        ));
                }
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Recall of '$box_name' box & folder had already been initiated"
                        ));
            }
         
         
     }
     
     
     
     /**
      * This is the function that determines if document recall had already been initiated
      */
     public function isThisBoxRecallRequestInitiated($id){
         
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $doc = PhysicalBoxHolder::model()->find($criteria);  
             
             if($doc['is_recall_initiated'] == 1){
                 return true;
             }else{
                 return false;
             }
         
         
     }
    
     
     /**
      * This is the function that confirms the success of the recall initiation request
      */
     public function isThisRecallInitiationSuccessful($id){
         
        $cmd =Yii::app()->db->createCommand();
        $result = $cmd->update('physical_box_holder',
                                  array(
                                    'is_recall_initiated'=>1, 
                                    'recall_initiated_by'=>Yii::app()->user->id,  
                                    'recall_initiation_date'=>new CDbExpression('NOW()'),
                                              
                            ),
                ("id=$id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }  
         
     }
    
     
      /**
         * This is the function that confirms the cancellation of a document request
         */
        public function isThisBoxRequestStillCancellable($box_id,$user_id){
            //get the document request id
            $id = $this->getTheIdOfThisBoxOnRequest($box_id,$user_id);
            if($id == 0){
                return false;
            }else{
             if($this->isThisBoxRequestCancellable($id)== false){
                    return false;
                }else{
                 return true;
                }
               }
            
            
        }
        
        
             /**
      * This is the function that gets the id of the document on request
      */
     public function getTheIdOfThisBoxOnRequest($box_id,$user_id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='(box_id=:doc and requesting_user_id=:userid) and (is_sent=:sent and is_requested=:requested) and is_request_cancelled=:cancelled';
             $criteria6->params = array(':doc'=>$box_id,':userid'=>$user_id,':sent'=>false,':requested'=>false,':cancelled'=>false);
             $holder = PhysicalBoxRequest::model()->find($criteria6);  
             
            if($holder['id'] == 0 || $holder['id'] == null ){
                return 0;
            }else{
                return $holder['id'];
            }
         
     }
     
     
      /**
      * This is the function that determines if a batch request is cancellable
      */
     public function isThisBoxRequestCancellable($id){
         
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';
             $criteria6->params = array(':id'=>$id);
             $request = PhysicalBoxRequest::model()->find($criteria6);  
             
             if($request['is_sent'] == true || $request['is_sent'] == 1){
                 return false;
             }else if($request['is_request_cancelled'] == true || $request['is_request_cancelled']==1){
                 return false;
             }else{
                 return true;
             }
         
     }

     
      /**
      * This is a unit testing function
      */
     public function actionUnitTester($box_id=1, $user_id=1,$domain_id=1){
         $id = $this->getTheIdOfThisPhysicallyHeldBox($box_id,$user_id,$domain_id);
                 
          header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"result" => $result,
                           "id"=>$id
                        ));
     }
    
}
