<?php

class ProductsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ListAllPlatformProducts','ListAllDomainProducts'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllDomainProducts','DeleteOneProduct','updateProductOrTechnology',
                                    'AddNewProductOrTechnology','GetProductName','ListAllPlatformProducts'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Products;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Products']))
		{
			$model->attributes=$_POST['Products'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Products']))
		{
			$model->attributes=$_POST['Products'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Products');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Products('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Products']))
			$model->attributes=$_GET['Products'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}
        
        /**
         * This is the function that list all document category per domain
         */
        public function actionListAllDomainProducts(){
            
            //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            //$domainid = $this->determineAUserDomainIdGiven($userid);
            
           //spool the products/technologies for this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='domain_id=:id';
            //$criteria->params = array(':id'=>$domainid);
            $products= Products::model()->findAll($criteria);
            
                if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "product" => $products
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that list all the platform document category
         */
        public function actionListAllPlatformProducts(){
            
            //obtain the id of the logged in user
          //  $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
           // $domainid = $this->determineAUserDomainIdGiven($userid);
            
           //spool the products/technologies for this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='domain_id=:id';
          //  $criteria->params = array(':id'=>$domainid);
            $products= Products::model()->findAll($criteria);
            
                if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "product" => $products
                          
                           
                           
                          
                       ));
                       
                }
            
        }

        
        /**
         * This is the function that adds new document category to the database
         */
        public function actionAddNewProductOrTechnology(){
            
            $model=new Products;
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
                    
            $model->name = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['version'])){
                $model->version = $_POST['version'];
            }
            if(isset($_POST['model'])){
                 $model->model = $_POST['model'];
            }
           if(isset($_POST['brand'])){
               $model->brand = $_POST['brand'];
           }
            if(isset($_POST['year'])){
                 $model->year = $_POST['year'];
            }
           if(isset($_POST['maker'])){
              $model->maker = $_POST['maker']; 
           }
            if(isset($_POST['chassis'])){
                 $model->chassis = $_POST['chassis'];
            }
            if(isset($_POST['terms'])){
                 $model->chassis = $_POST['terms'];
            }
            //$model->domain_id = $domainid;
            $model->create_user_id = $userid;
            $model->create_time = new CDbExpression('NOW()');
                      
           
             if($model->save()){
                      
                            $msg = "'$model->name' new document category was successfully added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "'$model->name' document category was not added";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
        }
        
        /** 
         * This is the function that edits document category info
         */
        public function actionUpdateProductOrTechnology(){
            $_id = $_POST['id'];
            $model=Products::model()->findByPk($_id);
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
                    
            $model->name = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            if(isset($_POST['version'])){
                $model->version = $_POST['version'];
            }
            if(isset($_POST['model'])){
                 $model->model = $_POST['model'];
            }
           if(isset($_POST['brand'])){
               $model->brand = $_POST['brand'];
           }
            if(isset($_POST['year'])){
                 $model->year = $_POST['year'];
            }
           if(isset($_POST['maker'])){
              $model->maker = $_POST['maker']; 
           }
            if(isset($_POST['chassis'])){
                 $model->chassis = $_POST['chassis'];
            }
             if(isset($_POST['terms'])){
                 $model->chassis = $_POST['terms'];
            }
            //$model->domain_id = $domainid;
            $model->update_user_id = $userid;
            $model->update_time = new CDbExpression('NOW()');
                      
           
             if($model->save()){
                      
                            $msg = " '$model->name' document category was updated successfully";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "'$model->name' document category was not updated";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
        
        
        /**
         * This is the function that deletes a document category from the database
         */
        public function actionDeleteOneProduct(){
            
            $_id = $_POST['id'];
            $model=Products::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'A Document Category Item Successfully Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'Document Category Item Not Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves the name of the document category given the product id
         */
        public function actionGetProductName(){
            
           //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the prefferred currency code
            
            $currency_code = $this->getThisCurrencyCode($preferred_currency);
            
            $_id = $_REQUEST['product_id'];
            
           
            
            $base_currency = $this->getThePlatformBaseCurrency();
            
            $resource_id = $_REQUEST['id'];
            
            
            
            if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheToolOrTaskPrice($resource_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheToolOrTaskPrice($resource_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
            
            //$_id = 5;
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$_id);
            $product = Products::model()->findAll($criteria);   
                       
                           
                if($product===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "product" => $product,
                           "currency_code"=>$currency_code,
                           "price"=>$price
                               )
                       );
                       
                }
            
            
            
        }
        
        
        /**
         * This is the function that gets the preferred currency for a domain
         */
        public function getThisDomainPreferredCurrency($domain_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='domain_id=:id and status="active"';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= DomainPolicy::model()->find($criteria);
                     
                     return $domain['domain_currency_preference'];
            
            
        }
        
        /**
         * get the preferred currency code
         */
        public function getThisCurrencyCode($preferred_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$preferred_currency);
            $currency = Currencies::model()->find($criteria); 
            
            return $currency['currency_code'];
        }
        
        /**
         * This is the function that fetches the tool or task price
         */
        public function getTheToolOrTaskPrice($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $resource = Resources::model()->find($criteria); 
            
            return $resource['price'];
            
            
        }
        
      /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        
                
        /**
         * This is the function that gets the resource type name
         */
        public function getTheResourcetypeName($resourcetype_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';  
            $criteria->params = array(':id'=>$resourcetype_id);
            $type = ResourceType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        
        /**
         * This is the function that gets the platform base currency
         */
        public function getThePlatformBaseCurrency(){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                    // $criteria->condition='country_id=:id';
                   //  $criteria->params = array(':id'=>$country_id);
                     $platform= PlatformSettings::model()->find($criteria);
                     
                     return $platform['platform_default_currency_id'];
            
        }
        
        /**
         * This is the function that gets the exchange rate of a currency
         */
        public function getThePreferredCurrencyExchangeRate($currency,$base_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='base_currency_id=:baseid and currency_id=:currencyid';
            $criteria->params = array(':baseid'=>$base_currency,':currencyid'=>$currency);
            $currency= CurrencyExchange::model()->find($criteria);
            
            return $currency['exchange_rate'];
        }

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Products the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Products::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Products $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='products-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
