<?php

class SettingsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListSettings','addnewsettings','updatesettings'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all settings
         */
        public function actionListSettings(){
            
            $settings = Settings::model()->findAll();
                if($settings===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "setting" => $settings,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that adds new settings
         */
        public function actionaddnewsettings(){
            
            $model = new Settings;
            
            if($model->isTheRemovalOfTheCurrentSettingASuccess()){
                $model->billing_cutoff_date = date("Y-m-d H:i:s", strtotime($_POST['billing_cutoff_date'])); 
                $model->last_billing_cutoff_date = date("Y-m-d H:i:s", strtotime($_POST['billing_cutoff_date'])); 
                $model->status = "active";
                $model->cutoff_date_created_by = Yii::app()->user->id;
                $model->date_created = new CDbExpression('NOW()');
                
                if($model->save()){
                    $msg = 'A new setting is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                       
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add a new setting failed. Please contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            }else{
                 //$result['success'] = 'false';
                         $msg = 'The attempt to add a new setting failed as the prevailing settings could not be deleteed, Please contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
            }
        }
        
        
        /**
         * This is the function that modifies settings
         */
        public function actionupdatesettings(){
            
             $_id = $_POST['id'];
            $model=Settings::model()->findByPk($_id);
            
            $prevailing_cutoff_date = $model->getThePrevailingCutoffDate($_id);
            
            $model->billing_cutoff_date = date("Y-m-d H:i:s", strtotime($_POST['billing_cutoff_date'])); 
            $model->last_billing_cutoff_date = $prevailing_cutoff_date;
            $model->status = "active";
            $model->cutoff_date_created_by = Yii::app()->user->id;
            $model->date_created = new CDbExpression('NOW()');
                
                if($model->save()){
                    $msg = 'The modification of this setting is successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                       
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to modify this setting failed. Please contact customer service for assistance';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
}
