<?php

class StreetController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrieveextrastreetinfo','deleteastreet','addanewstreet','updatestreet','listAllStreets',
                                    'listAllstreetforacity','getthisstreetname'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that adds new streets
         */
        public function actionaddanewstreet(){
            
            $model=new Street;

                $model->name = $_POST['name'];
                $model->city_id = $_POST['cityname'];
                 if(isset($_POST['is_street_gated'])){
                   $model->is_street_gated = $_POST['is_street_gated']; 
                }
                 if(isset($_POST['street_gate_colour'])){
                   $model->street_gate_colour = $_POST['street_gate_colour']; 
                }
                  if(isset($_POST['street_road_condition'])){
                   $model->street_road_condition = $_POST['street_road_condition']; 
                }
                if(isset($_POST['is_street_with_street_light_facility'])){
                   $model->is_street_with_street_light_facility = $_POST['is_street_with_street_light_facility']; 
                }
                 if(isset($_POST['is_street_light_facilities_working'])){
                   $model->is_street_light_facilities_working = $_POST['is_street_light_facilities_working']; 
                }
                 if(isset($_POST['nearest_busstop_to_the_street'])){
                   $model->nearest_busstop_to_the_street = $_POST['nearest_busstop_to_the_street']; 
                }
                 if(isset($_POST['is_street_guided_with_securities'])){
                   $model->is_street_guided_with_securities = $_POST['is_street_guided_with_securities']; 
                }
                 if(isset($_POST['does_street_allow_commercial_bikes'])){
                   $model->does_street_allow_commercial_bikes = $_POST['does_street_allow_commercial_bikes']; 
                }
                  if(isset($_POST['does_street_allow_commercial_keke'])){
                   $model->does_street_allow_commercial_keke = $_POST['does_street_allow_commercial_keke']; 
                }
                if(isset($_POST['does_street_allow_commercial_buses'])){
                   $model->does_street_allow_commercial_buses = $_POST['does_street_allow_commercial_buses']; 
                }
                if(isset($_POST['location_summary_from_popular_city_landmark'])){
                   $model->location_summary_from_popular_city_landmark = $_POST['location_summary_from_popular_city_landmark']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
               if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New Street Successfully Created';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation of a new street was unsuccessful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
            
        }
        
        
        
        /**
         * This is the function that updates street information
         */
        public function actionupdatestreet(){
            
           //get the city id
            $city = $_POST['cityname'];
          
            
            $_id = $_POST['id'];
            $model=  Street::model()->findByPk($_id);
          if(is_numeric($city)) {
                $model->city_id = $city;
                
            }else{
                              
                $model->city_id = $_POST['city_id'];
                
                
            }
          
              $model->name = $_POST['name'];
             if(isset($_POST['is_street_gated'])){
                   $model->is_street_gated = $_POST['is_street_gated']; 
                }
                 if(isset($_POST['street_gate_colour'])){
                   $model->street_gate_colour = $_POST['street_gate_colour']; 
                }
                  if(isset($_POST['street_road_condition'])){
                   $model->street_road_condition = $_POST['street_road_condition']; 
                }
               if(isset($_POST['is_street_with_street_light_facility'])){
                   $model->is_street_with_street_light_facility = $_POST['is_street_with_street_light_facility']; 
                }
                
                 if(isset($_POST['is_street_light_facilities_working'])){
                   $model->is_street_light_facilities_working = $_POST['is_street_light_facilities_working']; 
                }
                 if(isset($_POST['nearest_busstop_to_the_street'])){
                   $model->nearest_busstop_to_the_street = $_POST['nearest_busstop_to_the_street']; 
                }
                 if(isset($_POST['is_street_guided_with_securities'])){
                   $model->is_street_guided_with_securities = $_POST['is_street_guided_with_securities']; 
                }
                 if(isset($_POST['does_street_allow_commercial_bikes'])){
                   $model->does_street_allow_commercial_bikes = $_POST['does_street_allow_commercial_bikes']; 
                }
                  if(isset($_POST['does_street_allow_commercial_keke'])){
                   $model->does_street_allow_commercial_keke = $_POST['does_street_allow_commercial_keke']; 
                }
                if(isset($_POST['does_street_allow_commercial_buses'])){
                   $model->does_street_allow_commercial_buses = $_POST['does_street_allow_commercial_buses']; 
                }
                if(isset($_POST['location_summary_from_popular_city_landmark'])){
                   $model->location_summary_from_popular_city_landmark = $_POST['location_summary_from_popular_city_landmark']; 
                }
               
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
               if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Street information was updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The update of this street information was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
            
            
        }
        
        
        
        /**
         * This is the function that deletes a street
         */
        public function actiondeleteastreet(){
            
            $_id = $_POST['id'];
            $model=Street::model()->findByPk($_id);
           
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_id);
                $street= Street::model()->find($criteria);
                
                $streetname = $street['name'];
                
                $cityname = $this->getTheNameOfThisCity($street['city_id']);
            
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$streetname' street of '$cityname' city is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = "Attempt to delete '$streetname' street of '$cityname' city  wss  not successful";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        /**
         * This is the function that gets a city name
         */
        public function getTheNameOfThisCity($id){
            $model = new City;
            return $model->getTheNameOfThisCity($id);
        }
        
        
        
        /**
         * This is the function that list all streets 
         */
        public function actionlistAllStreets(){
            
            $street = Street::model()->findAll();
                if($street===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "street" => $street)
                       );
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves extra info for a street
         */
        public function actionretrieveextrastreetinfo(){
            
            $model = new State;
            $city_id = $_REQUEST['city_id'];
            
            //get the name of the 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$city_id);
             $city= City::model()->find($criteria);
             
             $countryname = $model->getTheCountryOfThisState($city['state_id']);
             
             $countryname = $model->getTheCountryOfThisState($city['state_id']);
             
             $statename = $model->getTheNameOfThisState($city['state_id']);
             
             $cityname = $city['name'];
             
             if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "statename" => $statename,
                           "countryname"=>$countryname,
                           "cityname"=>$cityname)
                       );
                       
                }
            
            
        }
        
        
        /**
         * This is the function that list all streets in a city
         */
        public function actionlistAllstreetforacity(){
            
            $city_id = $_REQUEST['city_id'];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='city_id=:id';
             $criteria->params = array(':id'=>$city_id);
             $street= Street::model()->findAll($criteria);
                if($street===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "street" => $street,
                                   
                    
                            ));
                       
                }
            
            
            
        }
        
        
        /**
         * This is the function that gets a street name
         */
        public function actiongetthisstreetname(){
            $street_id = $_REQUEST['street_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$street_id);
            $street= Street::model()->find($criteria);
            
             if($street===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "street"=>$street)
                       );
                       
                }
        }
        
        
       
}
