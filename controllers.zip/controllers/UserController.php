<?php

class UserController extends Controller
{
	
         private $_id;
         protected $passwordCompare;
          private $_userid;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','login','confirmIfUserIsLoggedIn','ListAllUsersInThePlatform','addnewguestuser','resetguestuserpassword'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListAllUserRoles','GetUserPermissions', 'ListAllUsersInCity','ListAllUsersOfThisUsertype',
                                    'ListDevicesForUserForSingleScheduling', 'ChangePasswordByOwner', 'ListCityAndUsertypeForAUser', 'ChangePasswordForOtherUsers',
                                    'ListAllUsersTaskFavourites','RetrieveThisFavouriteTaskName','UpdateFavouriteTask','DeleteOneUserfavourite',
                                    'DetermineIfInUserFavourite','ListAllTasksAssignedToAUser','ListAllTaskRelatedToThisTask','DeleteOneRelatedTask',
                                    'RetrieveAllUserTaskForChaining','ChainSelectedSlaveTasksToMaster','determineToolboxIdGivenToolAndUserId','AddTaskToFavourites',
                                    'ListAllSimilarTasksAcrossUserTools','ListAllSimilarTasksAcrossUserToolboxes','ListAllUsersInThePlatform','listAllDomainUsers',
                                    'getThisUsername','getTheUsernameAndStorageRoom','ListAllAwaitingColleaguesRequest','ListAllMemberColleagues',
                                    'ListAllStaffMembersOfADomain','ListAllCustomerMembersOfADomain','ListAllVendorMembersOfADomain','listallOtherDomainUsers','ObtainUserExtraInformation',
                                    'addanewnonstaffcustomerforadomain','updatingnonstaffcustomerforadomain','listDomainAllUserEmails','listDomainAllUserBvns','listDomainAllUserNin',
                                    'listDomainAllUserPassport','listDomainAllUserDrivingLicenses','listDomainAllUserVotersCard','listTheUserForVerification',
                                    'getUserExtraDetails','listTheNonStaffUserForVerification','listuserallverifiedrequests','ListAllColleaguesForThisMember','ListAllUserMessagableByThisDomainMember',
                                    'createnewdomainadmin','listAllAdminUsers','listDomainAllUsers','retrievethisUserprofile','listAllPlatformUsers','retrieveextrauserinfo',
                                    'retrievethisuserinfo','getThisUserRole'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listallusers','deleteoneuser','Logout', 'GetUserPermissions', 'ListAllUserNeeds','ListAllDomainNeeds','RetrieveThisUserNeedInfo'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new User;

                //get the logged i user
                $user_id = Yii::app()->user->id;
                
                //get the domain id of the logged in user
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
		
                
               $model->email = $_POST['email'];
               $model->username = $_POST['email'];
               if(isset($_POST['city'])){
                   $model->city_id = strtolower($_POST['city']);
                }
                if(isset($_POST['location_id'])){
                   $model->location_id = strtolower($_POST['location_id']);
                }
               $model->lastname = $_POST['lastname'];
               $model->middlename = $_POST['middlename'];
               $model->firstname = $_POST['firstname'];
               $model->type =  strtolower($_POST['type']);
               $model->security_level = strtolower('level0step0');
               $model->security_level_weight = 0;
               //$model->gender = strtolower($_POST['gender']);
              if($model->middlename == ""){
                    $model->name = $model->lastname . ' '. $model->firstname; 
                    
                }else{
                   $model->name = $model->lastname . ' '. $model->middlename . ' ' . $model->firstname; 
                    
                }
             
             if(isset($_POST['bvn'])){
                 $model->bvn = $_POST['bvn'];
             }else{
                $model->bvn =null; 
             } 
             if(isset($_POST['nin'])){
                 $model->nin = $_POST['nin'];
             }else{
                 $model->nin = null;
             }
             if(isset($_POST['pvc'])){
                 $model->pvc = $_POST['pvc'];
             }else{
                 $model->pvc = null;
             } 
             if(isset($_POST['passport_number'])){
                 $model->passport_number = $_POST['passport_number'];
             }else{
                 $model->passport_number=null;
             } 
              if(isset($_POST['passport_issuance_date'])){
                 $model->passport_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['passport_issuance_date'])); 
             }else{
                 $model->passport_issuance_date= null;
             }
              if(isset($_POST['passport_expiry_date'])){
                 $model->passport_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['passport_expiry_date']));   
             }else{
                 $model->passport_expiry_date = null;
             } 
             if(isset($_POST['passport_issuance_authority'])){
                 $model->passport_issuance_authority = $_POST['passport_issuance_authority'];
             }else{
                  $model->passport_issuance_authority=null;
             }
             if(isset($_POST['driving_license_number'])){
                 $model->driving_license_number = $_POST['driving_license_number'];
             }else{
                 $model->driving_license_number = null;
             } 
             if(isset($_POST['license_issuance_date'])){
                 $model->license_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['license_issuance_date']));  
             }else{
                 $model->license_issuance_date=null;
             }
             if(isset($_POST['license_expiry_date'])){
                 $model->license_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['license_expiry_date'])); 
             }else{
                 $model->license_expiry_date = null;
             }
             if(isset($_POST['license_issuance_authority'])){
                 $model->license_issuance_authority = $_POST['license_issuance_authority'];
             }else{
                  $model->license_issuance_authority=null;
             }
             if(isset($_POST['others_identification_number'])){
                 $model->others_identification_number = $_POST['others_identification_number'];
             }else{
                 $model->others_identification_number=null;
             }
              if(isset($_POST['others_issuance_date'])){
                 $model->others_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['others_issuance_date']));   
             }else{
                 $model->others_issuance_date = null;
             }
               if(isset($_POST['others_expiry_date'])){
                 $model->others_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['others_expiry_date']));  
             }else{
                  $model->others_expiry_date = null;
             }
              if(isset($_POST['others_issuance_authority'])){
                 $model->others_issuance_authority = $_POST['others_issuance_authority'];
             }else{
                 $model->others_issuance_authority = null;
             }
                         
              $model->role = "user";
                $model->status = strtolower($_POST['status']);
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                $model->domain_id = $domain_id;
                $password = $_POST['password'];
                $password_repeat = $_POST['passwordCompare'];
             
                
               $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
                
             if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                    
                    if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                         
                  $icon_error_counter = 0;     
                 $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
              if(isset($_FILES['picture']['name'])){
                  if($_FILES['picture']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                       
                       $icon_filename = $_FILES['picture']['name'];
                      $icon_size = $_FILES['picture']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                        //$icon_filename=null;
                        //$icon_size = 0;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideUserIconWhenUnavailable($model);
                    //$icon_filename=null;
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                  
              }else{
                  $icon_filename=$this->provideUserIconWhenUnavailable($model);
                   $icon_size = 0;
              }    
              
            
               
                if($icon_error_counter ==0){
                   if($model->validate()){
                        $model->picture = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                          $model->picture_size = $icon_size;
                           
                if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              // $result['success'] = 'true';
                                $msg = 'User Creation was successful';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                 } else {
                                     $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$name'  was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else if($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your picture file type or size as picture must be of width '$platform_width'px and height '$platform_height'px. Picture is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
             
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                    
                    
                    
                    
           }else{
                    if($model->isThisUserAlreadyCreatedAsOneOfYourDomainStaff($model,$domain_id)){
                        $msg = "'$name' had already been created as one of your staff. You do not have to create him again";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                
                        
                    }else if($model->isThisUserAlreadyAStaffOfAnotherDomain($model,$domain_id)){
                        
                        $msg = "'$name' is already a staff of another domain. You could only add him/her to your domain as a non staff member (customer, vendor etc)";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                    }else if($model->isThisUserAssociatedWithThePlatform($model)){
                        //updating the user detail chaging on the domain id
                        if($model->isTheTransferOfThisPlatformNonStaffMemberToThisDomainASuccess($model,$domain_id)){
                             $msg = "'$name' is successfully added to your staff list";
                             header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                             ));    
                        }else{
                            $msg = "The creation of '$name' as one of your domain staff was not suucessful. Please contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                            
                        }
                    }else{
                        $msg = "The creation of '$name' as one of your domain staff was not suucessful. Please contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                        
                    }
                   
                
                
                
                }  
           

	}
        
        
        
        
        
      

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actioncreatenewdomainadmin()
	{
		$model=new User;

                //get the logged i user
                $user_id = Yii::app()->user->id;
                
                //get the domain id of the logged in user
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
		
                
               $model->email = $_POST['email'];
               $model->username = $_POST['email'];
             /** if(isset($_POST['city'])){
                   $model->city_id = strtolower($_POST['city']);
                }
              * 
              */
               $model->lastname = $_POST['lastname'];
               $model->middlename = $_POST['middlename'];
               $model->firstname = $_POST['firstname'];
               if(isset($_POST['type'])){
                   $model->type = strtolower($_POST['type']);
                }
               $model->security_level = strtolower('level0step0');
               $model->security_level_weight = 0;
               //$model->gender = strtolower($_POST['gender']);
              if($model->middlename == ""){
                    $model->name = $model->lastname . ' '. $model->firstname; 
                    
                }else{
                   $model->name = $model->lastname . ' '. $model->middlename . ' ' . $model->firstname; 
                    
                }
              if(isset($_POST['bvn'])){
                 $model->bvn = $_POST['bvn'];
             }else{
                $model->bvn =null; 
             } 
             if(isset($_POST['nin'])){
                 $model->nin = $_POST['nin'];
             }else{
                 $model->nin = null;
             }
             if(isset($_POST['pvc'])){
                 $model->pvc = $_POST['pvc'];
             }else{
                 $model->pvc = null;
             } 
             if(isset($_POST['passport_number'])){
                 $model->passport_number = $_POST['passport_number'];
             }else{
                 $model->passport_number=null;
             } 
              if(isset($_POST['passport_issuance_date'])){
                 $model->passport_issuance_date =date("Y-m-d H:i:s", strtotime($_POST['passport_issuance_date']));
             }else{
                 $model->passport_issuance_date= null;
             }
              if(isset($_POST['passport_expiry_date'])){
                 $model->passport_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['passport_expiry_date']));// $_POST['passport_expiry_date'];
             }else{
                 $model->passport_expiry_date = null;
             } 
             if(isset($_POST['passport_issuance_authority'])){
                 $model->passport_issuance_authority = $_POST['passport_issuance_authority'];
             }else{
                  $model->passport_issuance_authority=null;
             }
             if(isset($_POST['driving_license_number'])){
                 $model->driving_license_number = $_POST['driving_license_number'];
             }else{
                 $model->driving_license_number = null;
             } 
             if(isset($_POST['license_issuance_date'])){
                 $model->license_issuance_date =date("Y-m-d H:i:s", strtotime($_POST['license_issuance_date'])); 
             }else{
                 $model->license_issuance_date=null;
             }
             if(isset($_POST['license_expiry_date'])){
                 $model->license_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['license_expiry_date'])); 
             }else{
                 $model->license_expiry_date = null;
             }
             if(isset($_POST['license_issuance_authority'])){
                 $model->license_issuance_authority = $_POST['license_issuance_authority'];
             }else{
                  $model->license_issuance_authority=null;
             }
             if(isset($_POST['others_identification_number'])){
                 $model->others_identification_number = $_POST['others_identification_number'];
             }else{
                 $model->others_identification_number=null;
             }
              if(isset($_POST['others_issuance_date'])){
                 $model->others_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['others_issuance_date']));  
             }else{
                 $model->others_issuance_date = null;
             }
               if(isset($_POST['others_expiry_date'])){
                 $model->others_expiry_date =  date("Y-m-d H:i:s", strtotime($_POST['others_expiry_date']));  
             }else{
                  $model->others_expiry_date = null;
             }
              if(isset($_POST['others_issuance_authority'])){
                 $model->others_issuance_authority = $_POST['others_issuance_authority'];
             }else{
                 $model->others_issuance_authority = null;
             }
                
             //$model->maritalstatus = $_POST['maritalstatus'];
               // $model->dateofbirth = $_POST['dateofbirth'];
              $model->role = "domainSuperAdmin";
                $model->status = strtolower($_POST['status']);
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                $model->domain_id = $_POST['domain_id'];
                $password = $_POST['password'];
                $password_repeat = $_POST['passwordCompare'];
             
                
               $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
                
              if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                    
                     if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                         
                  $icon_error_counter = 0;     
                 $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
              if(isset($_FILES['picture']['name'])){
                  if($_FILES['picture']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                       
                       $icon_filename = $_FILES['picture']['name'];
                      $icon_size = $_FILES['picture']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                        //$icon_filename=null;
                        //$icon_size = 0;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideUserIconWhenUnavailable($model);
                    //$icon_filename=null;
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                  
              }else{
                  $icon_filename=$this->provideUserIconWhenUnavailable($model);
                   $icon_size = 0;
              }    
              
            
               
                if($icon_error_counter ==0){
                   if($model->validate()){
                        $model->picture = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                          $model->picture_size = $icon_size;
                           
                if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              // $result['success'] = 'true';
                                $msg = 'User Creation was successful';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                 } else {
                                     $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$name'  was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else if($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your picture file type or size as picture must be of width '$platform_width'px and height '$platform_height'px. Picture is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
             
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                  
         }else{
                $msg = "This user already exist on the platorm. It is either you upgrade his/her role or select a different user as a domain administrrator";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }

	}
        
        
        
       
        
        

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
		$_id = $_POST['id'];
               
             
                //get the domain id of the user in question
                //$domain_id = $this->determineAUserDomainIdGiven($_id);
                
                //$usertype = 1;
               // $city = $_POST['city_id'];
                
                                    
                $model=User::model()->findByPk($_id);
               
                //obtain the current password
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, password';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$_id);
                $current_password= User::model()->find($criteria3);
                
                $model->current_pass = $current_password->password;
                
                
             
                
            /**    if(is_numeric($city)){
                    $model->city_id = $city;
                    
                    
                }else{
                     //derive the city id given the name and the state id 
                     $criteria2 = new CDbCriteria();
                     $criteria2->select = 'id';
                     $criteria2->condition='name=:name';
                     $criteria2->params = array(':name'=>$city);
                     $cityid= City::model()->find($criteria2);
                     
                     $model->city_id = $cityid->id;
                    
                }
             * 
             */
		
                $model->email = $_POST['email'];
                $model->username = $_POST['username'];
                $model->password = '';
                $model->password_repeat = '';  
                $model->lastname = $_POST['lastname'];
                $model->middlename = $_POST['middlename'];
                if(isset($_POST['type'])){
                   $model->type = strtolower($_POST['type']);
                }
                if(isset($_POST['location_id'])){
                   $model->location_id = strtolower($_POST['location_id']);
                }
               $model->security_level = strtolower('level0step0');
               $model->security_level_weight = 0;
                $model->firstname = $_POST['firstname'];
                if($model->middlename == ""){
                    $model->name = $model->lastname . ' '. $model->firstname; 
                    
                }else{
                   $model->name = $model->lastname . ' '. $model->middlename . ' ' . $model->firstname; 
                    
                }
                 if(isset($_POST['bvn'])){
                 $model->bvn = $_POST['bvn'];
             }else{
                $model->bvn =null; 
             } 
             if(isset($_POST['nin'])){
                 $model->nin = $_POST['nin'];
             }else{
                 $model->nin = null;
             }
             if(isset($_POST['pvc'])){
                 $model->pvc = $_POST['pvc'];
             }else{
                 $model->pvc = null;
             } 
             if(isset($_POST['passport_number'])){
                 $model->passport_number = $_POST['passport_number'];
             }else{
                 $model->passport_number=null;
             } 
              if(isset($_POST['passport_issuance_date'])){
                 $model->passport_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['passport_issuance_date'])); 
             }else{
                 $model->passport_issuance_date= null;
             }
              if(isset($_POST['passport_expiry_date'])){
                 $model->passport_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['passport_expiry_date']));
             }else{
                 $model->passport_expiry_date = null;
             } 
             if(isset($_POST['passport_issuance_authority'])){
                 $model->passport_issuance_authority = $_POST['passport_issuance_authority'];
             }else{
                  $model->passport_issuance_authority=null;
             }
             if(isset($_POST['driving_license_number'])){
                 $model->driving_license_number = $_POST['driving_license_number'];
             }else{
                 $model->driving_license_number = null;
             } 
             if(isset($_POST['license_issuance_date'])){
                 $model->license_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['license_issuance_date']));
             }else{
                 $model->license_issuance_date=null;
             }
             if(isset($_POST['license_expiry_date'])){
                 $model->license_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['license_expiry_date']));
             }else{
                 $model->license_expiry_date = null;
             }
             if(isset($_POST['license_issuance_authority'])){
                 $model->license_issuance_authority = $_POST['license_issuance_authority'];
             }else{
                  $model->license_issuance_authority=null;
             }
             if(isset($_POST['others_identification_number'])){
                 $model->others_identification_number = $_POST['others_identification_number'];
             }else{
                 $model->others_identification_number=null;
             }
              if(isset($_POST['others_issuance_date'])){
                 $model->others_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['others_issuance_date']));
             }else{
                 $model->others_issuance_date = null;
             }
               if(isset($_POST['others_expiry_date'])){
                 $model->others_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['others_expiry_date']));
             }else{
                  $model->others_expiry_date = null;
             }
              if(isset($_POST['others_issuance_authority'])){
                 $model->others_issuance_authority = $_POST['others_issuance_authority'];
             }else{
                 $model->others_issuance_authority = null;
             }
                $model->role = $_POST['role'];
                $model->status = $_POST['status'];
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                $model->domain_id = $_POST['domain_id'];
               // $model->usertype_id = 1;
                
                
                
            /**    if(($_FILES['picture']['name'] == null)){
                    
                    $this->saveUserInfoWithoutPicture($model, $_id);
                    
                    
                }
                
                if(($_FILES['picture']['name'] != null)){
                    $picture = $_FILES['picture']['name'];
                    
                    $this-> saveUserInfoWithPictureInclusive($model, $picture, $_id);
                    
                }
             * 
             */
              //get the domain name
                $user_name = $this->getTheUsername($_id);
                
                $icon_error_counter  = 0;
                
                if($_FILES['picture']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['picture']['name'];
                       $icon_size = $_FILES['picture']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    //$model->icon = $this->retrieveThePreviousIconName($_id);
                    $icon_filename = $this->retrieveThePreviousIconName($_id);
                    $icon_size = $this->retrieveThePrreviousIconSize($_id);
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->picture = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->picture_size = $icon_size;
                           
                 if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              // $result['success'] = 'true';
                                $msg = 'User update was successful';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                 } else {
                                     $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$user_name' information update was not successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your picture file type or size as picture must be of width '$platform_width'px and height '$platform_height'px. Picture is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }  
	}
        
        
        /**
             * This is the function that gea user name
             */
            public  function getTheUsername($user_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$user_id);
                $user= User::model()->find($criteria);
                
                $name = $user['firstname']." ".$user['middlename']. " ". $user['lastname'];
                
                return $name;
                
            }

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneUser()
	{
            //delete one user
            $_id = $_POST['id'];
            $model=User::model()->findByPk($_id);
            if($model === null){
                $msg = "This model is null and there no data to delete";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                                      
            }elseif($model->delete()){
                    
                    if($this->deleteRoleAssignedToAUser($model->role, $_id)){
                        $msg = "User was successfully deleted";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "msg" => $msg)
                       );
                        
                        
                    }else {
                        $msg = "The user was deleted but his/her record(s) still exist in the role assignment table";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                        
                        
                    }
                    
            } else {
                    $msg = "User record deletion was not successful";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                            
                }
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('User');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListAllUsers()
	{
		
            $userid = Yii::app()->user->id; 
            //get the domain of the logged in user
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
          if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformUserSupport")){
           $criteria4 = new CDbCriteria();
           $criteria4->select = '*';
           $criteria4->condition='type=:type';
           $criteria4->params = array(':type'=>"staff");
           $user= User::model()->findAll($criteria4);
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                      echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "users" => $user
            
                       ));
                       
                }
         
           }else{
               //retrieve only domain users 
               $criteria4 = new CDbCriteria();
                $criteria4->select = '*';
                $criteria4->condition='domain_id=:domainid and type=:type';
                $criteria4->params = array(':domainid'=>$domain_id,':type'=>"staff");
                $user= User::model()->findAll($criteria4);
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "users" => $user
            
                       ));
                       
                } 
               
           }
	}
        
        
        
        /**
         * This is the function that list all domain users
         */
        
        public function actionlistAllDomainUsers(){
            
            $userid = Yii::app()->user->id; 
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($userid);    
            
             //retrieve only domain users 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';
             $criteria->params = array(':domainid'=>$domain_id);
             $users= User::model()->findAll($criteria);
                if($users===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "user" => $users
            
                       ));
                       
                } 
            
        }
        
        /**
	 * Manages all models.
	 */
	public function actionListAllUsersInThePlatform()
	{
		
            $userid = Yii::app()->user->id; 
            //get the domain of the logged in user
            
            
             $user = User::model()->findAll();
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($user);
                       
                }
         
           
	}
        
        /**
         * This is the function that will list all roles in the platform
         */

        public function actionListAllUserRoles()
	{
		
            
                $criteria = new CDbCriteria();
                $criteria->select = 'name';
                $criteria->condition='type=2';              
                $userrole= Authitem::model()->findAll($criteria);
               
                if($userrole===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            
                            "data" => $userrole)
                       );
                       
                }
	}
        
        /*
   * Obtain the users permissions
   */
  public function actionGetUserPermissions(){

    //ini_set('max_execution_time', 300);
    $_userid = Yii::app()->user->id;
    //retrieve all the authitem assigned to this user
    $criteria2 = new CDbCriteria();
    $criteria2->select = 'itemname';
    $criteria2->condition='userid=:id';
    $criteria2->params = array(':id'=>$_userid);
    $authitems= AuthAssignment::model()->findAll($criteria2);
	
    $iten = [];
    
    $itemtype = [];
    $permissions = [];
    $operations = [];
    $tasks = [];
    $roles = [];
    $i = 0;
    foreach($authitems as $item){ 
	//determine the type of the itemname	
	$iten[$i] = $item->itemname;
        $criteria3 = new CDbCriteria();
        $criteria3->select = 'name, type';
        $criteria3->condition='name=:name';
        $criteria3->params = array(':name'=>$iten[$i]);
        $authtype= Authitem::model()->findAll($criteria3);
            
       //$itemtype;
        $operations_children = [];
        $tasks_children = [];
        $roles_children = [];
        
        foreach($authtype as $item){
           // $type = $item->type;
            if($item->type == 0){
		//$itemname = $authtype->name;
                $operation_children = $this->getAllOperationChildren($item->name);
                //$operations_children = $operations_children + $operation_children;
               $operations = array_merge($operations, $operation_children);
            } elseif($item->type == 1) { //end of the authtype->type=0 statement
				
		$task_children = $this->getTaskOperationChildren($item->name);
                // $tasks_children = $tasks_children + $task;
                 $tasks = array_merge($tasks, $task_children);
			
            }elseif($item->type == 2){//end of the authtype->type=1 statement
		$role_children = $this->getRoleOperationChildren($item->name);
                //$roles_children = $roles_children + $role;
                 $roles = array_merge($roles, $role_children);
			
	    }//end of the authtype->type=2 statement
		
        }
		
           $i = $i + 1;
   } //end of the $authitems foreach loop
   header('Content-Type: application/json');
   echo CJSON::encode(array(
        "success" => mysqli_connect_errno() == 0,
       "operations"=>$operations,
       "tasks"=>$tasks,
       "roles"=>$roles
         ));
} //end of the function


/*
 * Get all the operations permisions
 */
public function getAllOperationChildren($itemname){
    
    //determine the children of the task authitem
    $item = [];
    $i = 0;
    
    $permissions = [];
    //foreach($itemname as $operationitem ){
        //$item[$i] = $operationitem->name;
        $criteria8 = new CDbCriteria();
        $criteria8->select = 'child';
        $criteria8->condition='parent=:parent';
        $criteria8->params = array(':parent'=>$itemname);
        $operationchildren= Authitemchild::model()->findAll($criteria8);
        
        //determine the type of the child
        $childtype = [];
        if($operationchildren !== []){
        foreach($operationchildren as $child){
            $criteria9 = new CDbCriteria();
            $criteria9->select = 'name, type';
            $criteria9->condition='name=:name';
            $criteria9->params = array(':name'=>$child->child);
            $childrentype= Authitem::model()->findAll($criteria9);
            
            //process the role  child depending on its type
            $operation_in_operation = [];
            foreach($childrentype as $type){
            if($type->type == 0){
                 $operation_in_operation = getAllOperationChildren($type->name);
                 $permissions = array_merge($permissions ,$operation_in_operation);
            }//end of the else $childtype if statement
            }
            
        }//end of the $operationchildren as $childtype foreach statement
        $i = $i + 1;
    }else {
        $permissions = array_merge($permissions, array($itemname));
        return array(
            $permissions
        );
    }
   // }//end of the $itemname as $operationitem foreach statement
    
    return array(
        
        $permissions
     ); 
    
    
}//end of the function
  
/*
 * Get all the operations that makes up the task
 */
public function getTaskOperationChildren($itemname){
    
    //determine the children of the task authitem
    $item = [];
    $i = 0;
    
    $permissions = [];
    
   // foreach($itemname as $taskitem ){
       // $item[$i] = $taskitem->name;
        $criteria6 = new CDbCriteria();
        $criteria6->select = 'child';
        $criteria6->condition='parent=:parent';
        $criteria6->params = array(':parent'=>$itemname);
        $taskchildren= Authitemchild::model()->findAll($criteria6);
        
        //determine the type of the child
        if($taskchildren !== []){
        $childtype = [];
        foreach($taskchildren as $child){
            $criteria7 = new CDbCriteria();
            $criteria7->select = 'name, type';
            $criteria7->condition='name=:name';
            $criteria7->params = array(':name'=>$child->child);
            $childrentype= Authitem::model()->findAll($criteria7);
            
            //process the role  child depending on its type
            $task_in_task = [];
            $operation_in_task = [];
            foreach($childrentype as $type){
            if($type->type == 0){
                 $operation_in_task = $this->getAllOperationChildren($type->name);
                 $permissions = array_merge($permissions, $operation_in_task);
            }elseif($type->type == 1){
                $task_in_task = $this->getTaskOperationChildren($type->name);
                $permissions = array_merge($permissions ,$task_in_task);
                
            }//end of the else $childtype if statement
        }
            
        }//end of the $taskchiledren as $childtype foreach statement
        $i = $i + 1;
    } else {
        
        $permissions = array_merge($permissions, array($itemname));
        return array(
            $permissions
        );
    } 
  //  }//end of the $itemname as $taskitem foreach statement
    
    return array(
        
        $permissions
      );
        
    
    
}//end of the function



/*
 * Get all the operations that makes up the role
 */
public function getRoleOperationChildren($itemname){
    
    //determine the children of the role authitem
    $item = [];
    $i = 0;
    
    $permissions = [];
    //foreach($itemname as $roleitem ){
       // $item[$i] = $roleitem['name'];
        $criteria4 = new CDbCriteria();
        $criteria4->select = 'child';
        $criteria4->condition='parent=:parent';
        $criteria4->params = array(':parent'=>$itemname);
        $rolechildren= Authitemchild::model()->findAll($criteria4);
        
        //determine the type of the child
        if($rolechildren !== []){
        $childtype = [];
        $operation_in_role = [];
        $task_in_role = [];
        $role_in_role = [];
        foreach($rolechildren as $childname){
            $criteria5 = new CDbCriteria();
            $criteria5->select = 'name, type';
            $criteria5->condition='name=:name';
            $criteria5->params = array(':name'=>$childname->child);
            $childrentype= Authitem::model()->findAll($criteria5);
            
            //process the role  child depending on its type
            foreach($childrentype as $type){
            if($type->type == 0){
                 $operation_in_role = $this->getAllOperationChildren($type->name);
                  $permissions = array_merge($permissions, $operation_in_role);
            }elseif($type->type == 1){
                $task_in_role = $this->getTaskOperationChildren($type->name);
                $permissions = array_merge($permissions ,$task_in_role);
            }elseif($type->type == 2){
                $role_in_role = $this->getRoleOperationChildren($type->name);
                $permissions = array_merge($permissions, $role_in_role);
                
            }//end of the else $childtype if statement
          } 
            
        }//end of the $rolechiledren as $childtype foreach statement
       
        $i = $i + 1;
    } else {
        $permissions = array_merge($permissions, array($itemname));
        return array(
            $permissions
        );
    }
   // }//end of the $itemname as $roleitem foreach statement
    
    return array(
        $permissions
        );
       
    
    
}//end of the function
        
        /**
	 * Displays the login page
         * 
         */
	
         
          
	public function actionLogin()
	{
		
             $model = new User('login');
            
                                             
               
                              
                $model->username = $_POST['username'];
                $model->password = $_POST['password'];
                
                //determine the users id
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='username=:name';
                $criteria->params = array(':name'=>$_POST['username']);
                $id = User::model()->find($criteria);   
                
               $firstname = $id['firstname'] . " ". $id['lastname'];
              //validate the users logon credentials
              
         if($this->validatePassword($model, $id->id,$model->password) && $model->login()) {
           // if($model->login()) {
                      header('Content-Type: application/json');
                      $msg = "$firstname";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg,
                           "firstname"=>$id['firstname']
                            )
                           
                       );
          // }  

        }else {
                     header('Content-Type: application/json');
                      $msg= 'Incorrect username or password.';
                     echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                         "firstname"=>$id['firstname']
                             )
                       );
                       
                }
                
            
                
		
		
	}
        
        
         /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		//$this->redirect(Yii::app()->homeUrl);
                header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
	}
        
        
        /**
	 * List all the cities that belong to a particular state
	 */
	public function actionListAllUsersInCity()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 12;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='city_id=:id';
                $criteria->params = array(':id'=>$_id);
                $user= User::model()->findAll($criteria);
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($user);
                       
                }
	}
        
        
         /**
	 * List all the cities that belong to a particular state
	 */
	public function actionListAllUsersOfThisUsertype()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 12;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='usertype_id=:id';
                $criteria->params = array(':id'=>$_id);
                $user= User::model()->findAll($criteria);
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($user);
                       
                }
	}
        
        
        
         /**
	 * List all the Devices for a User for single scheduling
	 */
	public function actionListDevicesForUserForSingleScheduling()
	{
		
             $user_id = $_REQUEST['user_id'];
             $device_id = $_REQUEST['device_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, uuid';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$device_id);
             $device = Device::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, firstname, middlename, lastname';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$user_id);
             $user = User::model()->findAll($criteria2);
               
                if($device===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "user" => $user,
                            "device" => $device)
                       );
                       
                } 
               
               
	}
        
        
        /**
	 * perform own password change
	 */
	public function actionChangePasswordByOwner()
	{
		
            //obtain the current password from the database
            $userid = Yii::app()->user->id;
            
            $model = User::model()->findByPk($userid); 
                        
            $current_password = $_POST['password'];
            $password = $_POST['new_password'];
            $password_repeat = $_POST['password_repeat'];
                 
            //determine the value of the stored passwoord
            
            $criteria2 = new CDbCriteria();
            $criteria2->select = 'id, password';
            $criteria2->condition='id=:id';
            $criteria2->params = array(':id'=>$userid);
            $user = User::model()->find($criteria2);
            
            //ascertain that the new password is the same with the stored password
            if($model->hashPassword($current_password) === $user->password){
                               
                if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                                    //$model->password = $model->hashPassword($newpassword);
                            if($model->save()){
                                $msg = 'Password was successfully changed';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                         "msg" => $msg,
                                ));
                 
                            }else{
                            $msg = 'Password change was not successful';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                     "msg" => $msg,
                             ));  
                 
                         }
                                
                                
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
                //effect the change 
              /**
              $cmd =Yii::app()->db->createCommand();  
              $cmd->update('user',
                	array('password'=>$password,
	         	),
			"id = $userid"
		);
               * 
               */
             
              
                
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                
                
            }else{
                 $msg = 'Invalid current password. Try again';
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
            
            
            
             
             
            
                        
             
               
               
	}
        
        
        /**
	 * perform password change for other users
	 */
	public function actionChangePasswordForOtherUsers()
	{
		
            //obtain the current password from the database
            $_id = $_POST['id'];
            
            $model = User::model()->findByPk($_id); 
           // $model->scenario = 'password_reset';
                        
            $password_repeat = $_POST['password_repeat'];
            $password = $_POST['new_password'];
            
            $model->password = $password;
            $model->password_repeat = $password_repeat;
            
            //determine if the password meet the specified length
              if($model->getPasswordMinLengthRule($password)){
                    if($model->getPasswordMaxLengthRule($password )){
              
                                     
                        //determine if the password matches the specified patterns
                      if($model->getPasswordCharacterPatternRule($password)){
              
              
                       
                               //ascertain that the new password is the same with the stored password
                
                
            
                             if($password === $password_repeat){
                                 
                                 //$model->password = $password;                
                               if($model->validate()){ 
                               // $model->password = md5($password);
                               //$model->password = $model->hashPassword($password);
                           
                                 if($model->save()){
                                        $msg = 'Password was successfully changed';
                                         header('Content-Type: application/json');
                                          echo CJSON::encode(array(
                                          "success" => mysqli_connect_errno() == 0,
                                          "msg" => $msg,
                                        ));
                 
                                }else{
                                     $msg = 'Password change was not successful';
                                    header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                   )); 
                                 
                             }   
                                  
                 
                        }else{
                              $msg = 'Validation error detected';
                                    header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                   )); 
                             
                         }
                      
                     
              
                
                
                        }else{
                            $msg = 'Confirm Password do not match the new password';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                
                
            }
                            
                            
                       
       }else{
             $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
            
            
            
        }
       
      
                        
                        
                        
                        
        }else{
            $msg = 'The maximum Password length allowed is sixty(60)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
            
            
        }
                   
                   
                   
                   
               }else{
                   $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                   
                   
               }
        
        
               
               
	}
        
             
        
        
        /**
         * 
         * @param type $model
         * Save user information during creation and  update without the user picture
         */
        
        public function saveUserInfoWithoutPicture($model, $userid=null){
            if($_FILES['picture']['name'] == null AND $model->id === null) {
                $model->picture = $this->provideUserIconWhenUnavailable($model);
                if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              // $result['success'] = 'true';
                                $msg = 'User Creation/Update was successful';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                 } else {
                                     $msg = 'User creation/Update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'User creation/Update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
            
                
                
            }elseif($_FILES['picture']['name'] == null AND $model->id !== null) {
                
                if($model->validate()){
                     if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              // $result['success'] = 'true';
                                $msg = 'User Creation/Update was successful';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                 } else {
                                     $msg = 'User creation/Update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'User creation/Update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                    
                }else{
                    
                    $msg = 'There is a validation issue';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                }
               
                
            }
                
            
            
        }
        
        /**
         * 
         * @param type $model
         * @param type $picture
         * save user information with the picture during creation and update
         */
        
        public function saveUserInfoWithPictureInclusive($model, $picture, $userid=null){
            
           // $userid = Yii::app()->user->id;
            if(isset($_FILES['picture']['tmp_name'])){
                    $tmpName = $_FILES['picture']['tmp_name'];
                    $fileName = $_FILES['picture']['name'];
                    $type = $_FILES['picture']['type'];
                    $size = $_FILES['picture']['size'];
                  
                }
               if($fileName !== null) {
                      $iconFileName = time().'_'.$fileName;
                      $model->picture = $iconFileName;
                }
                //Testing for the file extension and size
                if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                   if($size <= 256 * 256 * 2){
                    if($model->validate()){
                        if($model->save())
                     {
                     // upload the file
                     if($fileName !== null) // validate to save file
                          $filepath = Yii::app()->params['users'].$iconFileName;
                            move_uploaded_file($tmpName,  $filepath);
                           
                            //assign primary role to the user in the authassignment table
                             $cmd1 =Yii::app()->db->createCommand();
                          if(isset($model->role)){
                              //assign the role to the user
                             if($this->assignRoleToAUser($model->role, $model->id)){
                                 $msg = 'User Creation/Update was successful';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                     "msg" => $msg)
                                    );
                                 
                                 
                             }else{
                                 $msg = 'User creation/Update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                 
                             } 
                             
                          }else{
                              $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                              
                              
                          }
                           
                          
                    }else {
                            $msg = 'User creation/Update was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
                        
                    }else {
                        $msg = 'There is a validation issue';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                        
                    }
                     
                   }else {
                       $msg = 'Icon/Image file is too large: Maximum file size allowed is 131kb';
				header('Content-Type: application/json');
				echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                    );                  
                   }
                   
                }else {
                    $msg = 'Wrong file Type. Only jpeg or jpg or png file is allowed ';
                         header('Content-Type: application/json');
			   echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg)
                          );
                    
                    
                }
            
        }
        
        
         /**
	 * List the city and usertype base on the city id and the usertype id
	 */
	public function actionListCityAndUsertypeForAUser()
	{
            $user_id = Yii::app()->user->id;
            
            //get the user domain
            $user_domain = $this->determineAUserDomainIdGiven($user_id);
             $city_id = $_REQUEST['city_id'];
             $domain_id = $_REQUEST['domain_id'];
            // $usertype_id = $_REQUEST['usertype_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, state_id';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$city_id);
             $city = City::model()->find($criteria);   
             $city_name = $city['name'];
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:domainid';
             $criteria2->params = array(':domainid'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria2);
              $domain_name = $domain['name'];
              
              
        
               
                if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "city" => $city_name,
                           "domain"=>$domain_name
                           // "usertype" => $usertype
                               )
                       );
                       
                } 
               
               
	}
        
        
        
        /**
	 * Assign new role to a user 
	 */
	public function assignRoleToAUser($role, $userid)
	{
		
             //confirm that the role exist in the authitem table
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('authitem')
                    ->where('name' == $role);
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    //confirm if the user aleady had been assigned a role before
                    $cmd =Yii::app()->db->createCommand();
                        $cmd->select('COUNT(*)')
                        ->from('authassignment')
                         ->where('userid' == $userid);
                    $result1 = $cmd->queryScalar();
                    
                     if($result1 > 0){
                         //delete the previous role(s) of the user and insert the new role
                          $cmd->delete('authassignment', 'userid=:id', array(':id'=>$userid ));
                         
                         
                     }
                     $cmd->insert('authassignment',
                                        array(
                                           'userid'=>$userid,
                                           'itemname'=>$role,
                                          
                     ));
                   /** $msg = 'New Role Successfully assigned to User';
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg
                            
                       ));
                    * 
                    */
                    return true;
                    
                    
                }else{
                   /** $msg = 'This role do not exist';
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg
                            
                       ));
                    * 
                    */
                    return false;
                }
         
               
	}
        
        
        /**
	 * delete a role assigned to a user 
	 */
	public function deleteRoleAssignedToAUser($role, $userid)
	{
            //determine if the role actually was assigned to the user
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('authassignment')
                    ->where('itemname' == $role and 'userid'==$userid);
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    //delete the role and assignment to the user
                     $cmd->delete('authassignment', 'userid=:id and itemname=:item', array(':id'=>$userid, ':item'=>$role ));
                      /**$msg = 'New Role assignment was successfully deleted';
                      header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg
                            
                       ));
                       * 
                       */
                    return true;
                }else{
                  /** $msg = 'This role was never assigned to this user';
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg      
                       )); 
                   * 
                   */
                    return false;
                    
                }
                
		
             
               
	}
        
          /**
        * Provide icon when unavailable
	 */
	public function provideUserIconWhenUnavailable($model)
	{
		return 'user_unavailable.png';
	}
        
        
         /*
         * validate the password during authorisation
         */
        public function validatePassword($model, $id, $password){
         
            //determine the existing password
            
           $criteria = new CDbCriteria();
           $criteria->select = 'id, password';
           $criteria->condition='id=:id';
           $criteria->params = array(':id'=>$id);
           $existing_password = User::model()->find($criteria);   
        
           return $model->hashPassword($password)=== $existing_password->password;
           
            
        }
        
      
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
         
        
        
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourceGroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourceGroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourceGroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourceGroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        
        
        /**
         * This is the function that retrieves the name of resource item/task
         */
        public function actionRetrieveThisFavouriteTaskName(){
            
            $resourceid = $_POST['resource_id'];
            
            $resourcename = $this->determineResourceOrToolName($resourceid);
            
            if($resourcename===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "name" =>$resourcename,  
                           
                          
                       ));
                       
                } 
        }
        
        /**
         * This is the function to update favourite task item
         */
        public function actionUpdateFavouriteTask(){
           
            $userid = $_POST['user_id'];
            $resourceid = $_POST['resource_id'];
            
            if(isset($_POST['description'])){
                $description = $_POST['description'];
            }
            
            $cmd =Yii::app()->db->createCommand();  
             $result = $cmd->update('user_has_favourites',
                	array(
                              	'description' => $description
					
					
			),
			"resource_id = $resourceid and  user_id = $userid"
		);
             
             if($result>0){
                 $msg = 'Favourite Item Information successfully updated';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 
             }else{
                 $msg = 'Favourite Item Information was successfully updated';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                 
             }
             
             
            
        }
        
        /**
         * This is the function to delete a user's favourite item
         */
        public function actionDeleteOneUserfavourite(){
            
            $_id = $_REQUEST['resource_id'];
            $userid = $_REQUEST['user_id'];
            
            $cmd =Yii::app()->db->createCommand();  
            
            $result = $cmd->delete('user_has_favourites', 'resource_id=:id and user_id=:user',
                    array(':id'=>$_id, ':user'=>$userid ));
            
            if($result>0){
                $msg = 'Favourite Item Successfully Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                
            }else{
                 $msg = 'Deletion of item not successful'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                
            }
                
            
        }
        
        /**
         * This is the function that determines if task is in users favourite
         */
        public function actionDetermineIfInUserFavourite(){
           $resourceid = $_REQUEST['resource_id'];
          $userid = $_REQUEST['user_id'];
           
          // $resourceid = 4;
           //$userid = 1;
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_favourites')
                    ->where("user_id=$userid and resource_id=$resourceid");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "hasTask" => true
                            //"category" =>$category,
                           
                           
                          
                       ));
                    
                }else{
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "haskTask" => false
                            //"category" =>$category,
                           
                           
                          
                       ));
                }
                
                
            
        }
        
        
        /**
         * This is the function that determines all tools assigned to a user
         */
        public function determineAllToolsAssignedToThisUser($userid){
            
            $allusertoolboxes = [];
            //determine all toolboxes assigned to this user
            
            $usertoolboxes = $this->determineAllToolboxesAssignedToThisUser($userid);
            
            $allusertoolboxes = array_merge($allusertoolboxes, $usertoolboxes);
                  
           
            //determine all subgroups this user was assigned to
            $usersubgroups = $this->determineAllUserSubgroups($userid);
            
            if($usersubgroups != null or $allusertoolboxes !=null ){
                //determine all toolboxes assigned to this subgroup
           
                
            if($usersubgroups != null){
                
                $allsubgrouptoolboxes = [];
            foreach($usersubgroups as $usersubgroup){
                
                $criteria1 = new CDbCriteria();
                $criteria1->select = 'subgroup_id, resourcegroup_id';
                $criteria1->condition='subgroup_id=:id';
                $criteria1->params = array(':id'=>$usersubgroup);
                $toolboxes= SubgroupHasResourcegroup::model()->findAll($criteria1);
                
               $allsubgrouptoolboxes = array_merge($allsubgrouptoolboxes, $toolboxes);
                
            }
                
             foreach($allsubgrouptoolboxes as $allsubgrouptoolbox){
                
                  $allusertoolboxes[] = $allsubgrouptoolbox['resourcegroup_id'];
            }
            
             //determine all the group for each subgroup
            $allgroups = [];
            foreach($usersubgroups as $subgroup){
                
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, group_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$subgroup);
                $groups= SubGroup::model()->find($criteria2);
                
                $allgroups[] = $groups['group_id'];
                
            }
            
            //determine all toolboxes assigned to these groups
            $allgrouptoolboxes = [];
            foreach($allgroups as $allgroup){
                
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'group_id, resourcegroup_id';
                $criteria3->condition='group_id=:id';
                $criteria3->params = array(':id'=>$allgroup);
                $grouptoolboxes= GroupHasResourcegroup::model()->findAll($criteria3);
                
                $allgrouptoolboxes = array_merge($allgrouptoolboxes,$grouptoolboxes);
                
            }
           
            foreach($allgrouptoolboxes as $allgrouptoolbox){
                
                $allusertoolboxes[] = $allgrouptoolbox['resourcegroup_id'];
            }
            
            //make the toolbox array unique
            
            }  //end of the subgroup not null if statement  
            
            
            $uniquetoolboxes = array_unique($allusertoolboxes,SORT_REGULAR);
           
            $allusertools = [];
           
            foreach($uniquetoolboxes as $uniquetoolbox){
                
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'resource_id, resourcegroup_id';
                $criteria4->condition='resourcegroup_id=:id';
                $criteria4->params = array(':id'=>$uniquetoolbox);
                $tools= ResourceHasResourcegroups::model()->findAll($criteria4);
                
                $allusertools = array_merge($allusertools,$tools);
                
                
            }
             $alltools = [];
             foreach($allusertools as $allusertool){
                 
                 $alltools[] = $allusertool['resource_id'];
             }
             
             //make the tools unique
             $uniquetools = array_unique($alltools,SORT_REGULAR);
                       
             //return $uniquetools;
             
             if($uniquetools===null) {
                return null;
            
         }else{
              
            return $uniquetools;
            
         } 
             
         }//end of the subgroup not null loop
       
         
            
        }
        
        
        /**
         * This is the function that determines all toolboxes directly assigned to a user
         */
        public function determineAllToolboxesAssignedToThisUser($userid){
            
             $alltoolboxes = [];
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, resourcegroup_id';
             $criteria4->condition='user_id=:id';
             $criteria4->params = array(':id'=>$userid);
             $toolboxes= UserHasResourcegroup::model()->findAll($criteria4);
             
             foreach($toolboxes as $toolbox){
                 
                 $alltoolboxes[] = $toolbox['resourcegroup_id'];
                 
             }
             
             //make it unique
             $uniquetoolboxes = array_unique($alltoolboxes);
             
             return $uniquetoolboxes;
             
           
        }
        
        
        /**
         * This is the function that determines all user's subgroup
         */
        public function determineAllUserSubgroups($userid){
            
            $allsubgroups = [];
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, subgroup_id';
             $criteria4->condition='user_id=:id';
             $criteria4->params = array(':id'=>$userid);
             $subgroups= UserHasSubgroups::model()->findAll($criteria4);
             
             foreach($subgroups as $subgroup){
                 
                 $allsubgroups[] = $subgroup['subgroup_id'];
                 
                 //make it unique
             $uniquesubgroup = array_unique($allsubgroups);
             
             return $uniquesubgroup;
             }
             
            
            
        }
        
       
        /**
         * This is the function that retrieves all task assigned to a user
         */
        public function actionListAllSimilarTasksAcrossUserTools(){
            
            $taskname = $_REQUEST['name'];
            $toolid = $_REQUEST['toolid'];
            //retrieve the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //$taskname = "Excel2010, word 2010";
            //$toolid = 3;
            $string = preg_replace('/\s/', '', $taskname);
            $singleTasks = explode('+',$string);
                     
            $allusertasks = [];
            
            foreach($singleTasks as $singleTask){
                   $q = "SELECT id FROM resources where parent_id=$toolid and name REGEXP '$singleTask'" ;
                    $cmd = Yii::app()->db->createCommand($q);
                    $results = $cmd->query();
                    foreach($results as $result){
                     $allusertasks[] = $result['id'];
                    }
               }
                
                
            
            
            $similar_task = [];
            
            foreach($allusertasks as $allusertask){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$allusertask);
                $tasks= Resources::model()->findAll($criteria);
                
                $similar_task = array_merge($similar_task, $tasks);
            }
            
            
            
            if($similar_task===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "task" =>$similar_task
                            //"string" =>$singleTasks
                           
                           
                          
                       ));
                       
                } 
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all task assigned to a user
         */
        public function actionListAllSimilarTasksAcrossUserToolboxes(){
            
            //retrieve the id of the logged in user
            $userid = Yii::app()->user->id;
            
           $taskname = $_REQUEST['name'];
           // $toolid = $_REQUEST['toolid'];
           //$taskname = "Excel2010 + word";
            $string = preg_replace('/\s/', '', $taskname);
            $singleTasks = explode('+',$string);
            $usertools = $this->determineAllToolsAssignedToThisUser($userid);
            
            $allusertasks = [];
            
            foreach($usertools as $usertool){
               foreach($singleTasks as $singleTask){
                   $q = "SELECT id FROM resources where parent_id=$usertool and name REGEXP '$singleTask'" ;
                    $cmd = Yii::app()->db->createCommand($q);
                    $results = $cmd->query();
                    foreach($results as $result){
                     $allusertasks[] = $result['id'];
                    }
               }
                
                
            }
            
            $similar_task = [];
            
            foreach($allusertasks as $allusertask){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$allusertask);
                $tasks= Resources::model()->findAll($criteria);
                
                $similar_task = array_merge($similar_task, $tasks);
            }
            
            
            
            if($similar_task===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "task" =>$similar_task,
                            "string" =>$singleTasks
                           
                           
                          
                       ));
                       
                } 
            
            
            
        }
        
        
        
        
        /**
         * This is the function that list all task related to a particular task
         */
        public function actionListAllTaskRelatedToThisTask(){
            
            //logged in user is
            $userid = Yii::app()->user->id;
            
            $id = $_REQUEST['id'];
            //$id = 4;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='master_id=:id and user_id=:user';
            $criteria->params = array(':id'=>$id, ':user'=>$userid);
            $slavetasks= TaskToTask::model()->findAll($criteria);
            
            if($slavetasks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "task" =>$slavetasks
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            
        }
        
        /**
         * This is the function that retreives all information about both the master 
         * and the slave task for the purpose of chaining 
         */
        public function actionRetrieveAllUserTaskForChaining(){
            
           //logged in user is
            $userid = Yii::app()->user->id;
            
            $id = $_REQUEST['id'];
            //$id = 4;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='master_id=:id and user_id=:user';
            $criteria->params = array(':id'=>$id, ':user'=>$userid);
            $slavetasks= TaskToTask::model()->findAll($criteria);
            
            //list all task for this user
            $usertools = $this->determineAllToolsAssignedToThisUser($userid);
            
            $allusertasks = [];
            
            foreach($usertools as $usertool){
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='parent_id=:id';
                $criteria1->params = array(':id'=>$usertool);
                $tasks= Resources::model()->findAll($criteria1);
                
                $allusertasks = array_merge($allusertasks, $tasks);
                
            }   
            
            //get the parent id of the given task
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, parent_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$id);
                $parent= Resources::model()->find($criteria2);
                
                //get the name of the parent id
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, name';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$parent['parent_id']);
                $parentname= Resources::model()->find($criteria3);
                
                
                if($slavetasks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "alltasks" => $allusertasks,
                            "slaves" =>$slavetasks,
                            "toolname" =>$parentname
                           
                           
                          
                       ));
                       
                } 
            
            
        }
        
        /**
         * This is the function to delete one related task
         */
        public function actionDeleteOneRelatedTask(){
            
            $_id = $_REQUEST['id'];
            $taskid = $_REQUEST['related_task_id'];
            
            $cmd =Yii::app()->db->createCommand();  
            
            $result = $cmd->delete('task_to_task', 'master_id=:id and slave_id=:taskid',
                    array(':id'=>$_id, ':taskid'=>$taskid ));
            
            if($result>0){
                $msg = 'Slave Document Successfully Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                
            }else{
                 $msg = 'Deletion of the Slave Document was not successful'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                
            }
            
        }
        
        
        /**
         * This is the function that saves slave tasks against a master task 
         */
        public function actionChainSelectedSlaveTasksToMaster(){
            
            //logged on user id is
            $userid = Yii::app()->user->id;
            
            $id = $_POST['id'];
            
            //obtain the tool/parent_id of this tool
            
            $toolid = $this->determineParentOfTask($id);
            
            
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('task_to_task')
                    ->where("master_id =$id and user_id=$userid");
                $result = $cmd->queryScalar();
            
           if(isset($_POST['slave'])){
               
               //confirm if there are already some slaves task on this master
               if($result > 0){
                         $cmd->delete('task_to_task', 'master_id=:id and user_id=:userid', array(':id'=>$id, ':userid'=>$userid ));
                    
                 }
               
                     if(is_array($_POST['slave'])) {
                            foreach($_POST['slave'] as $slave){ 
                                //obtain the tool id and toolbox id of the slave task
                                $slave_tool_id = $this->determineParentOfTask($slave);
                                $slave_toolbox_id = $this->determineToolboxIdGivenToolAndUserId($slave_tool_id,$userid);
                                  $slave_assignment= $cmd->insert('task_to_task',
                                        array(
                                           'master_id'=>$id,
                                           'slave_id'=>$slave,
                                            'user_id'=>$userid,
                                            'master_tool_id'=>$toolid,
                                            'slave_tool_id'=>$slave_tool_id,
                                            'slave_toolbox_id'=>$slave_toolbox_id,
                                            'create_time'=> new CDbExpression('NOW()'),
                                            'create_user_id'=>$userid
                                              
                                        ));
                                      
                               
                             }
                             
                       }else{
                           
                           $slave = $_POST['slave'];
                          $slave_tool_id = $this->determineParentOfTask($slave);
                          $slave_toolbox_id = $this->determineToolboxIdGivenToolAndUserId($slave_tool_id,$userid);
                           $slave_assignment= $cmd->insert('task_to_task',
                                   array(
                                         'master_id'=>$id,
                                           'slave_id'=>$slave,
                                            'user_id'=>$userid,
                                            'master_tool_id'=>$toolid,
                                            'slave_tool_id'=>$slave_tool_id,
                                            'slave_toolbox_id'=>$slave_toolbox_id,
                                            'create_time'=> new CDbExpression('NOW()'),
                                            'create_user_id'=>$userid
                                              
                                    ));
                           
                       }
                       if($slave_assignment>0){
                            $msg = 'Slave Document Successfully chained to the Master'; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                 //"selected" => $selected,
                                "msg" => $msg
                                //"category" =>$category,
                           
                           
                          
                       ));
                           
                       }else{
                           
                            $msg = 'Document Chaining was not successful'; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                //"selected" => $selected,
                                "msg" => $msg
                                //"category" =>$category,
                           
                           
                          
                       ));
                       }
                      
                           
                       
               
           } //end of the isset function
            
        }
        
        /**
         * this is the function that determines the parent id /tool id of a given task
         */
        public function determineParentOfTask($taskid){
            
            $criteria3 = new CDbCriteria();
            $criteria3->select = 'id, parent_id';
            $criteria3->condition='id=:id';
            $criteria3->params = array(':id'=>$taskid);
            $parentid= Resources::model()->find($criteria3);
            
            
            return $parentid['parent_id'];
        }
        
        
        /**
         * This is the function that determines a toolbox id  given a tool id and a user id
         */
        public function determineToolboxIdGivenToolAndUserId($slave_tool_id,$userid){
            //determine all the toolboxes assigned to this user
           // $slave_toolbox =0;
            $toolboxes = $this->determineAllToolboxesAssignedToThisUser($userid);
            
            //determine the toolbox where the slave_tool is from
            foreach($toolboxes as $toolbox){
                
                if($this->isToolInThisToolbox($slave_tool_id, $toolbox)){
                    $slave_toolbox = $toolbox;
                    
                    return $slave_toolbox;
                }
               
            }
         /**   
            if($slave_toolbox===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                             "toolbox" =>$slave_toolbox,
                             "toolbox2" =>$toolboxes
                              
                       ));
                       
                } 
          * 
          */
            
            
            
        }
        
        
        /**
         * This is the function that determines if a tool is in a toolbox
         */
        public function isToolInThisToolbox($slave_tool, $toolbox){
            
            //spool all tools in this toolbox
            $criteria3 = new CDbCriteria();
            $criteria3->select = 'resource_id, resourcegroup_id';
            $criteria3->condition='resourcegroup_id=:id';
            $criteria3->params = array(':id'=>$toolbox);
            $tools= ResourceHasResourcegroups::model()->findAll($criteria3);
            
            $alltools = [];
            foreach($tools as $tool){
                $alltools[] = $tool['resource_id'];
            }
            
            if(in_array($slave_tool, $alltools)){
                return true;
                
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that adds a task to favourite
         */
        public function actionAddTaskToFavourites(){
            
            //the logged in user is
            $userid = Yii::app()->user->id;
            
            $taskid = $_POST['taskid'];
            $toolboxid = $_POST['toolboxid'];
            if(isset($_POST['description'])){
                $description = $_POST['description'];
               
            }
            
            
            
            //confirming if this task is already in favourites for this user
            
            if(!$this->isThisTaskAlreadyInFavouritesForThisUser($taskid,$userid)){
                $cmd =Yii::app()->db->createCommand();
                $result= $cmd->insert('user_has_favourites',
                                        array(
                                           'resource_id'=>$taskid,
                                           'resourcegroup_id'=>$toolboxid,
                                            'user_'
                                            . 'id'=>$userid,
                                            'description'=>$description
                                            
                                              
            ));
           
           if($result>0){
                            $msg = 'Document  Successfully added to favourites'; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                 //"selected" => $selected,
                                "msg" => $msg
                                //"category" =>$category,
                   
                              ));
                           
                       }else{
                           
                            $msg = 'Document was not added to favourite'; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                //"selected" => $selected,
                                "msg" => $msg
                                //"category" =>$category,
                           
                           
                          
                       ));
                       }
                
            }else{
               //update the toolbox info in the user's favourite container
                if($this->updateTheTaskInfoInTheFavouriteContainer($userid,$taskid,$toolboxid,$description)){
                    $msg = 'Document info successfully updated in the favourites container'; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                 //"selected" => $selected,
                                "msg" => $msg
                                //"category" =>$category,
                   
                              ));
                }else{
                    
                     $msg = 'Document info not updated in the favourites container'; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                //"selected" => $selected,
                                "msg" => $msg
                                //"category" =>$category,
                             ));       
                }
                
               
                
            }//end of the if statement
            
   
        }
        
        
        /**
         * This is the function that updates the information in the favourite's container
         */
        public function updateTheTaskInfoInTheFavouriteContainer($user_id,$task_id,$toolbox_id,$description){
            
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user_has_favourites',
                                  array(
                                   'resourcegroup_id'=>$toolbox_id,
                                   'description'=>$description   
                                   
                           ),
                        ("user_id=$user_id and resource_id=$task_id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        /**
         * This is the function that will determine if a user already has task in favourites
         */
        public function isThisTaskAlreadyInFavouritesForThisUser($taskid,$userid){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_favourites')
                    ->where("resource_id =$taskid and user_id=$userid");
                $result = $cmd->queryScalar();
            
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
            /**
         * This is the function that determines the type and size of icon file
         */
        public function isIconTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['picture']['name'])){
                $tmpName = $_FILES['picture']['tmp_name'];
                $iconFileName = $_FILES['picture']['name'];    
                $iconFileType = $_FILES['picture']['type'];
                $iconFileSize = $_FILES['picture']['size'];
            } 
           if (isset($_FILES['picture'])) {
             $filename = $_FILES['picture']['tmp_name'];
             list($width, $height) = getimagesize($filename);
           }
      

           
            $platform_width = $this->getThePlatformSetIconWidth();
            $platform_height = $this->getThePlatformSeticonHeight();
            
            $width = $width;
            $height = $height;
           
            //$size = $width * $height;
           
            $icontypes = $this->retrieveAllTheIconMimeTypes();
            
          
           
            //if(($iconFileType === 'image/png'|| $iconFileType === 'image/jpg' || $iconFileType === 'image/jpeg') && ($iconFileSize = 256 * 256)){
            if((in_array($iconFileType,$icontypes)) && ($platform_width == $width && $platform_height = $height)){
                return true;
               
            }else{
                return false;
            }
            
        }



/**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousIconName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = User::model()->find($criteria);
            
            
            return $icon['picture'];
            
            
        }
        
        /**
         * This is the function that retrieves the previous icon size
         */
        public function retrieveThePrreviousIconSize($id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = User::model()->find($criteria);
            
            
            return $icon['picture_size'];
        }
		
		
		
		 /**
         * This is the function that gets the platform height setting
         */
        public function getThePlatformSeticonHeight(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_height'];
        }
		
		
		
		 /**
         * This is the function that gets the platform icon set width
         */
        public function getThePlatformSetIconWidth(){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_width'];
        }
		
		
		
		/**
         * This is the function that retrieves all icon mime types in the platform
         */
        public function retrieveAllTheIconMimeTypes(){
            
            $icon_mimetype = [];
            $icon_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon_mime = PlatformSettings::model()->find($criteria); 
            
            $icon_mimetype = explode(',',$icon_mime['icon_mime_type']);
            foreach($icon_mimetype as $icon){
                $icon_types[] =$icon; 
                
            }
            
            return $icon_types;
            
        }
		
		
		
		/**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename){
            
            if(isset($_FILES['picture']['name'])){
                        $tmpName = $_FILES['picture']['tmp_name'];
                        $iconName = $_FILES['picture']['name'];    
                        $iconType = $_FILES['picture']['type'];
                        $iconSize = $_FILES['picture']['size'];
                  
                   }
                    
                    if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename; 
                          if($icon_filename != 'user_unavailable.png'){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['users'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != 'user_unavailable.png'){
                                
                                if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['users'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\icons\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['picture'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                if($icon['picture'] == 'user_unavailable.png' || $icon['picture'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                if($icon['picture']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function to confirm if a user is logged in
         */
        public function actionconfirmIfUserIsLoggedIn(){
            $userid = Yii::app()->user->id;
            
           //retreive the firstname of the logged user
            $firstname = $this->getTheFirstNameOfTheLoggedInUser($userid);
            
            
            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                //"selected" => $selected,
                                "userid" => $userid,
                                "firstname"=>$firstname,
                                "length" =>strlen($firstname),
                             ));  
            
        }
        
        
        /**
         * This is the function that gets the firstname of the logged in user
         */
        public function getTheFirstNameOfTheLoggedInUser($userid){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$userid);
                $user= User::model()->find($criteria);
                
                return $user['firstname'];
        }
        
        
        /**
         * This is the functijon that gets a user's name
         */
        public function actiongetThisUsername(){
            
            $id = $_POST['user_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $user= User::model()->find($criteria);
            
            $name = $user['firstname'] . ' ' . $user['lastname'];
            
            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                               "name"=>$name
            ));  
            
   
        }
        
        /**
         * This is the functijon that gets a user's name and storage name
         */
        public function actiongetTheUsernameAndStorageRoom(){
            
            $id = $_POST['user_id'];
            $room_id = $_POST['room_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $user= User::model()->find($criteria);
            
            $name = $user['firstname'] . ' ' . $user['lastname'];
            
            //get the storage room name 
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$id);
            $room= StorageRoom::model()->find($criteria1);
            
            
            
            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                               "name"=>$name,
                                "room_name"=>$room['name']
                                    
            ));  
            
            
            
            
        }
        
        
        
	/**
         * This is the function that list a members awaiting collecgues request
         */
      
        public function actionListAllAwaitingColleaguesRequest(){
            
            $model = new User;
            $userid = Yii::app()->user->id;
            
            $user_domain_id = $this->determineAUserDomainIdGiven($userid);
            $country_id = $_REQUEST['country'];
            $domain_type = strtolower($_REQUEST['domain_type']);
            $search_string = $_REQUEST['search_string'];
            $domain = $_REQUEST['domain'];
            $start = $_REQUEST['start'];
            $limit = $_REQUEST['limit'];
            
             //get all the awaiting colleagues request
            $awaiting_colleagues = $model->getAllTheColleaguesAwaitingRequestOfThisMember($userid);
            
            if($search_string ==""){//search string was not provided
                //if the industry was not given
                if($domain == "" or $domain==0){//this is for all domains
                   if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type
                                            
                       $all_awaiting_colleagues_request = [];
                       $count = 0;
                                                 
                            foreach($awaiting_colleagues as $colleague){
                                if($model->isColleagueInTheRequiredDomainType($colleague,$domain_type)){
                                    $criteria = new CDbCriteria();
                                    $criteria->select = '*';
                                    $criteria->condition='id=:id';   
                                    $criteria->params = array(':id'=>$colleague);
                                    $criteria->order = "name";
                                    //$criteria->offset = $start;
                                    //$criteria->limit = $limit;     
                                    $member = User::model()->find($criteria);
                                
                                    $all_awaiting_colleagues_request[] = $member;
                                    
                                   $count = $count + 1;
                                }
                                
                            }
                      
                       
                       if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                      
                        
                        
                    }else{//country was provided
                       $all_awaiting_colleagues_request = [];
                       $count = 0;
                                             
                            foreach($awaiting_colleagues as $colleague){
                                
                              if($model->isDomainOfTheColleagueRequiredDomainTypeAndCountry($colleague,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='id=:id';   
                                  $criteria->params = array(':id'=>$colleague);
                                  $criteria->order = "name";
                                 // $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $member = User::model()->find($criteria);
                                
                                  $all_awaiting_colleagues_request[] = $member;
                                  $count = $count + 1;
                              }
                                
                            }
                       
                       
                       if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }
                    
                    
                    
                    
                }else{//a single domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){ //country was not provided
                       $all_awaiting_colleagues_request = [];
                       $count = 0;
                          
                        if($this->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domain';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                          if(in_array($member['id'],$awaiting_colleagues)){
                                                   $all_awaiting_colleagues_request[]= $member;
                                                   $count = $count + 1;
                                               }
                                       }
                                       
                           
                                }
                        
                                
                            
                       
                       
                       if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                    }else{
                        $all_awaiting_colleagues_request = [];
                        $count = 0;
                                             
                             if($this->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domain';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                           if(in_array($member['id'],$awaiting_colleagues)){
                                                   $all_awaiting_colleagues_request[]= $member;
                                                   $count = $count + 1;
                                               }
                                       }
                                       
                           
                                }                       
                    
                       
                       if($members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                    
                            ));
                       
                         }
						
                    }
                    
                    
                    
                    
                }
                
                
                
                
                
                
                
            }else{//search string wss provided
                $search_preference = strtolower($_REQUEST['search_preference']);
                
                //if the industry was not given
                if($domain == "" or $domain == 0){
                    
                    if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type, search_preference and the search string
                         $all_awaiting_colleagues_request = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                           /** $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                  }
                                
                               
                                 
                             }
                            * 
                            */
                                                       
                         
                        }
                        
                        $count = 0;
                     
                         foreach($awaiting_colleagues as $colleague){
                             if($model->isColleagueInTheRequiredDomainType($colleague,$domain_type)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='id=:id';   
                                        $criteria->params = array(':id'=>$colleague);
                                        $criteria->order = "name";
                                        //$criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $member = User::model()->find($criteria);
                                
                                       if(in_array($member['id'],$all_user_string_ids)){
                                               $all_awaiting_colleagues_request[] = $member;
                                               $count = $count + 1;
                                                       
                                           }
                           
                                }
                                
                             
                         }
             
                       if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                        
                        
                    }else{//country was provided
                        //retrieve the domains based on the country, search_preference, domain type and the search string
                         $all_partner_members = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                           /** $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                    
                                }
                                
                               
                                 
                             }
                            * 
                            */
                                                       
                         
                        }
                        
                             $count = 0;
                             foreach($awaiting_colleagues as $colleague){
                                 
                                  if($model->isDomainOfTheColleagueRequiredDomainTypeAndCountry($colleague,$domain_type,$country_id)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='id=:id';   
                                        $criteria->params = array(':id'=>$colleague);
                                        $criteria->order = "name";
                                        //$criteria->offset = $start;
                                       // $criteria->limit = $limit;  
                                        $member = User::model()->find($criteria);
                                
                                       if(in_array($member['id'],$all_user_string_ids)){
                                               $all_awaiting_colleagues_request[] = $member;
                                               $count = $count + 1;
                                           }
                                     
                                 }
                                 
                             }
                              
                           if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                                }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                    
                            ));
                       
                         }
                                 
                                  
                   }
     
         
                }else{//domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){//country was not provided
                       //retrieve the domain based on the industry(category), search_preference, domain type and the search strings
                        $all_awaiting_colleagues_request = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                           /** $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                    
                                }
                                
                               
                                 
                             }
                            * 
                            */
                                                       
                         
                        }
                        
                        $count = 0;
                     
                           
                                
                                 if($this->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domain';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                           if(in_array($member['id'],$all_user_string_ids)){
                                               if(in_array($member['id'],$awaiting_colleagues)){
                                                   $all_awaiting_colleagues_request[]= $member;
                                                   $count = $count + 1;
                                               }
                                               
                                           }
                                       }
                                       
                           
                                }
                                
                            
                       
                       
                       if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }else{
                        //retrieve the domain based on the industry(category), search_preference, country, domain type and the search strings
                         $all_awaiting_colleagues_request = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                          /**  $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                    
                                }
                                
                               
                                 
                             }
                           * 
                           */
                                                       
                         
                        }
                        
                        $count = 0;
                     
                           
                                
                                 if($this->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domin';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                           if(in_array($member['id'],$all_user_string_ids)){
                                               if(in_array($member['id'],$awaiting_colleagues)){
                                                   $all_awaiting_colleagues_request[]= $member;
                                                   $count = $count + 1;
                                               }
                                               
                                           }
                                       }
                                       
                           
                                }
                                
                            
                       
                       
                       if($awaiting_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_awaiting_colleagues_request,
                                    "results"=>$count
                    
                            ));
                       
                         }
                    }
                    
                    
                    
                }
                
                
                
            }
            
            
            
        }
        
        
        /**
         * This is the function that determine if a domain, domain type is the required one
         */
        public function isDomainOfTheRequiredDomainType($domain,$domain_type){
            $model = new ResourceGroupCategory;
            return $model->isDomainOfTheRequiredDomainType($domain,$domain_type);
        }
        
        
        /**
         * This is the function that determine if a domain, domain type is the required one
         */
        public function isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id){
            $model = new ResourceGroupCategory;
            return $model->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id);
        }
        
        
        
        /**
         * This is the function that list all member colleagues
         */
        public function actionListAllMemberColleagues(){
            
            $model = new User;
            $userid = Yii::app()->user->id;
            
            $user_domain_id = $this->determineAUserDomainIdGiven($userid);
            $country_id = $_REQUEST['country'];
            $domain_type = strtolower($_REQUEST['domain_type']);
            $search_string = $_REQUEST['search_string'];
            $domain = $_REQUEST['domain'];
            $start = $_REQUEST['start'];
            $limit = $_REQUEST['limit'];
            
             //get all the colleagues of this member
            $member_colleagues = $model->getAllTheColleaguesOfThisMember($userid);
            
            if($search_string ==""){//search string was not provided
                //if the industry was not given
                if($domain == "" or $domain==0){//this is for all domains
                   if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type
                                            
                       $all_member_colleagues = [];
                       $count = 0;
                                                 
                            foreach($member_colleagues as $colleague){
                                if($model->isColleagueInTheRequiredDomainType($colleague,$domain_type)){
                                    $criteria = new CDbCriteria();
                                    $criteria->select = '*';
                                    $criteria->condition='id=:id';   
                                    $criteria->params = array(':id'=>$colleague);
                                    $criteria->order = "name";
                                    //$criteria->offset = $start;
                                    //$criteria->limit = $limit;     
                                    $member = User::model()->find($criteria);
                                
                                    $all_member_colleagues[] = $member;
                                    
                                   $count = $count + 1;
                                }
                                
                            }
                      
                       
                       if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                      
                        
                        
                    }else{//country was provided
                       $all_member_colleagues = [];
                       $count = 0;
                                             
                            foreach($member_colleagues as $colleague){
                                
                              if($model->isDomainOfTheColleagueRequiredDomainTypeAndCountry($colleague,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='id=:id';   
                                  $criteria->params = array(':id'=>$colleague);
                                  $criteria->order = "name";
                                 // $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $member = User::model()->find($criteria);
                                
                                  $all_member_colleagues[] = $member;
                                  $count = $count + 1;
                              }
                                
                            }
                       
                       
                       if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }
                    
                    
                    
                    
                }else{//a single domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){ //country was not provided
                       $all_member_colleagues = [];
                       $count = 0;
                          
                        if($this->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domain';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                          if(in_array($member['id'],$member_colleagues)){
                                                   $all_member_colleagues[]= $member;
                                                   $count = $count + 1;
                                               }
                                       }
                                       
                           
                                }
                        
                                
                            
                       
                       
                       if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                    }else{
                        $all_member_colleagues = [];
                        $count = 0;
                                             
                             if($this->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domain';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                           if(in_array($member['id'],$member_colleagues)){
                                                   $all_member_colleagues[]= $member;
                                                   $count = $count + 1;
                                               }
                                       }
                                       
                           
                                }                       
                    
                       
                       if($members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                    
                            ));
                       
                         }
						
                    }
                    
                    
                    
                    
                }
                
                
                
                
                
                
                
            }else{//search string wss provided
                $search_preference = strtolower($_REQUEST['search_preference']);
                
                //if the industry was not given
                if($domain == "" or $domain == 0){
                    
                    if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type, search_preference and the search string
                         $all_member_colleagues = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                           /** $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                  }
                                
                               
                                 
                             }
                            * 
                            */
                                                       
                         
                        }
                        
                        $count = 0;
                     
                         foreach($member_colleagues as $colleague){
                             if($model->isColleagueInTheRequiredDomainType($colleague,$domain_type)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='id=:id';   
                                        $criteria->params = array(':id'=>$colleague);
                                        $criteria->order = "name";
                                        //$criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $member = User::model()->find($criteria);
                                
                                       if(in_array($member['id'],$all_user_string_ids)){
                                               $all_member_colleagues[] = $member;
                                               $count = $count + 1;
                                                       
                                           }
                           
                                }
                                
                             
                         }
             
                       if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                        
                        
                    }else{//country was provided
                        //retrieve the domains based on the country, search_preference, domain type and the search string
                         $all_member_colleagues = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                           /** $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                    
                                }
                                
                               
                                 
                             }
                            * 
                            */
                                                       
                         
                        }
                        
                             $count = 0;
                             foreach($awaiting_colleagues as $colleague){
                                 
                                  if($model->isDomainOfTheColleagueRequiredDomainTypeAndCountry($colleague,$domain_type,$country_id)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='id=:id';   
                                        $criteria->params = array(':id'=>$colleague);
                                        $criteria->order = "name";
                                        //$criteria->offset = $start;
                                       // $criteria->limit = $limit;  
                                        $member = User::model()->find($criteria);
                                
                                       if(in_array($member['id'],$all_user_string_ids)){
                                               $all_member_colleagues[] = $member;
                                               $count = $count + 1;
                                           }
                                     
                                 }
                                 
                             }
                              
                           if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                                }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                    
                            ));
                       
                         }
                                 
                                  
                   }
     
         
                }else{//domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){//country was not provided
                       //retrieve the domain based on the industry(category), search_preference, domain type and the search strings
                        $all_member_colleagues = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                           /** $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                    
                                }
                                
                               
                                 
                             }
                            * 
                            */
                                                       
                         
                        }
                        
                        $count = 0;
                     
                           
                                
                                 if($this->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domain';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                           if(in_array($member['id'],$all_user_string_ids)){
                                               if(in_array($member['id'],$member_colleagues)){
                                                   $all_member_colleagues[]= $member;
                                                   $count = $count + 1;
                                               }
                                               
                                           }
                                       }
                                       
                           
                                }
                                
                            
                       
                       
                       if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }else{
                        //retrieve the domain based on the industry(category), search_preference, country, domain type and the search strings
                         $all_member_colleagues = [];
                          if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_user_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM user where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_user_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                          /**  $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT domain_id FROM user where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['domain_id']; 
                                    
                                }
                                
                               
                                 
                             }
                           * 
                           */
                                                       
                         
                        }
                        
                        $count = 0;
                     
                           
                                
                                 if($this->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                        $criteria = new CDbCriteria();
                                        $criteria->select = '*';
                                        $criteria->condition='domain_id=:domin';   
                                        $criteria->params = array(':domain'=>$domain);
                                        $criteria->order = "name";
                                        $criteria->offset = $start;
                                        //$criteria->limit = $limit;  
                                        $members = User::model()->findAll($criteria);
                                
                                       foreach($members as $member){
                                           if(in_array($member['id'],$all_user_string_ids)){
                                               if(in_array($member['id'],$member_colleagues)){
                                                   $all_member_colleagues[]= $member;
                                                   $count = $count + 1;
                                               }
                                               
                                           }
                                       }
                                       
                           
                                }
                                
                            
                       
                       
                       if($member_colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_member_colleagues,
                                    "results"=>$count
                    
                            ));
                       
                         }
                    }
                    
                    
                    
                }
                
                
                
            }
            
            
        }
        
        
        /**
         * This is the function that list all staff members of a domain
         */
        public function actionListAllStaffMembersOfADomain(){
            
            $domain = $_REQUEST['domain'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:domainid and type =:type';   
            $criteria->params = array(':domainid'=>$domain,':type'=>"staff");
            $criteria->order = "name";
            $members = User::model()->findAll($criteria);
            
             if($members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $members,
                                   
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that list all customer members of a domain
         */
        public function actionListAllCustomerMembersOfADomain(){
            
            $model = new DomainHasOtherUsers;
            
            $domain = $_REQUEST['domain'];
            
            //get the customers of this domain
            $domain_customers = $model->getAllCustomersOfThisDomain($domain);
            
            $all_customers = [];
            
            foreach($domain_customers as $customer){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$customer);
                $criteria->order = "name";
                $member = User::model()->find($criteria);
                $all_customers[] = $member;
            }
            
            
            
             if($domain_customers===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_customers,
                                   
                                   
                    
                            ));
                       
                         }
            
        }
        
        
          /**
         * This is the function that list all vendor members of a domain
         */
        public function actionListAllVendorMembersOfADomain(){
            
            $model = new DomainHasOtherUsers;
            
            $domain = $_REQUEST['domain'];
            
            //get the customers of this domain
            $domain_vendors = $model->getAllVendorsOfThisDomain($domain);
            
            $all_vendors = [];
            
            foreach($domain_vendors as $vendor){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$vendor);
                $criteria->order = "name";
                $member = User::model()->find($criteria);
                $all_vendors[] = $member;
            }
            
            
            
             if($domain_vendors===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "member" => $all_vendors,
                                  
                                   
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that lisr all other domain users
         */
        public function actionlistallOtherDomainUsers(){
            
              
            $model = new DomainHasOtherUsers;
            $userid = Yii::app()->user->id;
              
              $domain = $this->determineAUserDomainIdGiven($userid);
            

            //get the non staff users members  of this domain
            $domain_nonstaff_members = $model->getAllNonStaffMembersOfThisDomain($domain);
            
            $other_members = [];
            
            foreach($domain_nonstaff_members as $mem){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$mem);
                $criteria->order = "name";
                $member = User::model()->find($criteria);
                $other_members[] = $member;
            }
            
            
            
             if($domain_nonstaff_members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "users" => $other_members,
                                  
                                   
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
	 * List the city and usertype base on the city id and the usertype id
	 */
	public function actionObtainUserExtraInformation()
	{
            
            $model = new DomainHasOtherUsers;
            $user_id = Yii::app()->user->id;
            
            //get the user domain
            $user_domain = $this->determineAUserDomainIdGiven($user_id);
             $city_id = $_REQUEST['city_id'];
             $domain_id = $_REQUEST['domain_id'];
            // $usertype_id = $_REQUEST['usertype_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, state_id';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$city_id);
             $city = City::model()->find($criteria);   
             $city_name = $city['name'];
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:domainid';
             $criteria2->params = array(':domainid'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria2);
              $domain_name = $domain['name'];
              
              //get the member user type for this domain
              $type = $model->getTheUserTypeOfThisMember($user_domain,$_REQUEST['member_id']);
              
        
              //get the user status on this domain
               $status = $model->getTheUserStatusOfThisMemberOnThisDomain($user_domain,$_REQUEST['member_id']);
               
                if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "city" => $city_name,
                           "domain"=>$domain_name,
                           "type" => $type,
                            "status" => $status
                               )
                       );
                       
                } 
               
               
	}
        
        
        /**
         * This is the function that adds new customer to the domain
         */
        public function actionaddanewnonstaffcustomerforadomain(){
            
            $model=new User;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                //get the logged i user
                $user_id = Yii::app()->user->id;
                
                //get the domain id of the logged in user
                $domain_id = $this->determineAUserDomainIdGiven($user_id);
		
                
                $model->usertype_id = 1;
                $model->email = $_POST['email'];
                $model->username = $_POST['email'];
                $model->city_id = $_POST['city'];
                $model->lastname = $_POST['lastname'];
                $model->middlename = $_POST['middlename'];
                $model->firstname = $_POST['firstname'];
                $model->gender = $_POST['gender'];
                if($model->middlename == ""){
                    $model->name = $model->lastname . ' '. $model->firstname; 
                    
                }else{
                   $model->name = $model->lastname . ' '. $model->middlename . ' ' . $model->firstname; 
                    
                }
                $type = $_REQUEST['type'];
                //$model->maritalstatus = $_POST['maritalstatus'];
                //$model->dateofbirth = $_POST['dateofbirth'];
                $model->role = "user";
                $model->status = $_POST['status'];
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                $model->domain_id = $domain_id;
                $password = $_POST['password'];
                $password_repeat = $_POST['passwordCompare'];
                
                $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
                
                if($model->doesThisUserAlreadyHaveAProfileOnThePlatform($_POST['email']) == false){
                    
                    if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                                    //$model->password = $model->hashPassword($newpassword);
                          /**  if($model->validate()){
                                 if(($_FILES['picture']['name'] == null)){
                    
                                        $this->saveUserInfoWithoutPicture($model);               
                                }
                
                             if(($_FILES['picture']['name'] != null)){
                                    $picture = $_FILES['picture']['name'];
                    
                                    $this-> saveUserInfoWithPictureInclusive($model, $picture);
                    
                                }
                 
                            }else{
                            $msg = 'There is parameter validation error';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                     "msg" => $msg,
                             ));  
                 
                         }
                                
                           * 
                           */
                  $icon_error_counter = 0;     
                  $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
                 if($_FILES['picture']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                       
                       $icon_filename = $_FILES['picture']['name'];
                      $icon_size = $_FILES['picture']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideUserIconWhenUnavailable($model);
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->picture = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->picture_size = $icon_size;
                           
                if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              
                              //assign user as either a customer or a vendor to this domain
                              if($this->isTheAdditionOfThisUserAsANonStaffUserToThisDomainASuccess($model->id,$domain_id,$type,$_REQUEST['status'])){
                                   // $result['success'] = 'true';
                                $msg = "The addition of '$name' as a '$type' to this domain was successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                  
                              }else{
                                   $msg = "The addition of '$name' as a '$type' to this domain was not successful";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                  
                              }
                             
                                 } else {
                                     $msg = "The addition of '$name' as a '$type' to this domain was successful";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "The addition of '$name' as a '$type' to this domain was successful";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$name'  was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your picture file type or size as picture must be of width '$platform_width'px and height '$platform_height'px. Picture is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
                //effect the change 
              /**
              $cmd =Yii::app()->db->createCommand();  
              $cmd->update('user',
                	array('password'=>$password,
	         	),
			"id = $userid"
		);
               * 
               */
             
              
                
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                    
                    
                    
                    
                }else{
                    if($model->isThisUserAlreadyCreatedAsOneOfYourDomainStaff($_POST['email'],$domain_id)){
                        
                        if($this->isTheAdditionOfThisStaffAsACustomerOrVendorMemberASuccss($model->id,$domain_id,$type,$_REQUEST['status'])){
                            $msg = "'$name', though existing as one of your domain staff, had also been added as one of your domain $type";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                            )); 
                            
                        }else{
                             $msg = "'$name' could not be added as a $type to your domain. Please try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                            )); 
                            
                        }
                       
                
                        
                    }else if($model->isThisUserAlreadyAStaffOfAnotherDomain($_POST['email'],$domain_id)){
                        
                       if($this->isTheAdditionOfThisUserAsADomainNonStaffMemberASuccss($model->id,$domain_id,$type,$_REQUEST['status'])){
                            $msg = "'$name' though existing as one of the staff of another domain, had also been added as one of your domain $type";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                            )); 
                            
                        }else{
                             $msg = "'$name' could not be added as a $type to your domain. Please try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                            )); 
                            
                        }
                    }else if($model->isThisUserAStaffOfThePlatform($_POST['email'])){
                        //updating the user detail chaging on the domain id
                        if($this->isTheAdditionOfThisUserAsADomainNonStaffMemberASuccss($model->id,$domain_id,$type,$_REQUEST['status'])){
                            $msg = "'$name' had successfully been added as one of your domain $type";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                            )); 
                            
                        }else{
                             $msg = "'$name' could not be added as a $type to your domain. Please try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                            )); 
                            
                        }
                    }else{
                        $msg = "The addition of '$name' as one of your domain staff was not suucessful. Please contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                        
                    }
                   
                
                
                
                } 
            
            
            
        }
        
        
        
        /**
         * This is the function that confirms that addition of a member as customer or vendor to a domain
         */
        public function isTheAdditionOfThisUserAsANonStaffUserToThisDomainASuccess($member_id,$domain_id,$type,$status){
            $model = new DomainHasOtherUsers;
            return $model->isTheAdditionOfThisUserAsANonStaffUserToThisDomainASuccess($member_id,$domain_id,$type,$status);
       }
       
       
       /**
        * This is the function that confirms the success of the addition of a domain staff as a customer or vendor
        */
       public function isTheAdditionOfThisStaffAsACustomerOrVendorMemberASuccss($member_id,$domain_id,$type,$status){
           $model = new DomainHasOtherUsers;
           return $model->isTheAdditionOfThisStaffAsACuatomerOrVendorMemberASuccss($member_id,$domain_id,$type,$status);
           
       }
       
       
       /**
        * This is the function if the addition of another domain staff as a domain customer or vendor a success
        */
       public function isTheAdditionOfThisUserAsADomainNonStaffMemberASuccss($member_id,$domain_id,$type,$status){
           $model = new DomainHasOtherUsers;
           return $model->isTheAdditionOfThisUserAsADomainNonStaffMemberASuccss($member_id,$domain_id,$type,$status);
       }
       
   
         /**
         * This is the function that updates a domain customer/vendor information
         */
        public function actionupdatingnonstaffcustomerforadomain(){
            
            $model = new DomainHasOtherUsers;
            
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $member_id = $_REQUEST['id'];
            
            $type = $_REQURST['type'];
            
            $status = $_REQUEST['status'];
                    
                    
            
            if($model->isTheModificationOfThisNonStaffUserInfoASucces($domain_id,$member_id,$type,$status)){
                 $msg = "You have successfully updated the $type's information for your domain";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                            )); 
                
            }else{
                 $msg = "The attempt to update the $type's information for your domain was not successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                            )); 
                
            }
            
            
            
            
            
            
        }
        
        
        /**
         * This is the function that list all domain emails
         */
        public function actionlistDomainAllUserEmails(){
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $email = $_REQUEST['email'];
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name,email';
            $criteria->condition='email=:email and domain_id=:domainid';
            $criteria->params = array(':email'=>$email,':domainid'=>$domain_id);
            $user = User::model()->find($criteria);   
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that list all domain bvn
         */
        public function actionlistDomainAllUserBvns(){
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $bvn = $_REQUEST['bvn'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='bvn=:bvn and domain_id=:domainid';
            $criteria->params = array(':bvn'=>$bvn,':domainid'=>$domain_id);
            $user = User::model()->find($criteria);   
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that list all domain national identity number
         */
        public function actionlistDomainAllUserNins(){
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $nin = $_REQUEST['nin'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='nin=:nin and domain_id=:domainid';
            $criteria->params = array(':nin'=>$nin,':domainid'=>$domain_id);
            $user = User::model()->find($criteria);   
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that list all domain international passport number
         */
        public function actionlistDomainAllUserPassports(){
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $passport = $_REQUEST['passport'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='passport_number=:passport and domain_id=:domainid';
            $criteria->params = array(':passport'=>$passport,':domainid'=>$domain_id);
            $user = User::model()->find($criteria);   
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
         
        }
        
        
        /**
         * This is the function that list all domain drivers licens number
         */
        public function actionlistDomainAllUserDrivingLicenses(){
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $driver = $_REQUEST['driver'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='driving_license_number=:driver and domain_id=:domainid';
            $criteria->params = array(':driver'=>$driver,':domainid'=>$domain_id);
            $user = User::model()->find($criteria);   
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
         
        }
        
        
        
         /**
         * This is the function that list all domain members using their pvc
         */
        public function actionlistDomainAllUserVotersCard(){
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $pvc = $_REQUEST['pvc'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='pvc=:pvc and domain_id=:domainid';
            $criteria->params = array(':pvc'=>$pvc,':domainid'=>$domain_id);
            $user = User::model()->find($criteria);   
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
         
        }
        
        
        /**
         * This is the function that retrieves the user for verification
         */
        public function actionlistTheUserForVerification(){
            
             $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $searched_by = $_REQUEST['search_by'];
            $identity = $_REQUEST['identity'];
            
            if($searched_by == 'email'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, email';
                $criteria->condition='email=:email and domain_id=:domainid';
                $criteria->params = array(':email'=>"$identity",':domainid'=>$domain_id);
                $user = User::model()->find($criteria);   
            }else if($searched_by == 'bvn'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, bvn';
                $criteria->condition='bvn=:bvn and domain_id=:domainid';
                $criteria->params = array(':bvn'=>"$identity",':domainid'=>$domain_id);
                $user = User::model()->find($criteria);   
            }else if($searched_by == 'nin'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, nin';
                $criteria->condition='nin=:nin and domain_id=:domainid';
                $criteria->params = array(':nin'=>"$identity",':domainid'=>$domain_id);
                $user = User::model()->find($criteria);   
            }else if($searched_by == 'passport'){
                 $criteria = new CDbCriteria();
                $criteria->select = 'id, name, passport_number';
                $criteria->condition='passport_number=:passport and domain_id=:domainid';
                $criteria->params = array(':passport'=>"$identity",':domainid'=>$domain_id);
                $user = User::model()->find($criteria);   
            }else if($searched_by == 'driver'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, driving_license_number';
                $criteria->condition='driving_license_number=:driver and domain_id=:domainid';
                $criteria->params = array(':driver'=>"$identity",':domainid'=>$domain_id);
                $user = User::model()->find($criteria);   
            }else if($searched_by == 'pvc'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, pvc';
                $criteria->condition='pvc=:pvc and domain_id=:domainid';
                $criteria->params = array(':pvc'=>"$identity",':domainid'=>$domain_id);
                $user = User::model()->find($criteria);   
            }
            
             if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that gets a user's extra information
         */
        public function actiongetUserExtraDetails(){
            
            $user_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user = User::model()->find($criteria);
            
            $name = $user['name'];
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "name" => $name,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that list the non staff user for verification
         */
        public function actionlistTheNonStaffUserForVerification(){
            
            $model = new DomainHasOtherUsers;
            
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $searched_by = $_REQUEST['search_by'];
            $identity = $_REQUEST['identity'];
            
            //get all the non staff members of this domain
            $non_staff_members = $model->getAllNonStaffMembersOfThisDomain($domain_id);
            
            $target_user = [];
            
            if($searched_by == 'email'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, email,type';
                $criteria->condition='email=:email';
                $criteria->params = array(':email'=>"$identity");
                $user = User::model()->find($criteria);  
                if(in_array($user['id'],$non_staff_members)){
                    $target_user[] = $user;
                }
            }else if($searched_by == 'bvn'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, bvn';
                $criteria->condition='bvn=:bvn';
                $criteria->params = array(':bvn'=>"$identity");
                $user = User::model()->find($criteria); 
                 if(in_array($user['id'],$non_staff_members)){
                    $target_user[] = $user;
                }
            }else if($searched_by == 'nin'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, nin';
                $criteria->condition='nin=:nin';
                $criteria->params = array(':nin'=>"$identity");
                $user = User::model()->find($criteria); 
                 if(in_array($user['id'],$non_staff_members)){
                    $target_user[] = $user;
                }
            }else if($searched_by == 'passport'){
                 $criteria = new CDbCriteria();
                $criteria->select = 'id, name, passport_number';
                $criteria->condition='passport_number=:passport';
                $criteria->params = array(':passport'=>"$identity");
                $user = User::model()->find($criteria); 
                 if(in_array($user['id'],$non_staff_members)){
                    $target_user[] = $user;
                }
            }else if($searched_by == 'driver'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, driving_license_number';
                $criteria->condition='driving_license_number=:driver';
                $criteria->params = array(':driver'=>"$identity");
                $user = User::model()->find($criteria);   
                 if(in_array($user['id'],$non_staff_members)){
                    $target_user[] = $user;
                }
            }else if($searched_by == 'pvc'){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name, pvc';
                $criteria->condition='pvc=:pvc';
                $criteria->params = array(':pvc'=>"$identity");
                $user = User::model()->find($criteria);   
                 if(in_array($user['id'],$non_staff_members)){
                    $target_user[] = $user;
                }
            }
            
             if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" =>$target_user,
                                    "non_staff"=>$non_staff_members
                                    
                    
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that list the colleagues of a member
         */
        public function actionListAllColleaguesForThisMember(){
            $model = new MemberHasColleagues;
            
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //get all the colleagues of this use
            $colleagues = $model->getAllTheColleaguesOfThisMember($user_id);
            
            $all_colleagues = [];
            
            foreach($colleagues as $col){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$col);
                $user = User::model()->find($criteria);
                
                $all_colleagues[] = $user;
            }
            
             if($colleagues===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "colleague" => $all_colleagues
                                   
                            ));
                       
                         }
            
            
            
        }
        
        
        /**
         * This is the function that lista the uses that a user can send email or an anniucement to
         */
        public function actionListAllUserMessagableByThisDomainMember(){
            
            $model = new DomainHasOtherUsers;
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $preference = $_REQUEST['preference'];
            
            if($preference == strtolower('staff')){
                
                //retrieve staff members here
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid and type=:type';
                $criteria->params = array(':domainid'=>$domain_id,':type'=>"staff");                    
                $users = User::model()->findAll($criteria);
                
                if($users===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $users
                                   
                            ));
                       
                         }
            
            }else if($preference == strtolower('client')){
                //get other non staff members of a domain
                
                $non_staff_members = $model->getAllNonStaffMembersOfThisDomain($domain_id);
                
                $target = [];
                
                foreach($non_staff_members as $mem){
                    
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$mem);                    
                    $user= User::model()->find($criteria);
                    
                    $target[] = $user;
                }  
                    
                     if($non_staff_members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $target
                                   
                            ));
                       
                         }
                    
                
                
                
            }else if($preference == strtolower('partner')){
                //get all partners of this domain
                $partners = $this->getAllThePartnersOfThisDomain($domain_id);
                $target = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='type=:type';
                $criteria->params = array(':type'=>"staff");                    
                $users = User::model()->findAll($criteria);
                
                foreach($users as $user){
                    if(in_array($user['domain_id'],$partners)){
                        $target[] = $user;
                    }
                }
                if($partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $target
                                   
                            ));
                       
                         }
                
            }
            
        }
        
        
        
        /**
         * This is the function that gets all the partners of a domain
         */
        public function getAllThePartnersOfThisDomain($domain_id){
            $model = new DomainHasPartners;
            return $model->getAllThePartnersOfThisDomain($domain_id);
        }
        
        
        
        /**
         * This is the function that list all admin users
         */
        public function actionlistAllAdminUsers(){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='role=:role';
                $criteria->params = array(':role'=>"domainSuperAdmin");                    
                $users = User::model()->findAll($criteria);
                
                if($users===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $users
                                   
                            ));
                       
                         }
            
            
            
        }
        
        
        
         /**
         * This is the function that list all domain users
         */
        public function actionlistDomainAllUsers(){
            
           $user_id = Yii::app()->user->id;
            
            //get the domain id of this user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='role=:role and domain_id=:domainid';
                $criteria->params = array(':role'=>"user",':domainid'=>$domain_id);                    
                $users = User::model()->findAll($criteria);
                
                if($users===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $users
                                   
                            ));
                       
                         }
            
            
            
        }
        
        
        
        
         /**
         * This is the function that retrieves a user's profile
         */
        public function actionretrievethisUserprofile(){
            
           $user_id = Yii::app()->user->id;
            
            //get the domain id of this user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$user_id);                    
                $user = User::model()->find($criteria);
                
                if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $user
                                   
                            ));
                       
                         }
            
            
            
        }
        
        
        
        /**
         * This is the function that list all platform users
         */
        public function actionlistAllPlatformUsers(){
            
           $user_id = Yii::app()->user->id;
            
                    
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $users = User::model()->findAll($criteria);
                
                if($users===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" => $users
                                   
                            ));
                       
                         }
            
            
            
        }
        
        
        /**
         * This is the function that retrieves extra about a user
         */
        public function actionretrieveextrauserinfo(){
            
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);                    
            $user = User::model()->find($criteria);
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "name" =>$user['name'],
                                    "email"=>$user['email'],
                                    "userid"=>$user['id']
                                   
                            ));
                       
                         }
            
            
        }
        
        
        
        
        
        /**
	 *This is the function that adds a new guest user
	 */
	public function actionaddnewguestuser()
	{
		$model=new User;

            
                
                //get the domain id of the logged in user
                $domain_id = $this->getTheIdOfTheGuestDomain();
		
                
               $model->email = $_POST['email'];
               $model->username = $_POST['email'];
               if(isset($_POST['city'])){
                   $model->city_id = strtolower($_POST['city']);
                }
                if(isset($_POST['location_id'])){
                   $model->location_id = strtolower($_POST['location_id']);
                }
               $model->lastname = $_POST['lastname'];
               $model->middlename = $_POST['middlename'];
               $model->firstname = $_POST['firstname'];
               $model->type =  strtolower($_POST['type']);
               $model->security_level = strtolower('level0step0');
               $model->security_level_weight = 0;
               //$model->gender = strtolower($_POST['gender']);
              if($model->middlename == ""){
                    $model->name = $model->lastname . ' '. $model->firstname; 
                    
                }else{
                   $model->name = $model->lastname . ' '. $model->middlename . ' ' . $model->firstname; 
                    
                }
             
             if(isset($_POST['bvn'])){
                 $model->bvn = $_POST['bvn'];
             }else{
                $model->bvn =null; 
             } 
             if(isset($_POST['nin'])){
                 $model->nin = $_POST['nin'];
             }else{
                 $model->nin = null;
             }
             if(isset($_POST['pvc'])){
                 $model->pvc = $_POST['pvc'];
             }else{
                 $model->pvc = null;
             } 
             if(isset($_POST['passport_number'])){
                 $model->passport_number = $_POST['passport_number'];
             }else{
                 $model->passport_number=null;
             } 
              if(isset($_POST['passport_issuance_date'])){
                 $model->passport_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['passport_issuance_date'])); 
             }else{
                 $model->passport_issuance_date= null;
             }
              if(isset($_POST['passport_expiry_date'])){
                 $model->passport_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['passport_expiry_date']));   
             }else{
                 $model->passport_expiry_date = null;
             } 
             if(isset($_POST['passport_issuance_authority'])){
                 $model->passport_issuance_authority = $_POST['passport_issuance_authority'];
             }else{
                  $model->passport_issuance_authority=null;
             }
             if(isset($_POST['driving_license_number'])){
                 $model->driving_license_number = $_POST['driving_license_number'];
             }else{
                 $model->driving_license_number = null;
             } 
             if(isset($_POST['license_issuance_date'])){
                 $model->license_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['license_issuance_date']));  
             }else{
                 $model->license_issuance_date=null;
             }
             if(isset($_POST['license_expiry_date'])){
                 $model->license_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['license_expiry_date'])); 
             }else{
                 $model->license_expiry_date = null;
             }
             if(isset($_POST['license_issuance_authority'])){
                 $model->license_issuance_authority = $_POST['license_issuance_authority'];
             }else{
                  $model->license_issuance_authority=null;
             }
             if(isset($_POST['others_identification_number'])){
                 $model->others_identification_number = $_POST['others_identification_number'];
             }else{
                 $model->others_identification_number=null;
             }
              if(isset($_POST['others_issuance_date'])){
                 $model->others_issuance_date = date("Y-m-d H:i:s", strtotime($_POST['others_issuance_date']));   
             }else{
                 $model->others_issuance_date = null;
             }
               if(isset($_POST['others_expiry_date'])){
                 $model->others_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['others_expiry_date']));  
             }else{
                  $model->others_expiry_date = null;
             }
              if(isset($_POST['others_issuance_authority'])){
                 $model->others_issuance_authority = $_POST['others_issuance_authority'];
             }else{
                 $model->others_issuance_authority = null;
             }
                         
              $model->role = "user";
              $model->mobile_number = $_POST['mobile_number'];
                $model->status = strtolower($_POST['status']);
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                $model->domain_id = $domain_id;
                $password = $_POST['password'];
                $password_repeat = $_POST['passwordCompare'];
             
                
               $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
                
             if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                    
                    if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                         
                  $icon_error_counter = 0;     
                 $name = $model->firstname . ' ' . $model->middlename . ' ' . strtoupper($model->lastname);
              if(isset($_FILES['picture']['name'])){
                  if($_FILES['picture']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                       
                       $icon_filename = $_FILES['picture']['name'];
                      $icon_size = $_FILES['picture']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                        //$icon_filename=null;
                        //$icon_size = 0;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideUserIconWhenUnavailable($model);
                    //$icon_filename=null;
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                  
              }else{
                  $icon_filename=$this->provideUserIconWhenUnavailable($model);
                   $icon_size = 0;
              }    
              
            
               
                if($icon_error_counter ==0){
                   if($model->validate()){
                        $model->picture = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                          $model->picture_size = $icon_size;
                           
                if($model->save()) {
                        
                    //$userid = Yii::app()->user->id;
                    if(isset($model->role)){
                            
                          if($this->assignRoleToAUser($model->role, $model->id)) {
                              // $result['success'] = 'true';
                                $msg = 'You have successfully been added as a guest user on the weVerified! platform. You may now login with the email address and the password you provided on registration';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                              
                                 } else {
                                     $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                                     
                                     
                                 } 
                        }else{
                            $msg = "Role is not assigned to this User";
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                            
                        }
                        
                   
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$name'  was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else if($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your picture file type or size as picture must be of width '$platform_width'px and height '$platform_height'px. Picture is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
             
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                    
                    
                    
                    
           }else{
                    if($model->isThisUserAlreadyCreatedAsOneOfYourDomainStaff($model,$domain_id)){
                        $msg = "'$name' had already been created as one of your staff. You do not have to create him again";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                
                        
                    }else if($model->isThisUserAlreadyAStaffOfAnotherDomain($model,$domain_id)){
                        
                        $msg = "'$name' is already a staff of another domain. You could only add him/her to your domain as a non staff member (customer, vendor etc)";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                    }else if($model->isThisUserAssociatedWithThePlatform($model)){
                        //updating the user detail chaging on the domain id
                        if($model->isTheTransferOfThisPlatformNonStaffMemberToThisDomainASuccess($model,$domain_id)){
                             $msg = "'$name' is successfully added to your staff list";
                             header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                             ));    
                        }else{
                            $msg = "The creation of '$name' as one of your domain staff was not suucessful. Please contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                            
                        }
                    }else{
                        $msg = "The creation of '$name' as one of your domain staff was not suucessful. Please contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                        
                    }
                   
                
                
                
                }  
           

	}
        
        
        /**
         * This is the function that gets the id of the guest domain
         */
        public function getTheIdOfTheGuestDomain(){
            $model = new ResourceGroupCategory;
            return $model->getTheIdOfTheGuestDomain();
        }
        
        
        /**
         * This is the function that resets a guest users password
         */
        public function actionresetguestuserpassword(){
            
            $model = new User;
            
            $email = $_REQUEST['email'];
            
            if($model->isThisUserEmailAlreadyUsedOnThePlatform($email)){
                if($model->isThisUserAGuestUser($email)){
                    if($model->isPasswordResetRequestSuccessful($email)){
                         $msg = "Your request to reset your password had been received. The new password will be sent to your registeted email address shortly. Please don't resend the request";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "msg" => $msg,
                       )); 
                    }else{
                        $msg = "The attempt to reset your password was not successful. Please try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                    }
                    
                }else{
                    $msg = "You are not a guest user. Please ask your domain administrator to reset your password instead";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
                    
                }
                
                
                
            }else{
                 $msg = "The email you entered is not registered on this platform. Please check the email address and try again";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg,
                       )); 
            }
        }
        
        
        /**
         * This is the function that retrieves a user's info
         */
        public function actionretrievethisuserinfo(){
            
            $user_id = $_REQUEST['user_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);                    
            $user = User::model()->find($criteria);
            
             if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" =>$user,
                                   
                                   
                            ));
                       
                         }
            
        }
        
        
        /**
         * this is the function that gets the role of a use
         */
        public function actiongetThisUserRole(){
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);                    
            $user = User::model()->find($criteria);
            
             if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "user" =>$user,
                                   
                                   
                            ));
                       
                         }
            
        }
        
}
