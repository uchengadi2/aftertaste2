<?php

class UserEnlistmentRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listallfeedbackitemsinadomainlocation','listallfeedbackitemsinadomainlocation'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisUserEnlistmentRequests','requestingforitemenlistment','retrieveenlistmentinfo','updatemesageenlistment',
                                    'generatemesageenlistmentcode','listThisUserProductEnlistmentRequests','requestingforproductenlistment','updatingthisproductenlistment',
                                    'generateproductenlistmentcode','listThisUserFeedbackProductEnlistmentRequests','listThisUserEngagementProductEnlistmentRequests',
                                    'requestingforproductfeedbackenlistment','updatingthisproductfeedbackenlistment','generateproductfeedbackenlistmentcode',
                                    'requestingforproductengagementenlistment','updatingthisproductengagementenlistment','generateproductegagementenlistmentcode',
                                    'requestingforproductaftertasteenlistment','updatingthisproductaftertasteenlistment','generateproductaftertasteenlistmentcode',
                                    'listThisUserFeedbackEngagementProductEnlistmentRequests','listAllProductsEnlistedByDomain','listAllProductsEnlistedForEngagementByDomain',
                                    'listAllProductsEnlistedForAftertasteByDomain','listThisUserDomainIdcardEnlistmentRequests','listThisUserDomainBusinesscardEnlistmentRequests',
                                    'listThisUserDomainEventEnlistmentRequests','requestingforbusinessscardenlistment','requestingforidcardenlistment','listThisUserDomainIdcardEnlistmentRequests',
                                    'listThisUserDomainBusinesscardEnlistmentRequests','updatingthisidcardenlistment','updatingthisbusinesscardenlistment',
                                    'listThisUserDomainEventEnlistmentRequests','requestingforeventenlistment','updatethiseventenlistment','openthiseventenlistment','closethiseventenlistment',
                                    'listAllEventEnlistmentRequests','postponethiseventenlistment','requestingforproductoffencefeedbackenlistment',
                                    'generateproductoffencefeedbackenlistmentcode','requestingforproductaftertasteoffenceenlistment','generateproductaftertasoffenceteenlistmentcode',
                                    'listallfeedbackitemsinaunit','retrieveafeedbackitem'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * This is the function that list all particular user message enlistments
         */
        public function actionlistThisUserEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid and item_type=:type';
            $criteria->params = array(':userid'=>$user_id,':type'=>"messages");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that list all particular user product enlistments
         */
        public function actionlistThisUserProductEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid and item_type=:type';
            $criteria->params = array(':userid'=>$user_id,':type'=>"product");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that list all particular user product feedback enlistments
         */
        public function actionlistThisUserFeedbackProductEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid and item_type=:type';
            $criteria->params = array(':userid'=>$user_id,':type'=>"feedback");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that list all particular user product feedback enlistments
         */
        public function actionlistThisUserEngagementProductEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid and item_type=:type';
            $criteria->params = array(':userid'=>$user_id,':type'=>"engagement");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        
         /**
         * This is the function that list all particular user product engagement and feedback enlistments
         */
        public function actionlistThisUserFeedbackEngagementProductEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid and item_type=:type';
            $criteria->params = array(':userid'=>$user_id,':type'=>"aftertaste");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that list all particular domain id card enlistments request
         */
        public function actionlistThisUserDomainIdcardEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            //get the domain of this user
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlister_domain_id=:domainid and item_type=:type';
            $criteria->params = array(':domainid'=>$domain_id,':type'=>"idcard");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that list all particular domain business card enlistments request
         */
        public function actionlistThisUserDomainBusinesscardEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            //get the domain of this user
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlister_domain_id=:domainid and item_type=:type';
            $criteria->params = array(':domainid'=>$domain_id,':type'=>"businesscard");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that list all particular domain event enlistments request
         */
        public function actionlistThisUserDomainEventEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            //get the domain of this user
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlister_domain_id=:domainid and item_type=:type';
            $criteria->params = array(':domainid'=>$domain_id,':type'=>"event");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that list all particular event enlistments request
         */
        public function actionlistAllEventEnlistmentRequests(){
            $user_id = Yii::app()->user->id;
            
            //get the domain of this user
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='item_type=:type';
            $criteria->params = array(':type'=>"event");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistments,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that request for an item enlostment
         * 
         */
        public function actionrequestingforitemenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
     if($this->isUserVerifiedOnThisMessagePlatform($user_id,$_REQUEST['type'], $_REQUEST['originating_enlistment_type_address'])){
            $model->invoice_id = $location_invoice_id;
            if($_REQUEST['nature'] == "coded"){
                $model->nature =$_REQUEST['nature'];
                $model->coded_title =$_REQUEST['coded_title'];
                $model->coded_content_meaning = $_REQUEST['coded_content_meaning'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $model->nature =$_REQUEST['nature'];
                $model->coded_title =NULL;
                $model->coded_content_meaning = NULL;
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
            $model->title = $_REQUEST['title'];
            $model->content = $_REQUEST['content'];
            $model->item_type = strtolower("messages");
            $model->type = $_REQUEST['type'];
            $model->originating_enlistment_type_address = $_REQUEST['originating_enlistment_type_address'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            $city_id=NULL;
            
            
          
            //$this->verification_code = $this->generateTheVerificationCode($user_id,$domain_id);
            
            if($location_invoice_id>0){
                if($model->save()){
                   $verification_code = $this->getTheGeneratedVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the enlistment verification code: '$verification_code'. This code should be sent to those you want to view this enlistment"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                        ));
                } 
                  
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
                
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"You are trying to enlist from a/an $platform profile/account that had not been verified, Please verify the '$profile' profile/account before enlisting messages from it"
                        ));
                
                
            }
            
     }
     
     
     /**
      * This is the function that generates verification code for any message enlistment
      */
     public function getTheGeneratedVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
     }
     
     
      /**
      * This is the function that generates verification code for any message enlistment
      */
     public function getTheGeneratedVerificationIdentificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedVerificationIdentificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
     }
     
     
     /**
      * This is the function that confirms if a user profile had been verified for a particular messaging platform
      */
     public function isUserVerifiedOnThisMessagePlatform($user_id,$type, $originating_enlistment_type_address){
         $model = new UserVerificationOutcome;
         return $model->isUserVerifiedOnThisMessagePlatform($user_id,$type, $originating_enlistment_type_address);
     }
        
        
    /**
     * This is the function that confirms if a domain has a live transaction
     */  
     public function isDomainWithLiveTransaction($domain_id){
         $model = new DomainTransactions;
         return $model->isDomainWithLiveTransaction($domain_id);
     }
     
     
     /**
      * This is the function that adds a new domain transaction 
      */
     public function newDomainTransactionTreeAdded($domain_id){
         $model = new DomainTransactions;
         return $model->newDomainTransactionTreeAdded($domain_id);
     }
     
     /**
      * This is the function that returns a live domain transaction
      */
     public function getTheLiveDomainTransId($domain_id){
         $model = new DomainTransactions;
         return $model->getTheLiveDomainTransId($domain_id);
     }
     
        
    /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
        
        
           /**
         * This is the function that retrieves the pending invoice id of a user's location
         */
        public function getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id){
            $model = new Invoice;
            return $model->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
        }
        
        
        /**
         * This is the function that retrieves information about user enlistments
         */
        public function actionretrieveenlistmentinfo(){
            $enlistment_id = $_REQUEST['id'];
            
             //retrieve enlistment information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$enlistment_id);
            $enlistment = UserEnlistmentRequest::model()->find($criteria); 
            
            //retrieve verification code information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:listid';
            $criteria->params = array(':listid'=>$enlistment_id);
            $code = EnlistmentVerificationCode::model()->find($criteria); 
            
            //get the name of the unit/branch
            $unit = $this->getThisLocationUnitName($enlistment['unit_id']);
            
            if($enlistment_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "enlistment" =>$enlistment,
                                    "code"=>$code,
                                    'unit'=>$unit
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that gets the name of a unit
         */
        public function getThisLocationUnitName($unit_id){
            $model = new LocationUnit;
            return $model->getThisLocationUnitName($unit_id);
        }
        
        
        
        /**
         * This is the function that updates a message enlistment
         */
        public function actionupdatemesageenlistment(){
            
           $_id = $_POST['id'];
            $model= UserEnlistmentRequest::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
       // if($this->isThisEnlistmentCodeActive($_REQUEST['date_of_expiry'])){
            if($this->isUserVerifiedOnThisMessagePlatform($user_id,$_REQUEST['type'], $_REQUEST['originating_enlistment_type_address'])){
            $model->invoice_id = $location_invoice_id;
            if($_REQUEST['nature'] == "coded"){
                $model->nature =$_REQUEST['nature'];
                $model->coded_title =$_REQUEST['coded_title'];
                $model->coded_content_meaning = $_REQUEST['coded_content_meaning'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                   $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = $_REQUEST['is_verification_required'];
                    }else{
                        $is_verification_required = 0;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $model->nature =$_REQUEST['nature'];
                $model->coded_title =NULL;
                $model->coded_content_meaning = NULL;
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                     $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                      $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                   $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
            $model->title = $_REQUEST['title'];
            $model->content = $_REQUEST['content'];
            $model->item_type = strtolower("messages");
            $model->type = $_REQUEST['type'];
            $model->originating_enlistment_type_address = $_REQUEST['originating_enlistment_type_address'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            
          
            //$this->verification_code = $this->generateTheVerificationCode($user_id,$domain_id);
            
            if($location_invoice_id>0){
                if($model->save()){
                 // if($this->isEnlistmentCodeInformationnUpdatedSuccessfully($model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth)){
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Message Enlistment is updated succesfully"
                        ));
                      
                 /** }else{
                       header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Either no amendment was made or there was an issue trying to update the enlistment verification code. Please try again. If the problem persist, contact customer service for assistance"
                        ));
                  }
                  * 
                  */
              
                }else{
                  header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
                }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
                
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"You are trying to enlist from a/an $platform profile/account that had not been verified, Please verify the '$profile' profile/account before enlisting messages from it"
                        ));
                
                
            }
            
      /**  }else{
             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This code had expired and therefore it cannot be updated. You may however wish to generate a new verification code for this enlistment"
                        ));
            
            
        }    
       * 
       */
     
            
            
        }
        
        /**
         * This is the function that updates the enlistment verification code information
         */
        public function isEnlistmentCodeInformationnUpdatedSuccessfully($nature,$id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth){
            $model = new EnlistmentVerificationCode;
            return $model->isEnlistmentCodeInformationnUpdatedSuccessfully($nature,$id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth);
        }
        
        
        /**
         * This is the function that determines if an enlistment code is still valid
         */
        public function isThisEnlistmentCodeActive($date_of_expiry){
            $model = new EnlistmentVerificationCode;
            return $model->isThisEnlistmentCodeActive($date_of_expiry);
        }
        
        
        /**
         * This is the function that generates codes for an enistment
         */
        public function actiongeneratemesageenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('messages'); 
            $city_id=NULL;
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                   // $viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the enlistment verification code: '$verification_code'. This code should be sent to those you want to view this enlistment"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please discard this enlistment and try again. If the problem persist, contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
        
        
        
        
        /**
         * This is the function that request for a product enlostment
         * 
         */
        public function actionrequestingforproductenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("product");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            
             if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }
                
            }
            
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = NULL;
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = NULL;
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = NULL;
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = NULL;
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = NULL;
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = NULL;
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename = NULL;
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
                     
            
                
           
            
     }
     
     
     /**
      * This is the function that updates product enlistment request
      */
     public function actionupdatingthisproductenlistment(){
           $_id = $_POST['id'];
          $model= UserEnlistmentRequest::model()->findByPk($_id);
          
          $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           
            $model->invoice_id = $location_invoice_id;
         
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("product");
            //$model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            $model->city_id=$city_id;
            
             if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = $model->retrieveTheExistingFrontviewImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = $model->retrieveTheExistingBackviewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename =$model->retrieveTheExistingTopviewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = $model->retrieveTheExistingBottomviewImage($_id);
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = $model->retrieveTheExistingRightviewImage($_id);
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = $model->retrieveTheExistingLeftviewImage($_id);
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = $model->retrieveTheExistingInteriorviewImage($_id);
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = $model->retrieveTheExistingEngineviewImage($_id);
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = $model->retrieveTheExistingBoothviewImage($_id);
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename =$model->retrieveTheExistingContentviewImage($_id);
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                         header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This product enlistment is updated successfully."
                                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
          
         
     }
     
     
     
     /**
         * This is the function that generates codes for a product enistment
         */
        public function actiongenerateproductenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('product');     
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please try again or  contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
        
        
        
        /**
         * This is the function that request for a product feedbacck enlostment
         * 
         */
        public function actionrequestingforproductfeedbackenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                   // $viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("feedback");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            $model->feedback_item_type = $_REQUEST['feedback_item_type'];
            if(isset($_REQUEST['service_outlet_type'])){
                $model->service_outlet_type = $_REQUEST['service_outlet_type'];
            }
           if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
            
            if(isset($_REQUEST['feedback_display_medium'])){
                $feedback_display_medium = $_REQUEST['feedback_display_medium'];
            }else{
                $feedback_display_medium = "all";
            }
                 
            
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = NULL;
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = NULL;
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = NULL;
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = NULL;
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = NULL;
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = NULL;
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename = NULL;
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedFeedbackVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the feedback enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity and also a means to obtain feedback from the consumer"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
                    
            
     }
     
     
      /**
      * This is the function that generates verification code for any message enlistment
      */
     public function getTheGeneratedFeedbackVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedFeedbackVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
     }
     
     
     /**
         * This is the function that request for a product feedbacck enlostment
         * 
         */
        public function actionrequestingforproductengagementenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("engagement");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            $model->feedback_item_type = $_REQUEST['feedback_item_type'];
            if(isset($_REQUEST['service_outlet_type'])){
                $model->service_outlet_type = $_REQUEST['service_outlet_type'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
            if(isset($_REQUEST['feedback_display_medium'])){
                $feedback_display_medium = $_REQUEST['feedback_display_medium'];
            }else{
                $feedback_display_medium = "all";
            }
                       
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = NULL;
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = NULL;
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = NULL;
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = NULL;
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = NULL;
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = NULL;
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename = NULL;
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedEngagementVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the engagement enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
                    
            
     }
     
     
      /**
      * This is the function that generates verification code for any engagement enlistment
      */
     public function getTheGeneratedEngagementVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedEngagementVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
     }
     
     
     
     /**
         * This is the function that request for a product feedbacck enlostment
         * 
         */
        public function actionrequestingforproductaftertasteenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("aftertaste");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            $model->feedback_item_type = $_REQUEST['feedback_item_type'];
            if(isset($_REQUEST['service_outlet_type'])){
                $model->service_outlet_type = $_REQUEST['service_outlet_type'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
            if(isset($_REQUEST['feedback_display_medium'])){
                $feedback_display_medium = $_REQUEST['feedback_display_medium'];
            }else{
                $feedback_display_medium = "all";
            }
                      
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = NULL;
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = NULL;
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = NULL;
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = NULL;
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = NULL;
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = NULL;
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename = NULL;
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedAftertasteVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the after taste enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
                    
            
     }
     
      /**
      * This is the function that generates verification code for any feedbck & engagement enlistment
      */
     public function getTheGeneratedAftertasteVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedAftertasteVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
     }
     
     
     
      /**
      * This is the function that updates product feedback enlistment request
      */
     public function actionupdatingthisproductfeedbackenlistment(){
           $_id = $_POST['id'];
          $model= UserEnlistmentRequest::model()->findByPk($_id);
          
          $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           
            $model->invoice_id = $location_invoice_id;
         
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("feedback");
            //$model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            $model->feedback_item_type = $_REQUEST['feedback_item_type'];
            if(isset($_REQUEST['service_outlet_type'])){
                $model->service_outlet_type = $_REQUEST['service_outlet_type'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
           
                        
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = $model->retrieveTheExistingFrontviewImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = $model->retrieveTheExistingBackviewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename =$model->retrieveTheExistingTopviewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = $model->retrieveTheExistingBottomviewImage($_id);
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = $model->retrieveTheExistingRightviewImage($_id);
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = $model->retrieveTheExistingLeftviewImage($_id);
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = $model->retrieveTheExistingInteriorviewImage($_id);
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = $model->retrieveTheExistingEngineviewImage($_id);
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = $model->retrieveTheExistingBoothviewImage($_id);
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename =$model->retrieveTheExistingContentviewImage($_id);
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                         header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This product feedback enlistment is updated successfully."
                                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
          
         
     }
     
     
     
     
     /**
      * This is the function that updates product feedback enlistment request
      */
     public function actionupdatingthisproductaftertasteenlistment(){
           $_id = $_POST['id'];
          $model= UserEnlistmentRequest::model()->findByPk($_id);
          
          $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           
            $model->invoice_id = $location_invoice_id;
         
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("aftertaste");
            //$model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
            $model->feedback_item_type = $_REQUEST['feedback_item_type'];
            if(isset($_REQUEST['service_outlet_type'])){
                $model->service_outlet_type = $_REQUEST['service_outlet_type'];
            }
                        
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = $model->retrieveTheExistingFrontviewImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = $model->retrieveTheExistingBackviewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename =$model->retrieveTheExistingTopviewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = $model->retrieveTheExistingBottomviewImage($_id);
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = $model->retrieveTheExistingRightviewImage($_id);
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = $model->retrieveTheExistingLeftviewImage($_id);
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = $model->retrieveTheExistingInteriorviewImage($_id);
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = $model->retrieveTheExistingEngineviewImage($_id);
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = $model->retrieveTheExistingBoothviewImage($_id);
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename =$model->retrieveTheExistingContentviewImage($_id);
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                         header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This product after taste enlistment is updated successfully."
                                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
          
         
     }
     
     
     
     /**
      * This is the function that updates product engagement enlistment request
      */
     public function actionupdatingthisproductengagementenlistment(){
           $_id = $_POST['id'];
          $model= UserEnlistmentRequest::model()->findByPk($_id);
          
          $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           
            $model->invoice_id = $location_invoice_id;
         
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("engagement");
            //$model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
           if(isset($_REQUEST['location_id'])){
                $model->location_id = $_REQUEST['location_id'];
            }
            if(isset($_REQUEST['unit'])){
                if(is_numeric($_REQUEST['unit'])){
                    $model->unit_id = $_REQUEST['unit'];
                }else{
                     $model->unit_id = $_REQUEST['unit_id'];
                }
                
            }
            $model->feedback_item_type = $_REQUEST['feedback_item_type'];
            if(isset($_REQUEST['service_outlet_type'])){
                $model->service_outlet_type = $_REQUEST['service_outlet_type'];
            }
            
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = $model->retrieveTheExistingFrontviewImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = $model->retrieveTheExistingBackviewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename =$model->retrieveTheExistingTopviewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = $model->retrieveTheExistingBottomviewImage($_id);
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = $model->retrieveTheExistingRightviewImage($_id);
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = $model->retrieveTheExistingLeftviewImage($_id);
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = $model->retrieveTheExistingInteriorviewImage($_id);
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = $model->retrieveTheExistingEngineviewImage($_id);
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = $model->retrieveTheExistingBoothviewImage($_id);
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename =$model->retrieveTheExistingContentviewImage($_id);
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                         header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This product engagement enlistment is updated successfully."
                                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
          
         
     }
     
     
     /**
         * This is the function that generates codes for a product feedback nistment
         */
        public function actiongenerateproductfeedbackenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('feedback'); 
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
             if(isset($_REQUEST['feedback_display_medium'])){
                $feedback_display_medium = $_REQUEST['feedback_display_medium'];
               
            }else{
                $feedback_display_medium = "all";
            }   
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedFeedbackVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the feedback enlistment verification code: '$verification_code'. This code is a feedback code that should be placed on the product as a seal of originality and authenticity"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please try again or  contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
        
        
        
         /**
         * This is the function that generates codes for a product engagement nistment
         */
        public function actiongenerateproductegagementenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('engagement');   
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
             if(isset($_REQUEST['feedback_display_medium'])){
                $feedback_display_medium = $_REQUEST['feedback_display_medium'];
            }else{
                $feedback_display_medium = "all";
            }    
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                   // $viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedEngagementVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the engagement enlistment verification code: '$verification_code'. This code is a customer service code that should be placed on the product as a seal of originality and authenticity "
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please try again or  contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
     
        
        
        
        
        /**
         * This is the function that generates codes for a product engagement nistment
         */
        public function actiongenerateproductaftertasteenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('aftertaste'); 
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
              if(isset($_REQUEST['feedback_display_medium'])){
                $feedback_display_medium = $_REQUEST['feedback_display_medium'];
            }else{
                $feedback_display_medium = "all";
            }   
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedAftertasteVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required,$feedback_display_medium);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the after taste enlistment verification code: '$verification_code'. This code is both a customer service and a feedback code that should be placed on the product as a seal of originality and authenticity"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please try again or  contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
        
        
        /**
         * This is the function that list all product enlistments by a domain
         */
        public function actionlistAllProductsEnlistedByDomain(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlister_domain_id=:domainid and item_type=:type';
            $criteria->params = array(':domainid'=>$domain_id,':type'=>"feedback");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        /**
         * This is the function that list all product engagement enlistments by a domain
         */
        public function actionlistAllProductsEnlistedForEngagementByDomain(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlister_domain_id=:domainid and item_type=:type';
            $criteria->params = array(':domainid'=>$domain_id,':type'=>"engagement");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        
         /**
         * This is the function that list all product aftertaste enlistments by a domain
         */
        public function actionlistAllProductsEnlistedForAftertasteByDomain(){
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlister_domain_id=:domainid and item_type=:type';
            $criteria->params = array(':domainid'=>$domain_id,':type'=>"aftertaste");
            $enlistments = UserEnlistmentRequest::model()->findAll($criteria);
            
            if($enlistments===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" =>$enlistments,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
         /**
         * This is the function that request for a id card enlistment
         * 
         */
        public function actionrequestingforidcardenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'] * 365;
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'] * 365;
                }
               
            $city_id=NULL;                
            $model->name_on_id_card = $_REQUEST['name_on_id_card'];
            $model->address_on_id_card = $_REQUEST['address_on_id_card'];
            $model->job_title_on_id_card = $_REQUEST['job_title_on_id_card'];
            $model->id_card_holder_staff_number = $_REQUEST['id_card_holder_staff_number'];
            $model->id_card_holder_employment_status = $_REQUEST['id_card_holder_employment_status'];
            $model->id_card_emergency_numbers = $_REQUEST['id_card_emergency_numbers'];
            $model->id_card_emergency_email_addresses = $_REQUEST['id_card_emergency_email_addresses'];
            $model->id_card_holder_numbers = $_REQUEST['id_card_holder_numbers'];
            $model->id_card_holder_email_addresses = $_REQUEST['id_card_holder_email_addresses'];
            $model->is_id_card = 1;
            $model->id_card_expiration_date = date("Y-m-d H:i:s", strtotime($_POST['id_card_expiration_date'])); 
            $model->item_type = strtolower("idcard");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
           
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['id_card_holder_photo']['name'] != ""){
                    if($model->isUserPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['id_card_holder_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['id_card_front_view']['name'] != ""){
                    if($model->isCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['id_card_front_view']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['id_card_back_view']['name'] != ""){
                    if($model->isCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['id_card_back_view']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
              
                
                    
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->id_card_holder_photo = $model->moveTheUserPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->id_card_front_view = $model->moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->id_card_back_view = $model->moveTheCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedVerificationIdentificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the enlistment verification code: '$verification_code'. This code should be placed as a seal of originality and authenticity on the card"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment if available or contact customer service for assistance"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer service for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
 
     }
     
     
     
     
     /**
         * This is the function that request for a business card enlistment
         * 
         */
        public function actionrequestingforbusinessscardenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'] * 365;
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'] * 365;
                }
               
            $city_id=NULL;              
            $model->name_on_business_card = $_REQUEST['name_on_business_card'];
            $model->address_on_business_card = $_REQUEST['address_on_business_card'];
            $model->job_title_on_business_card = $_REQUEST['job_title_on_business_card'];
            $model->business_card_holder_employment_status = $_REQUEST['business_card_holder_employment_status'];
            $model->business_card_holder_phone_numbers = $_REQUEST['business_card_holder_phone_numbers'];
            $model->business_card_holder_email_addresses = $_REQUEST['business_card_holder_email_addresses'];
            $model->business_card_emergency_numbers = $_REQUEST['business_card_emergency_numbers'];
            $model->business_card_emergency_email_addresses = $_REQUEST['business_card_emergency_email_addresses'];
            $model->business_card_holder_staff_number = $_REQUEST['business_card_holder_staff_number'];
            $model->is_business_card = 1;
            $model->item_type = strtolower("businesscard");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            
            
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['business_card_holder_photo']['name'] != ""){
                    if($model->isCardOwnerPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['business_card_holder_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['business_card_front_view']['name'] != ""){
                    if($model->isBusinessCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['business_card_front_view']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['business_card_back_view']['name'] != ""){
                    if($model->isBusinessCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['business_card_back_view']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
              
                
                    
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->business_card_holder_photo = $model->moveTheCardOwnerPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->business_card_front_view = $model->moveTheBusinessCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->business_card_back_view = $model->moveTheBusinessCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedVerificationIdentificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the enlistment verification code: '$verification_code'. This code should be placed as a seal of originality and authenticity on the card"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment if available or contact customer service for assistance"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer service for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
  
     }
     
     
     /**
      * This is the function that updates business card enlistment information
      */
     public function actionupdatingthisidcardenlistment(){
         
          $_id = $_POST['id'];
          $model= UserEnlistmentRequest::model()->findByPk($_id);
          
          $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    //$enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
           /**     if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            * 
            */
               
            $city_id=NULL;                
            $model->name_on_id_card = $_REQUEST['name_on_id_card'];
            $model->address_on_id_card = $_REQUEST['address_on_id_card'];
            $model->job_title_on_id_card = $_REQUEST['job_title_on_id_card'];
            $model->id_card_holder_staff_number = $_REQUEST['id_card_holder_staff_number'];
            $model->id_card_holder_employment_status = $_REQUEST['id_card_holder_employment_status'];
            $model->id_card_emergency_numbers = $_REQUEST['id_card_emergency_numbers'];
            $model->id_card_emergency_email_addresses = $_REQUEST['id_card_emergency_email_addresses'];
            $model->id_card_holder_numbers = $_REQUEST['id_card_holder_numbers'];
            $model->id_card_holder_email_addresses = $_REQUEST['id_card_holder_email_addresses'];
            $model->is_id_card = 1;
            $model->id_card_expiration_date = date("Y-m-d H:i:s", strtotime($_POST['id_card_expiration_date'])); 
            $model->item_type = strtolower("idcard");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
           
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['id_card_holder_photo']['name'] != ""){
                    if($model->isUserPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['id_card_holder_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = $model->retrieveTheExistingIdentityCardholderImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['id_card_front_view']['name'] != ""){
                    if($model->isCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['id_card_front_view']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = $model->retrieveTheExistingIdentityCardFrontViewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['id_card_back_view']['name'] != ""){
                    if($model->isCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['id_card_back_view']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = $model->retrieveTheExistingIdentityCardBackViewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                    
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->id_card_holder_photo = $model->moveTheUserPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->id_card_front_view = $model->moveTheCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->id_card_back_view = $model->moveTheCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                    
                  if($location_invoice_id>0){
                      if($model->save()){
                         header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This id card enlistment information is updated successfully."
                                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
         
     }
     
     
     
     /**
      * This is the function that updates identity card enlistment information
      */
     public function actionupdatingthisbusinesscardenlistment(){
         
          $_id = $_POST['id'];
          $model= UserEnlistmentRequest::model()->findByPk($_id);
          
          $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    //$enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
              /**  if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
               * 
               */
               
            $city_id=NULL;              
            $model->name_on_business_card = $_REQUEST['name_on_business_card'];
            $model->address_on_business_card = $_REQUEST['address_on_business_card'];
            $model->job_title_on_business_card = $_REQUEST['job_title_on_business_card'];
            $model->business_card_holder_employment_status = $_REQUEST['business_card_holder_employment_status'];
            $model->business_card_holder_phone_numbers = $_REQUEST['business_card_holder_phone_numbers'];
            $model->business_card_holder_email_addresses = $_REQUEST['business_card_holder_email_addresses'];
            $model->business_card_emergency_numbers = $_REQUEST['business_card_emergency_numbers'];
            $model->business_card_emergency_email_addresses = $_REQUEST['business_card_emergency_email_addresses'];
            $model->business_card_holder_staff_number = $_REQUEST['business_card_holder_staff_number'];
            $model->is_business_card = 1;
            $model->item_type = strtolower("businesscard");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            
            
            
            $icon_error_counter = 0;
            //front view image
            if($_FILES['business_card_holder_photo']['name'] != ""){
                    if($model->isCardOwnerPhotoViewTypeAndSizeLegal()){
                        
                       $user_photo_filename = $_FILES['business_card_holder_photo']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $user_photo_filename = $model->retrieveTheExistingBusinessCardholderImage($_id);
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
        //back view image
            if($_FILES['business_card_front_view']['name'] != ""){
                    if($model->isBusinessCardFrontViewTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['business_card_front_view']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = $model->retrieveTheExistingBusinessCardFrontViewImage($_id);
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['business_card_back_view']['name'] != ""){
                    if($model->isBusinessCardBackViewTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['business_card_back_view']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = $model->retrieveTheExistingBusinessCardBackViewImage($_id);
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                    
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                        
                      $model->business_card_holder_photo = $model->moveTheCardOwnerPhotoToItsPathAndReturnTheFilename($model,$user_photo_filename);
                      $model->business_card_front_view = $model->moveTheBusinessCardFrontviewToItsPathAndReturnTheFilename($model,$front_filename);
                      $model->business_card_back_view = $model->moveTheBusinessCardBackviewToItsPathAndReturnTheFilename($model,$back_filename);
                      
                  if($location_invoice_id>0){
                      if($model->save()){
                         header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This id card enlistment information is updated successfully."
                                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
         
     }
     
     /**
      * This is the function that reqquestd for an eventg enlistment
      */
     public function actionrequestingforeventenlistment(){
         
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
            $model->event_name = $_REQUEST['event_name'];
            $model->event_venue = $_REQUEST['event_venue'];
            $model->event_purpose = $_REQUEST['event_purpose'];
            $model->event_delegate_enlisters = $_REQUEST['event_delegate_enlisters'];
            $model->event_delegate_verifiers = $_REQUEST['event_delegate_verifiers'];
            $model->event_delegate_checkiners = $_REQUEST['event_delegate_checkiners'];
            $model->event_delegate_checkouters = $_REQUEST['event_delegate_checkouters'];
            $model->item_type = strtolower("event");
            $model->event_code = $model->generateThisEventCode($domain_id,$platform,$model->item_type);
            if(isset($_REQUEST['allow_self_service_delegate_enrollment'])){
                $model->allow_self_service_delegate_enrollment = $_REQUEST['allow_self_service_delegate_enrollment'];
            }else{
                $model->allow_self_service_delegate_enrollment = 0;
            }
             if(isset($_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'])){
                $model->allow_delegate_enrollment_while_event_is_ongoing = $_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_enrollment_while_event_is_ongoing = 0;
            }
             if(isset($_REQUEST['allow_delegate_checkin_while_event_is_ongoing'])){
                $model->allow_delegate_checkin_while_event_is_ongoing = $_REQUEST['allow_delegate_checkin_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkin_while_event_is_ongoing = 0;
            }
             if(isset($_REQUEST['allow_delegate_checkout_while_event_is_ongoing'])){
                $model->allow_delegate_checkout_while_event_is_ongoing = $_REQUEST['allow_delegate_checkout_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkout_while_event_is_ongoing = 0;
            }
            $model->event_date = date("Y-m-d H:i:s", strtotime($_POST['event_date'])); 
            $model->event_status = strtolower("pending");
            $model->event_duration_in_mins = $_REQUEST['event_duration_in_mins'];
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
            
            if($location_invoice_id>0){
               if($model->save()){
                         header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" =>"This event is enlisted successfully. The event code is '$model->event_code'"
                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
           }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer service for assistance"
                        ));
                }
            
            
    }
    
    
    /**
     * This is the function that updates an event enlistment
     */
    public function actionupdatethiseventenlistment(){
        
        $_id = $_POST['id'];
         $model= UserEnlistmentRequest::model()->findByPk($_id);
         
      
            $platform = $_REQUEST['type'];
           
            $model->invoice_id = $_REQUEST['invoice_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->enlister_domain_id = $_REQUEST['enlister_domain_id'];
            $model->domain_transaction_id = $_REQUEST['domain_transaction_id'];
            $model->nature =$_REQUEST['nature'];
            $model->event_name = $_REQUEST['event_name'];
            $model->event_venue = $_REQUEST['event_venue'];
            $model->event_purpose = $_REQUEST['event_purpose'];
            $model->event_delegate_enlisters = $_REQUEST['event_delegate_enlisters'];
            $model->event_delegate_verifiers = $_REQUEST['event_delegate_verifiers'];
            $model->event_delegate_checkiners = $_REQUEST['event_delegate_checkiners'];
            $model->event_delegate_checkouters = $_REQUEST['event_delegate_checkouters'];
            $model->item_type = strtolower("event");
            $model->event_code = $_REQUEST['event_code'];
            if(isset($_REQUEST['allow_self_service_delegate_enrollment'])){
                $model->allow_self_service_delegate_enrollment = $_REQUEST['allow_self_service_delegate_enrollment'];
            }else{
                $model->allow_self_service_delegate_enrollment = 0;
            }
             if(isset($_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'])){
                $model->allow_delegate_enrollment_while_event_is_ongoing = $_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_enrollment_while_event_is_ongoing = 0;
            }
              if(isset($_REQUEST['allow_delegate_checkin_while_event_is_ongoing'])){
                $model->allow_delegate_checkin_while_event_is_ongoing = $_REQUEST['allow_delegate_checkin_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkin_while_event_is_ongoing = 0;
            }
             if(isset($_REQUEST['allow_delegate_checkout_while_event_is_ongoing'])){
                $model->allow_delegate_checkout_while_event_is_ongoing = $_REQUEST['allow_delegate_checkout_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkout_while_event_is_ongoing = 0;
            }
            $model->event_date = date("Y-m-d H:i:s", strtotime($_POST['event_date'])); 
            $model->event_status = $_REQUEST['event_status'];
            $model->event_duration_in_mins = $_REQUEST['event_duration_in_mins'];
            $model->type = $_REQUEST['type'];
            
            if( $model->event_status =="pending"){
                 if($model->save()){
                         header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" =>"This event enlistment informatoion is updated successfully'"
                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This event information cannot be updated at this time as it is current ongoing or it is already over"
                        ));
                
            }
            
           
            
        
    }
    
    
    /**
     * This is the function that declares an event opened
     */
    public function actionopenthiseventenlistment(){
        
         $_id = $_POST['id'];
         $model= UserEnlistmentRequest::model()->findByPk($_id);
         
                  
            $platform = $_REQUEST['type'];
          
            $model->invoice_id = $_REQUEST['invoice_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->enlister_domain_id = $_REQUEST['enlister_domain_id'];
            $model->domain_transaction_id = $_REQUEST['domain_transaction_id'];
            $model->nature =$_REQUEST['nature'];
            $model->event_name = $_REQUEST['event_name'];
            $model->event_venue = $_REQUEST['event_venue'];
            $model->event_purpose = $_REQUEST['event_purpose'];
            $model->event_delegate_enlisters = $_REQUEST['event_delegate_enlisters'];
            $model->event_delegate_verifiers = $_REQUEST['event_delegate_verifiers'];
            $model->event_delegate_checkiners = $_REQUEST['event_delegate_checkiners'];
            $model->event_delegate_checkouters = $_REQUEST['event_delegate_checkouters'];
            $model->item_type = strtolower("event");
            $model->event_code = $_REQUEST['event_code'];
            if(isset($_REQUEST['allow_self_service_delegate_enrollment'])){
                $model->allow_self_service_delegate_enrollment = $_REQUEST['allow_self_service_delegate_enrollment'];
            }else{
                $model->allow_self_service_delegate_enrollment = 0;
            }
             if(isset($_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'])){
                $model->allow_delegate_enrollment_while_event_is_ongoing = $_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_enrollment_while_event_is_ongoing = 0;
            }
              if(isset($_REQUEST['allow_delegate_checkin_while_event_is_ongoing'])){
                $model->allow_delegate_checkin_while_event_is_ongoing = $_REQUEST['allow_delegate_checkin_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkin_while_event_is_ongoing = 0;
            }
             if(isset($_REQUEST['allow_delegate_checkout_while_event_is_ongoing'])){
                $model->allow_delegate_checkout_while_event_is_ongoing = $_REQUEST['allow_delegate_checkout_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkout_while_event_is_ongoing = 0;
            }
            $model->event_date = date("Y-m-d H:i:s", strtotime($_POST['event_date'])); 
            $model->event_status = strtolower('running');
            $model->event_duration_in_mins = $_REQUEST['event_duration_in_mins'];
            $model->type = $_REQUEST['type'];
            $model->event_opening_time = new CDbExpression('NOW()');
            
            if($model->save()){
                         header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" =>"This enlisted event is opened successfully'"
                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
    }
    
    
    
     /**
     * This is the function that declares an event closed
     */
    public function actionclosethiseventenlistment(){
        
         $_id = $_POST['id'];
         $model= UserEnlistmentRequest::model()->findByPk($_id);
         
                  
            $platform = $_REQUEST['type'];
          
            $model->invoice_id = $_REQUEST['invoice_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->enlister_domain_id = $_REQUEST['enlister_domain_id'];
            $model->domain_transaction_id = $_REQUEST['domain_transaction_id'];
            $model->nature =$_REQUEST['nature'];
            $model->event_name = $_REQUEST['event_name'];
            $model->event_venue = $_REQUEST['event_venue'];
            $model->event_purpose = $_REQUEST['event_purpose'];
            $model->event_delegate_enlisters = $_REQUEST['event_delegate_enlisters'];
            $model->event_delegate_verifiers = $_REQUEST['event_delegate_verifiers'];
            $model->event_delegate_checkiners = $_REQUEST['event_delegate_checkiners'];
            $model->event_delegate_checkouters = $_REQUEST['event_delegate_checkouters'];
            $model->item_type = strtolower("event");
            $model->event_code = $_REQUEST['event_code'];
            if(isset($_REQUEST['allow_self_service_delegate_enrollment'])){
                $model->allow_self_service_delegate_enrollment = $_REQUEST['allow_self_service_delegate_enrollment'];
            }else{
                $model->allow_self_service_delegate_enrollment = 0;
            }
             if(isset($_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'])){
                $model->allow_delegate_enrollment_while_event_is_ongoing = $_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_enrollment_while_event_is_ongoing = 0;
            }
              if(isset($_REQUEST['allow_delegate_checkin_while_event_is_ongoing'])){
                $model->allow_delegate_checkin_while_event_is_ongoing = $_REQUEST['allow_delegate_checkin_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkin_while_event_is_ongoing = 0;
            }
             if(isset($_REQUEST['allow_delegate_checkout_while_event_is_ongoing'])){
                $model->allow_delegate_checkout_while_event_is_ongoing = $_REQUEST['allow_delegate_checkout_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkout_while_event_is_ongoing = 0;
            }
            $model->event_date = date("Y-m-d H:i:s", strtotime($_POST['event_date'])); 
           $model->event_status = strtolower('closed');
            $model->event_duration_in_mins = $_REQUEST['event_duration_in_mins'];
            $model->type = $_REQUEST['type'];
            $model->event_closing_time = new CDbExpression('NOW()');
            
            if($model->save()){
                         header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" =>"This enlisted event is closed successfully'"
                                ));
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
    }
    
    
    
     /**
     * This is the function that postpones an event date
     */
    public function actionpostponethiseventenlistment(){
        
        $_id = $_POST['id'];
         $model= UserEnlistmentRequest::model()->findByPk($_id);
         
      
            $platform = $_REQUEST['type'];
           
            $model->invoice_id = $_REQUEST['invoice_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->enlister_domain_id = $_REQUEST['enlister_domain_id'];
            $model->domain_transaction_id = $_REQUEST['domain_transaction_id'];
            $model->nature =$_REQUEST['nature'];
            $model->event_name = $_REQUEST['event_name'];
            $model->event_venue = $_REQUEST['event_venue'];
            $model->event_purpose = $_REQUEST['event_purpose'];
            $model->event_delegate_enlisters = $_REQUEST['event_delegate_enlisters'];
            $model->event_delegate_verifiers = $_REQUEST['event_delegate_verifiers'];
            $model->event_delegate_checkiners = $_REQUEST['event_delegate_checkiners'];
            $model->event_delegate_checkouters = $_REQUEST['event_delegate_checkouters'];
            $model->item_type = strtolower("event");
            $model->event_code = $_REQUEST['event_code'];
            if(isset($_REQUEST['allow_self_service_delegate_enrollment'])){
                $model->allow_self_service_delegate_enrollment = $_REQUEST['allow_self_service_delegate_enrollment'];
            }else{
                $model->allow_self_service_delegate_enrollment = 0;
            }
             if(isset($_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'])){
                $model->allow_delegate_enrollment_while_event_is_ongoing = $_REQUEST['allow_delegate_enrollment_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_enrollment_while_event_is_ongoing = 0;
            }
              if(isset($_REQUEST['allow_delegate_checkin_while_event_is_ongoing'])){
                $model->allow_delegate_checkin_while_event_is_ongoing = $_REQUEST['allow_delegate_checkin_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkin_while_event_is_ongoing = 0;
            }
             if(isset($_REQUEST['allow_delegate_checkout_while_event_is_ongoing'])){
                $model->allow_delegate_checkout_while_event_is_ongoing = $_REQUEST['allow_delegate_checkout_while_event_is_ongoing'];
            }else{
                $model->allow_delegate_checkout_while_event_is_ongoing = 0;
            }
            $model->event_date = date("Y-m-d H:i:s", strtotime($_POST['event_date'])); 
            $model->event_status = $_REQUEST['event_status'];
            $model->event_duration_in_mins = $_REQUEST['event_duration_in_mins'];
            $model->type = $_REQUEST['type'];
            
            if( $model->event_status =="pending"){
                 if($model->save()){
                     //update te delegates code information
                     if($this->isTheDelegatesCodeExpiryUpdated($_id,$model->event_date) == 0){
                         header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" =>"This event had been postponed successfully'"
                                ));
                         
                     }else{
                         header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                        "success" => mysql_errno() != 0,
                                        "msg" =>"Though the event had been postponed, but there where some issues trying to update the expiry date of some or all of the event delegates codes. Please contact customer service for assistance'"
                                ));
                     }
                         
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This event cannot be postponed at this time as it is currently ongoing or it is already over"
                        ));
                
            }
      
    }
    
    
     /**
             * This is the function that updates the expiry date of event delegate codes
             */
            public function isTheDelegatesCodeExpiryUpdated($event_id,$event_date){
                $model = new EnlistmentVerificationCode;
                return $model->isTheDelegatesCodeExpiryUpdated($event_id,$event_date);
            }
            
            
            
            /**
         * This is the function that request for a product feedbacck enlostment
         * 
         */
        public function actionrequestingforproductoffencefeedbackenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                   // $viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("feedback");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
                        
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = NULL;
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = NULL;
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = NULL;
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = NULL;
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = NULL;
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = NULL;
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename = NULL;
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedOffenceFeedbackVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the feedback enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity and also a means to obtain feedback from the consumer"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
                    
            
     }
     
     
      /**
      * This is the function that generates verification code for any message enlistment
      */
     public function getTheGeneratedOffenceFeedbackVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedOffenceFeedbackVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
     }
     
     
     
     
     /**
         * This is the function that generates codes for a product offence feedback enlistment
         */
        public function actiongenerateproductoffencefeedbackenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('feedback'); 
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedOffenceFeedbackVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the feedback enlistment verification code: '$verification_code'. This code is a feedback code that should be placed on the product as a seal of originality and authenticity"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please try again or  contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
        
        
        
        
         /**
         * This is the function that request for a product offence feedbacck enlistment
         * 
         */
        public function actionrequestingforproductaftertasteoffenceenlistment(){
            
            $model = new UserEnlistmentRequest;
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            //$profile = $_REQUEST['originating_enlistment_type_address'];
           // $location_invoice_id = 0;
            
            $model->invoice_id = $location_invoice_id;
            $model->nature =$_REQUEST['nature'];
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
              if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                    $enlistment_authorized_viewers_email = NULL;
                    $is_verification_required = 0;
                    
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                    $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                   if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
                
            
            $model->product_name = $_REQUEST['product_name'];
            $model->product_description = $_REQUEST['product_description'];
            $model->item_type = strtolower("aftertaste");
            $model->type = $_REQUEST['type'];
            $model->enlister_domain_id = $domain_id;
            $model->domain_transaction_id = $domain_trans_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->date_enlisted = new CDbExpression('NOW()');
            $model->user_id = $user_id;
                      
            $icon_error_counter = 0;
            //front view image
            if($_FILES['product_frontview_image']['name'] != ""){
                    if($model->isFrontViewTypeAndSizeLegal()){
                        
                       $frontview_filename = $_FILES['product_frontview_image']['name'];
                      //$frontview_size = $_FILES['product_frontview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $frontview_filename = NULL;
                   //$frontview_size = 0;
             
                }//end of the if icon is empty statement
                
                 
//back view image
            if($_FILES['product_backview_image']['name'] != ""){
                    if($model->isBackViewAndSizeLegal()){
                        
                       $backview_filename = $_FILES['product_backview_image']['name'];
                      //$backview_size = $_FILES['product_backview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $backview_filename = NULL;
                  // $backview_size = 0;
             
                }//end of the if icon is empty statement
                
                
           //top view image
            if($_FILES['product_topview_image']['name'] != ""){
                    if($model->isTopViewAndSizeLegal()){
                        
                       $topview_filename = $_FILES['product_topview_image']['name'];
                      //$topview_size = $_FILES['product_topview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $topview_filename = NULL;
                  // $topview_size = 0;
             
                }//end of the if icon is empty statement  
                
                
               //bottom view image
            if($_FILES['product_bottomview_image']['name'] != ""){
                    if($model->isBottomViewAndSizeLegal()){
                        
                       $bottomview_filename = $_FILES['product_bottomview_image']['name'];
                      //$bottomview_size = $_FILES['product_bottomview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottomview_filename = NULL;
                   //$bottomview_size = 0;
             
                }//end of the if icon is empty statement    
                
                
                
        //right side view image
            if($_FILES['product_rightview_image']['name'] != ""){
                    if($model->isRightViewAndSizeLegal()){
                        
                       $rightview_filename = $_FILES['product_rightview_image']['name'];
                      //$rightview_size = $_FILES['product_rightview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $rightview_filename = NULL;
                   //$rightview_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
         //left side view image
            if($_FILES['product_leftview_image']['name'] != ""){
                    if($model->isLeftViewAndSizeLegal()){
                        
                       $leftview_filename = $_FILES['product_leftview_image']['name'];
                      //$leftview_size = $_FILES['product_leftview_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $leftview_filename = NULL;
                   //$leftview_size = 0;
             
                }//end of the if icon is empty statement   
                
            
                
          //interior view image
            if($_FILES['product_interior_image']['name'] != ""){
                    if($model->isInteriorViewAndSizeLegal()){
                        
                       $interior_filename = $_FILES['product_interior_image']['name'];
                      //$interior_size = $_FILES['product_interior_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $interior_filename = NULL;
                   //$interior_size = 0;
             
                }//end of the if icon is empty statement   
                
         
                
        //engine view image
            if($_FILES['product_engine_image']['name'] != ""){
                    if($model->isEngineViewAndSizeLegal()){
                        
                       $engine_filename = $_FILES['product_engine_image']['name'];
                      //$engine_size = $_FILES['product_engine_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $engine_filename = NULL;
                   //$engine_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
                         
                
        //booth view image
            if($_FILES['product_booth_image']['name'] != ""){
                    if($model->isBoothViewAndSizeLegal()){
                        
                       $booth_filename = $_FILES['product_booth_image']['name'];
                     // $booth_size = $_FILES['product_booth_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $booth_filename = NULL;
                   ///$booth_size = 0;
             
                }//end of the if icon is empty statement   
                
                
                
             //image view image
            if($_FILES['product_content_image']['name'] != ""){
                    if($model->isContentViewAndSizeLegal()){
                        
                       $content_filename = $_FILES['product_content_image']['name'];
                      //$content_size = $_FILES['product_content_image']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $content_filename = NULL;
                   //$content_size = 0;
             
                }//end of the if icon is empty statement       
                
                 
             if($icon_error_counter ==0){
                 
                  if($model->validate()){
                      $model->product_frontview_image = $model->moveTheFrontviewToItsPathAndReturnTheFilename($model,$frontview_filename);
                      $model->product_backview_image = $model->moveTheBackviewToItsPathAndReturnTheFilename($model,$backview_filename);
                      $model->product_topview_image = $model->moveTheTopviewToItsPathAndReturnTheFilename($model,$topview_filename);
                      $model->product_bottomview_image = $model->moveTheBottomviewToItsPathAndReturnTheFilename($model,$bottomview_filename);
                      $model->product_rightview_image = $model->moveTheRightviewToItsPathAndReturnTheFilename($model,$rightview_filename);
                      $model->product_leftview_image = $model->moveTheLeftviewToItsPathAndReturnTheFilename($model,$leftview_filename);
                      $model->product_interior_image = $model->moveTheInteriorviewToItsPathAndReturnTheFilename($model,$interior_filename);
                      $model->product_engine_image = $model->moveTheEngineviewToItsPathAndReturnTheFilename($model,$engine_filename);
                      $model->product_booth_image = $model->moveTheBoothviewToItsPathAndReturnTheFilename($model,$booth_filename);
                      $model->product_content_image = $model->moveTheContentviewToItsPathAndReturnTheFilename($model,$content_filename);
                      
                      if($location_invoice_id>0){
                        if($model->save()){
                                     $verification_code = $this->getTheGeneratedAftertasteOffenceVerificationCodeForThisEnlistment($city_id,$model->nature,$model->id,$platform,$model->item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                                     if($verification_code !=0){
                                             header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                        "success" => mysql_errno() == 0,
                                                            "msg" =>"This is the after taste enlistment verification code: '$verification_code'. This code should be placed on the product as a seal of originality and authenticity"
                                                ));
                    }else{
                                header('Content-Type: application/json');
                                         echo CJSON::encode(array(
                                          "success" => mysql_errno() != 0,
                                           "msg" =>"There was an issue trying to generate this code. However, you can use the code generation option  to generate codes on this enlistment"
                                        ));
                     } 
                  
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is a validation error. Please check your input data and try again"
                        ));
                }
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
                }
                
                      
                      
                      
       }else{
                           //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: There are issues with some input data you provided. Please check the data and try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                      
                  }
                 
                 
                 
             }else{
                 $msg = "Please check the images you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                 
                 
             }
                    
            
     }
     
     
     
        /**
      * This is the function that generates offence verification code for any feedbck & engagement enlistment
      */
     public function getTheGeneratedAftertasteOffenceVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required){
         $model = new EnlistmentVerificationCode;
         return $model->getTheGeneratedAftertasteOffenceVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$item_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
     }
     
     
     
      /**
         * This is the function that generates codes for a product engagement nistment
         */
        public function actiongenerateproductaftertasoffenceteenlistmentcode(){
            $model = new EnlistmentVerificationCode;
            
            $enlistment_id = $_REQUEST['id'];
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            //confirm if these domain has a live transaction tree. create it if unavailable
            if($this->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $this->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $this->getTheLiveDomainTransId($domain_id);
            }
            $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            
            $platform = $_REQUEST['type'];
            $tem_type = strtolower('aftertaste'); 
            if($_REQUEST['city'] == ""){
                    $city_id = NULL;
                }else{
                    $city_id = $_REQUEST['city'];
                }
           if($_REQUEST['nature'] == "coded"){
                $nature =$_REQUEST['nature'];
                $is_paid_for_by_code_consumer = 0;
                $is_for_public = 0;
                $verify_public_with_parameter = NULL;
                $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
                 if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
            }else{
                $nature =$_REQUEST['nature'];
                if(isset($_REQUEST['is_paid_for_by_code_consumer'])){
                     $is_paid_for_by_code_consumer = $_REQUEST['is_paid_for_by_code_consumer'];
                }else{
                    $is_paid_for_by_code_consumer = 0;
                }
               
                if(isset($_REQUEST['is_for_public'])){
                    $is_for_public = $_REQUEST['is_for_public'];
                    $verify_public_with_parameter = $_REQUEST['verify_public_with_parameter'];
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                    $verify_receiver_with_nin_second_level_auth = 0;
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                     $enlistment_authorized_viewers_email = NULL;
                     $is_verification_required = 0;
                }else{
                   $is_for_public = 0;
                    $verify_public_with_parameter = NULL;
                     $enlistment_authorized_viewers_email = $_REQUEST['enlistment_authorized_viewers_email'];
                      if(isset($_REQUEST['is_verification_required'])){
                        $is_verification_required = 0;
                    }else{
                        $is_verification_required = 1;
                    }
                     if(isset($_REQUEST['verify_receiver_with_bvn_in_second_level_auth'])){
                    $verify_receiver_with_bvn_in_second_level_auth = $_REQUEST['verify_receiver_with_bvn_in_second_level_auth'];
                }else{
                    $verify_receiver_with_bvn_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_nin_second_level_auth'])){
                    $verify_receiver_with_nin_second_level_auth = $_REQUEST['verify_receiver_with_nin_second_level_auth'];
                }else{
                    $verify_receiver_with_nin_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pvc_in_second_level_auth'])){
                    $verify_receiver_with_pvc_in_second_level_auth = $_REQUEST['verify_receiver_with_pvc_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pvc_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'])){
                    $verify_receiver_registered_mobile_number_in_second_level_auth = $_REQUEST['verify_receiver_registered_mobile_number_in_second_level_auth'];
                }else{
                    $verify_receiver_registered_mobile_number_in_second_level_auth = 0;
                }
                if(isset($_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'])){
                    $verify_receiver_with_passport_number_in_second_level_auth = $_REQUEST['verify_receiver_with_passport_number_in_second_level_auth'];
                }else{
                    $verify_receiver_with_passport_number_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'])){
                    $verify_receiver_with_driving_license_in_second_level_auth = $_REQUEST['verify_receiver_with_driving_license_in_second_level_auth'];
                }else{
                    $verify_receiver_with_driving_license_in_second_level_auth = 0;
                }
                 if(isset($_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'])){
                    $verify_receiver_with_pension_pin_in_second_level_auth = $_REQUEST['verify_receiver_with_pension_pin_in_second_level_auth'];
                }else{
                    $verify_receiver_with_pension_pin_in_second_level_auth = 0;
                }
                }
                
                
                if($_REQUEST['code_type'] == "one_time"){
                    $code_type = "one_time";
                    //$viewership = "same_viewer";
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }else{
                     $code_type = $_REQUEST['code_type'];
                    $viewership = $_REQUEST['viewership'];
                    $day_to_expiry = $_REQUEST['day_to_expiry'];
                }
            }
             if($location_invoice_id>0){
               $verification_code = $this->getTheGeneratedAftertasteOffenceVerificationCodeForThisEnlistment($city_id,$nature,$enlistment_id,$platform,$tem_type,$user_id,$domain_trans_id,$domain_id,$is_paid_for_by_code_consumer,$is_for_public,$verify_public_with_parameter,$code_type,$viewership,$day_to_expiry,$verify_receiver_with_bvn_in_second_level_auth,$verify_receiver_with_nin_second_level_auth,$verify_receiver_with_pvc_in_second_level_auth,$verify_receiver_registered_mobile_number_in_second_level_auth,$verify_receiver_with_passport_number_in_second_level_auth,$verify_receiver_with_driving_license_in_second_level_auth,$verify_receiver_with_pension_pin_in_second_level_auth,$enlistment_authorized_viewers_email,$is_verification_required);
                if($verification_code !=0){
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This is the after taste enlistment verification code: '$verification_code'. This code is both a customer service and a feedback code that should be placed on the product as a seal of originality and authenticity"
                        ));
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to generate this code. Please try again or  contact customer service for assistance"
                        ));
                } 
                 
                 
                 
                 
                 
             }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The attempt to create an invoice for this transaction failed. Please try again or contact customer care for assistance"
                        ));
            }
            
        }
        
        
        /**
         * This is the function that retrieves all feedbac items for a unit
         */
        public function actionlistallfeedbackitemsinaunit(){
            
            $unit_id = $_REQUEST['unit_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
             $criteria->condition='unit_id=:unitid';
             $criteria->params = array(':unitid'=>$unit_id);
             $items= UserEnlistmentRequest::model()->findAll($criteria);
             
              if($items===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "items" => $items
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves an enlistment feedback item
         */
        public function actionretrieveafeedbackitem(){
             $enlistment_id = $_REQUEST['enlistment_id'];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:enlistid';
             $criteria->params = array(':enlistid'=>$enlistment_id);
             $item= UserEnlistmentRequest::model()->find($criteria);
             
              if($item===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "items" => $item
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        
        /**
         * This is the function that retrieves all feedback items for a domain location
         */
        public function actionlistallfeedbackitemsinadomainlocation(){
            
            $model = new LocationUnit;
            
            $targets = [];
            
            $location_id = $_REQUEST['location_id'];
            
            //get all units in this location
            $units = $model->getAllUnitsInThisLocation($location_id);
            
            foreach($units as $unit_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='unit_id=:unitid';
                $criteria->params = array(':unitid'=>$unit_id);
                $items= UserEnlistmentRequest::model()->findAll($criteria);
                
                foreach($items as $item){
                    $targets[] = $item;
                }
            }
            
           
             
              if($items===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "items" => $targets
                          
                           
                           
                          
                       ));
                       
                }
        }
}
