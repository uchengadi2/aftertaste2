<?php

class UserTypeController extends Controller
{
	
        private $_id;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'. 'listallusertypes'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listallusertypes','deleteoneusertype'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new UserType;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                $model->name = $_POST['name'];
                $model->description = $_POST['description'];
               // $model->checkDevice = $_POST['checkDevice'];
                $model->create_time = new CDbExpression('NOW()');
                //$model->create_user_id = Yii::app()->user->id;
                
                if(isset($_POST['checkDevice'])){
                        $model->checkDevice = $_POST['checkDevice'];
                 }else {
                        $model->checkDevice = 0;
                
                 }
                if($_FILES['icon']['name'] == null) {
                         $model->icon = $this->provideUsertypeIconWhenUnavailable($model);   
                        if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'Creation of User type was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation of User type was  not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }else if($_FILES['icon']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['icon']['tmp_name'];
                                 $fileName = $_FILES['icon']['name'];
                                 $type = $_FILES['icon']['type'];
                                 $size = $_FILES['icon']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->icon = $iconFileName;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                           
                                              //  $result['success'] = 'true';
                                                 $msg = 'Creation of User type was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'User type creation was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysqli_connect_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Failed. Icon/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysqli_connect_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png file is allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysqli_connect_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
	}
        
        

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            // Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
            
            $_id = $_POST['id'];
            $model=UserType::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            //$model->checkDevice = $_POST['checkDevice'];
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            
            if(isset($_POST['checkDevice'])){
                $model->checkDevice = $_POST['checkDevice'];
            }else{
                $model->checkDevice = 0;
                
            }
            
                
                if($_FILES['icon']['name'] == null) {
                            
                        if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'Creation of User type was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysqli_connect_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Creation of User type was  not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }else if($_FILES['icon']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['icon']['tmp_name'];
                                 $fileName = $_FILES['icon']['name'];
                                 $type = $_FILES['icon']['type'];
                                 $size = $_FILES['icon']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->icon = $iconFileName;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                           
                                              //  $result['success'] = 'true';
                                                 $msg = 'Creation of User type was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'User type creation was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysqli_connect_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Failed. Icon/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysqli_connect_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png file is allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysqli_connect_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneUserType()
	{
            //delete a usertype
            $_id = $_POST['id'];
            $model=UserType::model()->findByPk($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = 'The data was successfully deleted';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('UserType');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListAllUserTypes()
	{
	
            $userid = Yii::app()->user->id; 
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformUserAdmin")){
            $usertype = UserType::model()->findAll();
                if($usertype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($usertype);
                       
                }
        }else{
                //obtain the domain of the user
                $criteria = new CDbCriteria();
                $criteria->select = 'id, usertype_id';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$userid);
                $usertypeid= User::model()->find($criteria);
                
                //obtain the name of the usertype
                $criteria1 = new CDbCriteria();
                $criteria1->select = 'id, name';
                $criteria1->condition='id=:id';
                $criteria1->params = array(':id'=>$usertypeid->usertype_id);
                $type= UserType::model()->find($criteria1);
                
                 //spool the domain corresponding to that usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = '*';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$type->id);
                $usertype= UserType::model()->findAll($criteria3);
                if($usertype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($usertype);
                       
                } 
                
                
            }   
         
         
           
           
	}
        
        
         /**
        * Provide icon when unavailable
	 */
	public function provideUsertypeIconWhenUnavailable($model)
	{
		return 'usertype_unavailable.png';
	}
        
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
         
            
        

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return UserType the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=UserType::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

        public function justTestingStuff(){
          $str = "This is a good example";
          $splitted = str_split($str);
          foreach($splitted as $sp){
              if($sp == ""){
                  $counter = $counter + 1;
              }
          }
          
        }
}
