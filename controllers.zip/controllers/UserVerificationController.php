<?php

class UserVerificationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listallStaffUserVerificationRequestForARequestor','listallNonStaffUserVerificationRequestForARequestor',
                                    'addanewuserverificationrequest','getUserVerificationExtraDetails','updateuserverificationrequest','replaceverificationprimarysupportfile',
                                    'addanewnonstaffuserverificationrequest','listTheResultOfVerifiedUsersForAMember','reverifyuserverificationrequest','listuserallverifiedrequests',
                                    'listallawaitingUserVerificationRequest','verifyingASubjectUserVerificationRequest','getConsummableUserVerificationExtraDetails',
                                    'listdomainalluserverificationconsummablerequests'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that list all staff user verification request by a user
         */
        public function actionlistallStaffUserVerificationRequestForARequestor(){
            
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_id=:requestor and (status=:status and user_type=:type)';
            $criteria->params = array(':requestor'=>$user_id,':status'=>'requested',':type'=>'staff');
            $verifications = UserVerification::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verification" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that list all non staff user verification request by a user
         */
        public function actionlistallNonStaffUserVerificationRequestForARequestor(){
            
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_id=:requestor and (status=:status and user_type=:type)';
            $criteria->params = array(':requestor'=>$user_id,':status'=>'requested',':type'=>'nonstaff');
            $verifications = UserVerification::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verification" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
         /** 
          * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
        /**
         * This is the function that adds new user verification request
         */
        public function actionaddanewuserverificationrequest(){
            
            $model = new UserVerification;
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->user_id = $_REQUEST['id'];
            $model->issue_of_verification = $_REQUEST['verification_issue'];
            $model->status = strtolower('requested');
            $model->requestor_domain_id = $domain_id;
            $model->user_type = $_REQUEST['user_type'];
            $model->requestor_id = $user_id;
            $model->date_requested = new CDbExpression('NOW()');
            
            $icon_error_counter = 0;
            if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "A new verification request is successfully added";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add a new user verification request was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while adding a new user verification request";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
            
            
        }
        
        
        
        /**
         * This is the function that gets verification extra details
         */
        public function actiongetUserVerificationExtraDetails(){
            
             $user_id = $_REQUEST['id'];
             $issue_for_verification = $_REQUEST['issue_for_verification'];
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user = User::model()->find($criteria);
            
            $name = $user['name'];
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>"$issue_for_verification");
            $verification = VerificationCost::model()->find($criteria);
            
            if($verification['is_cost_quotable'] == 0){
                $cost =  $verification['cost'];
            }else{
                $cost = 0;
            }
            
            //get the consumption cost
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>"$issue_for_verification");
            $consumption = ConsumptionCost::model()->find($criteria);
            
            if($consumption['is_cost_quotable'] == 0){
                $consumption_cost =  $consumption['cost'];
            }else{
                $consumption_cost = 0;
            }
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "name" => $name,
                                     "verification_cost" => $cost,
                                     "consumption_cost"=>$consumption_cost
                                    
                    
                            ));
                       
                         }
            
        }
        
        /**
         * This is the function that updates user verification request
         */
        public function actionupdateuserverificationrequest(){
            
            $model = new UserVerification;
            $issue_for_verification = $_REQUEST['verification_issue'];
            $verification_id = $_REQUEST['id'];
            
            
            if($model->isTheUpdateOfTheVerificationIssueASuccess($verification_id,$issue_for_verification)){
                $msg ="You have successfully updated this user verification request" ;
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    
                                    
                    
                            ));
            }else{
                 $msg ="The attempt to update this user verification was not successful" ;
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    
                                    
                    
                            ));
            }
        }
        
        
        /**
         * This is the function that replaces the verification primary supporting document 
         */
        public function actionreplaceverificationprimarysupportfile(){
            
            $id = $_REQUEST['id'];
            $model=  UserVerification::model()->findByPk($id);
            $model->user_id =$_REQUEST['user_id'];
            $model->issue_of_verification =$_REQUEST['issue_of_verification'];
            $model->requestor_id =$_REQUEST['requestor_id'];
            $model->requestor_domain_id =$_REQUEST['requestor_domain_id'];
            $model->user_type =$_REQUEST['user_type'];
            $model->status = $_REQUEST['status'];
            $icon_error_counter = 0;
             if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "Verification primary support file replaced successfully";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to replace the user verification primary support file was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while attempting to to replace the primary support file";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
            
        }
        
        
         /**
         * This is the function that adds new non staff ser verification request
         */
        public function actionaddanewnonstaffuserverificationrequest(){
            
            $model = new UserVerification;
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->user_id = $_REQUEST['id'];
            $model->issue_of_verification = $_REQUEST['verification_issue'];
            $model->status = strtolower('requested');
            $model->requestor_domain_id = $domain_id;
            $model->user_type = $_REQUEST['user_type'];
            $model->requestor_id = $user_id;
            $model->date_requested = new CDbExpression('NOW()');
            
            $icon_error_counter = 0;
            if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "A new verification request is successfully added";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add a new user verification request was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while adding a new user verification request";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
            
            
        }
        
        /**
         * This is the function that lists all verified request of a user
         */
        public function actionlistTheResultOfVerifiedUsersForAMember(){
            
            $model = new UserVerification;
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="(requestor_id=:requestorid and requestor_domain_id=:domainid) and status=:status";
            $criteria->params = array(':requestorid'=>$user_id, ':domainid'=>$domain_id,':status'=>"verified");
            $verify = UserVerification::model()->findAll($criteria);
            
            if($verify===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verified" =>$verify,
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
        /**
         * This is the function that reverifies a user subject
         */
        public function actionreverifyuserverificationrequest(){
            
            $model = new UserVerification;
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->user_id = $_REQUEST['user_id'];
            $model->issue_of_verification = $_REQUEST['verification_issue'];
            $model->status = strtolower('requested');
            $model->requestor_domain_id = $domain_id;
            $model->user_type = $_REQUEST['user_type'];
            $model->requestor_id = $user_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->filename = $_REQUEST['filename'];
            
             if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "A new re-verification request is successfully added";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to reverify this subject was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
            
            
        }
        
        
         /**
         * This is the function that list all verified requests for a uer
         */
        public function actionlistuserallverifiedrequests(){
            
            $model = new DomainVerification;
            
            $subject_user_id = $_REQUEST['user_id'];
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="user_id=:userid and status=:status";
            $criteria->params = array(':userid'=>$subject_user_id,':status'=>"verified");
            $verify = UserVerification::model()->findAll($criteria);
            
            if($verify===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verified" =>$verify,
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        /**
         * This is the function that list all users' verification request
         */
        public function actionlistallawaitingUserVerificationRequest(){
            
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status and is_paid_for=:paidfor';
            $criteria->params = array(':status'=>'requested',':paidfor'=>1);
            $verifications = UserVerification::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verification" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that effects a user verification request
         */
        public function actionverifyingASubjectUserVerificationRequest(){
            
            $id = $_REQUEST['id'];
            $model=  UserVerification::model()->findByPk($id);
            $model->user_id =$_REQUEST['user_id'];
            $model->issue_of_verification =$_REQUEST['issue_for_verification'];
            $model->requestor_id =$_REQUEST['requestor_id'];
            $model->requestor_domain_id =$_REQUEST['requestor_domain_id'];
            $model->user_type =$_REQUEST['user_type'];
            $model->status = strtolower('verified');
            $model->date_verified = new CDbExpression('NOW()');
           $icon_error_counter = 0;
             if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->verified_filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "User Subject verification was done successfully";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false'
                         $msg = 'The attempt to verify this user subject was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while attempting to to verify this user subject";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
            
        }
        
        
        
        /**
         * This is the function that gets verification extra details
         */
        public function actiongetConsummableUserVerificationExtraDetails(){
            
             $verification_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="id=:id and status=:status";
            $criteria->params = array(':id'=>$verification_id,':status'=>"verified");
            $verify = UserVerification::model()->find($criteria);
             
             
             
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$verify['user_id']);
            $user = User::model()->find($criteria);
            
            $name = $user['name'];
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>$verify['issue_of_verification']);
            $verification = VerificationCost::model()->find($criteria);
            
            if($verification['is_cost_quotable'] == 0){
                $cost =  $verification['cost'];
            }else{
                $cost = 0;
            }
            
            //get the consumption cost
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>$verify['issue_of_verification']);
            $consumption = ConsumptionCost::model()->find($criteria);
            
            if($consumption['is_cost_quotable'] == 0){
                $consumption_cost =  $consumption['cost'];
            }else{
                $consumption_cost = 0;
            }
            
            if($verify===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "name" => $name,
                                     "verification_cost" => $cost,
                                    "consumption_cost"=>$consumption_cost,
                                    "verification"=>$verify
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        /**
         * This is the function that list all consumable user verification request for a domain
         */
        public function actionlistdomainalluserverificationconsummablerequests(){
            
            $model = new UserVerification;
            
            $subject_user_id = $_REQUEST['user_id'];
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $targets = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="domain_id=:domainid and is_consumption_paid_for=:paidfor";
            $criteria->params = array(':domainid'=>$domain_id,':paidfor'=>1);
            $verify = UserVerificationConsumedByOtherDomain::model()->findAll($criteria);
            
            foreach($verify as $ver){
                if($model->getTheUserIdForThisUserVerification($ver['verification_id']) ==$subject_user_id ){
                    $targets[] = $ver;
                }
            }
               
            if($verify==null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "consumable" =>$targets,
                                   
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
}
