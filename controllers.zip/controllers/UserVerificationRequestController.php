<?php

class UserVerificationRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisDomainUserPendingVerificationRequest','listThisDomainUserVerifiedVerificationRequest',
                                    'listThisDomainUserUnverifiedVerificationRequest','listAllDomainUserPendingVerificationRequest','listAllDomainUserVerifiedVerificationRequest',
                                    'listAllDomainUserUnverifiedVerificationRequest','retrieveextrauserverificationinfo','freezethisuserverificationrequest'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list this domain pending user verification request
         */
        public function actionlistThisDomainUserPendingVerificationRequest(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_domain_id=:domainid and status=:status';
            $criteria->params = array(':domainid'=>$domain_id,':status'=>'requested');
            $verifications =  UserVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that list this domain verified user request
         */
        public function actionlistThisDomainUserVerifiedVerificationRequest(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_domain_id=:domainid and status=:status';
            $criteria->params = array(':domainid'=>$domain_id,':status'=>'verified');
            $verifications =  UserVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
         /**
         * This is the function that list this domain  unverified user request
         */
        public function actionlistThisDomainUserUnverifiedVerificationRequest(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_domain_id=:domainid and status=:status';
            $criteria->params = array(':domainid'=>$domain_id,':status'=>'not_verified');
            $verifications =  UserVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that list all domain pending user request
         */
        public function actionlistAllDomainUserPendingVerificationRequest(){
            
                    
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'requested');
            $verifications =  UserVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        /**
         * This is the function that list all domain verified user request
         */
        public function actionlistAllDomainUserVerifiedVerificationRequest(){
            
                    
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'verified');
            $verifications =  UserVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
        
         /**
         * This is the function that list all domain unverified user request
         */
        public function actionlistAllDomainUserUnverifiedVerificationRequest(){
            
                    
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>'not_verified');
            $verifications =  UserVerificationRequest::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "request" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that retrieves extra domain verification parametser
         */
        public function actionretrieveextrauserverificationinfo(){
            $user_id = $_REQUEST['user_id'];
            
            //retrieve domain information
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user = User::model()->find($criteria); 
            
            //retrieve user verification request parameters
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:userid';
            $criteria->params = array(':userid'=>$user_id);
            $verifications = UserVerificationOutcome::model()->find($criteria); 
            
            if($user_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "user" => $user,
                                    "request"=>$verifications
                                    
                    
                            ));
                       
                         }
        }
        
        
        
         /**
         * This is the function that freezes a user verification request before the commencement of verification exercise
         */
        public function actionfreezethisuserverificationrequest(){
            $model = new UserVerificationRequest;
            $user_id = $_REQUEST['user_id'];
            
            if($model->isTheFreezingOfThisUserVerificationRequestASuccess($user_id)){
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => "This user verification request is frozen successfully"
                                   
                            ));
                
            }else{
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => "Attempt to freeze this user verification request was not successfully. You may however still go ahead with the verification exercise"
                                    
                                   
                            ));
                
            }
            
        }
}
