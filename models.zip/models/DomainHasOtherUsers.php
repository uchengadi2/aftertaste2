<?php

/**
 * This is the model class for table "domain_has_other_users".
 *
 * The followings are the available columns in table 'domain_has_other_users':
 * @property string $domain_id
 * @property string $member_id
 * @property string $type
 * @property string $status
 * @property string $security_level
 * @property string $security_level_weight
 * @property string $date_initiated
 * @property string $date_accepted
 * @property integer $initiated_user_id
 */
class DomainHasOtherUsers extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_has_other_users';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, member_id, type, security_level', 'required'),
			array('initiated_user_id', 'numerical', 'integerOnly'=>true),
			array('domain_id, member_id, status', 'length', 'max'=>10),
			array('type', 'length', 'max'=>8),
			array('security_level', 'length', 'max'=>11),
			array('security_level_weight', 'length', 'max'=>2),
			array('date_initiated, date_accepted', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('domain_id, member_id, type, status, security_level, security_level_weight, date_initiated, date_accepted, initiated_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'domain_id' => 'Domain',
			'member_id' => 'Member',
			'type' => 'Type',
			'status' => 'Status',
			'security_level' => 'Security Level',
			'security_level_weight' => 'Security Level Weight',
			'date_initiated' => 'Date Initiated',
			'date_accepted' => 'Date Accepted',
			'initiated_user_id' => 'Initiated User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('member_id',$this->member_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('security_level',$this->security_level,true);
		$criteria->compare('security_level_weight',$this->security_level_weight,true);
		$criteria->compare('date_initiated',$this->date_initiated,true);
		$criteria->compare('date_accepted',$this->date_accepted,true);
		$criteria->compare('initiated_user_id',$this->initiated_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainHasOtherUsers the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that retrievss customer users for a domain
         */
        public function getAllCustomersOfThisDomain($domain_id){
            
             $domain_members = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and type=:type';   
             $criteria->params = array(':domainid'=>$domain_id, ':type'=>'customer');
             $members = DomainHasOtherUsers::model()->findAll($criteria);
             
             foreach($members as $member){
                 $domain_members[] = $member['member_id'];
             }
             return $domain_members;
        }
        
        
        /**
         * This is the function that retrievss vendor users for a domain
         */
        public function getAllVendorsOfThisDomain($domain_id){
            
             $domain_members = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and type=:type';   
             $criteria->params = array(':domainid'=>$domain_id, ':type'=>'vendor');
             $members = DomainHasOtherUsers::model()->findAll($criteria);
             
             foreach($members as $member){
                 $domain_members[] = $member['member_id'];
             }
             return $domain_members;
        }
        
        
        /**
         * This is the function that gets all non staff memberrs of a domain
         */
        public function getAllNonStaffMembersOfThisDomain($domain_id){
            
             $domain_members = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid';   
             $criteria->params = array(':domainid'=>$domain_id);
             $members = DomainHasOtherUsers::model()->findAll($criteria);
             
             foreach($members as $member){
                 $domain_members[] = $member['member_id'];
             }
             return $domain_members;
            
        }
        
        
        /**
         * This is the function that gets the type of the other domain non staff user
         */
        public function getTheUserTypeOfThisMember($domain_id,$member_id){
            
            $domain_members = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and member_id=:member';   
             $criteria->params = array(':domainid'=>$domain_id, ':member'=>$member_id);
             $member = DomainHasOtherUsers::model()->find($criteria);
             return $member['type'];
            
        }
        
          /**
         * This is the function that gets the type of the other domain non staff user
         */
        public function getTheUserStatusOfThisMemberOnThisDomain($domain_id,$member_id){
            
            $domain_members = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='domain_id=:domainid and member_id=:member';   
             $criteria->params = array(':domainid'=>$domain_id, ':member'=>$member_id);
             $member = DomainHasOtherUsers::model()->find($criteria);
             return $member['status'];
            
        }
        
        
        /**
         * This is the function that adds a domain staff as a customer or vendor to that domain
         */
        public function isTheAdditionOfThisStaffAsACustomerOrVendorMemberASuccss($member_id,$domain_id,$type,$status){
            
            if($this->isTheRemovalOfAnyExistingRelationshipBetweenDomainAndMemberASuccess($member_id,$domain_id)){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('domain_has_other_users',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'member_id'=>$member_id,
                                    'type'=>"$type", 
                                    'status'=>"$status", 
                                   'security_level'=>"level0step0",
                                   'security_level_weight'=>0,
                                   'date_initiated'=>new CDbExpression('NOW()'),
                                   'initiated_user_id'=>Yii::app()->user->id
                           )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
            
        }
        
        
        
         /**
         * This is the function that adds a aonther domain staff as a customer or vendor to another domain
         */
        public function isTheAdditionOfThisUserAsADomainNonStaffMemberASuccss($member_id,$domain_id,$type,$status){
           
            if($this->isTheRemovalOfAnyExistingRelationshipBetweenDomainAndMemberASuccess($member_id,$domain_id)){
                 $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('domain_has_other_users',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'member_id'=>$member_id,
                                    'type'=>"$type", 
                                    'status'=>"$status", 
                                   'security_level'=>"level0step0",
                                   'security_level_weight'=>0,
                                   'date_initiated'=>new CDbExpression('NOW()'),
                                   'initiated_user_id'=>Yii::app()->user->id
                           )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
                
            }else{
                
                return false;
            }
           
        }
        
        
        
         /**
         * This is the function that adds a a user as customer or vendor to to a  domain
         */
        public function isTheAdditionOfThisUserAsANonStaffUserToThisDomainASuccess($member_id,$domain_id,$type,$status){
           
            if($this->isTheRemovalOfAnyExistingRelationshipBetweenDomainAndMemberASuccess($member_id,$domain_id)){
                 $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('domain_has_other_users',
                                  array(
                                    'domain_id'=>$domain_id,
                                    'member_id'=>$member_id,
                                    'type'=>"$type", 
                                    'status'=>"$status", 
                                   'security_level'=>"level0step0",
                                   'security_level_weight'=>0,
                                   'date_initiated'=>new CDbExpression('NOW()'),
                                   'initiated_user_id'=>Yii::app()->user->id
                           )
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
                
            }else{
                
                return false;
            }
           
        }
        
        
        
        
        /**
         * This is the function that removes any existing relationship between a domain and a member
         */
        public function isTheRemovalOfAnyExistingRelationshipBetweenDomainAndMemberASuccess($member_id,$domain_id){
            
            if($this->isThereAPriorRelationshipBetweenDomainAndMember($member_id,$domain_id)){
                 $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('domain_has_other_users','(domain_id=:domainid and member_id=:memberid)', array(':domainid'=>$domain_id,':memberid'=>$member_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                } 
                
            }else{
                return true;
            }
           
        }
        
        
        /**
         * This is the function that confirms if there is a prior relationship between domain and member
         */
        public function isThereAPriorRelationshipBetweenDomainAndMember($member_id,$domain_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_has_other_users')
                    ->where("domain_id = $domain_id and member_id=$member_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that updates a non staff information for a domain
         */
        public function isTheModificationOfThisNonStaffUserInfoASucces($domain_id,$member_id,$type,$status){
            
              $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('domain_has_other_users',
                                  array(
                                    'type'=>"$type",
                                    'status'=>$status 
                                   
                               
		
                            ),
                     ("domain_id=$domain_id and member_id=$member_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
}
