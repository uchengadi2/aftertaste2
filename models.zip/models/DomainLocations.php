<?php

/**
 * This is the model class for table "domain_locations".
 *
 * The followings are the available columns in table 'domain_locations':
 * @property string $id
 * @property string $name
 * @property string $address
 * @property string $domain_id
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 * 
 */
class DomainLocations extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_locations';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, address', 'length', 'max'=>250),
                        array('code', 'length', 'max'=>100),
			array('domain_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, address, domain_id, code,create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'address' => 'Address',
			'domain_id' => 'Domain',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainLocations the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that gets the location of a user
         */
        public function getTheLocationOfThisUser($user_id){
            $model = new User;
            
            $location_id = $model->getTheLocationIdOfThisUser($user_id);
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$location_id);
            $location= DomainLocations::model()->find($criteria1);
            
            return $location['name'];
        }
        
        
        /**
         * This is the function that determines if a location is for a domain
         */
        public function isThisInvoiceLocationForThisDomain($domain,$location_id){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$location_id);
            $location= DomainLocations::model()->find($criteria1);
            
            if($location['domain_id'] == $domain){
                return true;
            }else{
                return false;
            }
            
        }
      
        
        /**
         * This is the function that confirms if a location unit is for a domain
         * 
         */
        public function isThisLocationUnitForThisDomain($location_id,$domain_id){
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$location_id);
            $location= DomainLocations::model()->find($criteria1);
            
            if($location['domain_id']==$domain_id){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that determines the type of icon file
         */
        public function isIconTypeAndSizeLegal(){
            
           if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['icon']['tmp_name'];
                $iconFileName = $_FILES['icon']['name'];    
                $iconFileType = $_FILES['icon']['type'];
                $iconFileSize = $_FILES['icon']['size'];
            } 
                 
            if(($iconFileType === 'image/png'|| $iconFileType === 'image/jpg' || $iconFileType === 'image/jpeg')){
              return true;
               
            }else{
                return false;
            }
            
        }
        
        
        	/**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                   }
                    if($icon_filename==NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                    }else{
                        if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;
                          if($icon_filename != 'group_unavailable.png'){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }   
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['icons'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != 'group_unavailable.png'){ 
                                
                                if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['icons'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
					
                       
                               
        }
        
        
        	 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= DomainLocations::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               //$directoryPath = "c:\\xampp\htdocs\appspace_assets\\icons\\";
               $directoryPath = "..\appspace_assets\\icons\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['icon'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= DomainLocations::model()->find($criteria);
                
                if($icon['icon'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, icon';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= DomainLocations::model()->find($criteria);
                
                if($icon['icon']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
           /**
         * This is the function that retrieves the previous icon size
         */
        public function retrieveTheExistingIconImage($id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = DomainLocations::model()->find($criteria);
            
            
            return $icon['icon'];
        }
        
        
              /**
         * This is the function that retrieves the name of a location
         */
        public function getThisLocationName($id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $loction = DomainLocations::model()->find($criteria);
            
            
            return $loction['name'];
        }
        
        
        /**
         * This is the function that confirms if some analysis data are correct
         */
        public function isThisDataAuthentic($domain_id,$user_id,$location){
            if($this->isThisDomainAvailable($domain_id)){
                if($this->isThisUserInThisDomain($domain_id,$user_id)){
                    if($this->isThisLocationInThisDomain($domain_id,$location)){
                        return true;
                    }
                }
            }
            return false;
        }
        
        
        /**
         * This is the function that determines if a domain exist
         */
        public function isThisDomainAvailable($domain_id){
            $model = new ResourceGroupCategory;
            return $model->isThisDomainAvailable($domain_id);
                    
        }
        
        
        /**
         * This is the function that determines if a user belongs to a domain
         */
        public function isThisUserInThisDomain($domain_id,$user_id){
            $model = new User;
            return $model->isThisUserInThisDomain($domain_id,$user_id);
        }
        
        
        
        /**
         * This is the function that determines if a location is for a domain
         */
        public function isThisLocationInThisDomain($domain_id,$location){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_locations')
                    ->where("id = $location and domain_id=$domain_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
       /**
        * This is the function that retrieves a location code of a location
        */ 
        public function getTheLocationCodeOfThisLocation($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $location = DomainLocations::model()->find($criteria);
            
            
            return $location['code'];
            
        }
        
        /**
        * This is the function that retrieves the next location code numbering
        */ 
        public function getTheNextLocationCodeNumber($location_id){
            
            $model = DomainLocations::model()->findByPk($location_id); 
            //$current_code_numbering = $this->getTheCurrentCodeNumeringForThisLOcation($location_id);
            //$next_code_numbering = $current_code_numbering + 1;
            $model->code_numbering = $model->code_numbering + 1;
            if($model->save()){
                return $model->code_numbering;
            }else{
                return $this->generateTheRandomNumber();
            }
        }
        
        
        /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
}
