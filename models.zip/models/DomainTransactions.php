<?php

/**
 * This is the model class for table "domain_transactions".
 *
 * The followings are the available columns in table 'domain_transactions':
 * @property string $id
 * @property string $domain_id
 * @property string $transaction_code
 * @property string $status
 * @property string $transaction_date
 * @property integer $transacted_by
 */
class DomainTransactions extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_transactions';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, status', 'required'),
			array('transacted_by', 'numerical', 'integerOnly'=>true),
			array('domain_id', 'length', 'max'=>10),
			array('transaction_code', 'length', 'max'=>250),
			array('status', 'length', 'max'=>6),
			array('transaction_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, domain_id, transaction_code, status, transaction_date, transacted_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'domain_id' => 'Domain',
			'transaction_code' => 'Transaction Code',
			'status' => 'Status',
			'transaction_date' => 'Transaction Date',
			'transacted_by' => 'Transacted By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('transaction_code',$this->transaction_code,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('transaction_date',$this->transaction_date,true);
		$criteria->compare('transacted_by',$this->transacted_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainTransactions the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms there is a live domain transaction tree
         */
        public function isDomainWithLiveTransaction($domain_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('domain_transactions')
                    ->where("domain_id = $domain_id and status='live'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that creates a new domain transaction tree
         */
        public function newDomainTransactionTreeAdded($domain_id){
            
            $this->domain_id= $domain_id;
            $this->status = "live";
            $this->transaction_code = $this->generateDomainNewTransactionCode($domain_id);
            $this->trans_code_date_created = new CDbExpression('NOW()');
            
            if($this->save()){
                return $this->id;
            }else{
                return 0;
            }
        }
        
        
        /**
         * This is the function that returns the live domain transaction code
         */
        public function getTheLiveDomainTransId($domain_id){
             $criteria1 = new CDbCriteria();
             $criteria1->select = '*';
             $criteria1->condition='domain_id=:domainid and status=:status';
             $criteria1->params = array(':domainid'=>$domain_id,':status'=>'live');
             $trans= DomainTransactions::model()->find($criteria1);
             return $trans['id'];
        }
        
        
        /**
             * This is the function that ends domain transaction tree
             */
            public function isTheEndingOfdomainTransactionTreeASuccess($domain_id){
                
                //get the domain live trans id of this domain
                $trans_id = $this->getTheLiveDomainTransId($domain_id);
                
                if($trans_id != null){
                    $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('domain_transactions',
                                  array(
                                    'status'=>"billed",
                                    
                                    
                            ),
                     ("id=$trans_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
                    
                }else{
                    return false;
                }
                
                
       }
       
       
       /**
        * This is the function that generates domain transcode 
        */
       public function generateDomainNewTransactionCode($domain_id){
           //get the first 3 letters of the domain name
                $domain_first_three_letters = strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id)); 
           
            //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                               
                $transcode = "$domain_id$domain_first_three_letters$random_number";
                
                return $transcode; 
       }
       
       
        /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstThreeLetters($domain_id){
                
                $model = new Resourcegroupcategory;    
                //get the domain name
                $domainname = $model->getThisDomainName($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
        
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
}
