<?php

/**
 * This is the model class for table "feedback_template".
 *
 * The followings are the available columns in table 'feedback_template':
 * @property string $id
 * @property string $template_name
 * @property string $template_label
 * @property string $code_id
 * @property string $first_feedback_type
 * @property string $first_feedback_question
 * @property string $first_feedback_description
 * @property string $first_feedback_name
 * @property integer $is_first_feedback_included
 * @property string $first_feedback_purpose
 * @property string $second_feedback_type
 * @property string $second_feedback_question
 * @property string $second_feedback_description
 * @property string $second_feedback_purpose
 * @property string $second_feedback_name
 * @property integer $is_second_feedback_included
 * @property string $third_feedback_type
 * @property string $third_feedback_question
 * @property string $third_feedback_description
 * @property string $third_feedback_purpose
 * @property string $third_feedback_name
 * @property integer $is_third_feedback_included
 * @property string $fourth_feedback_type
 * @property string $fourth_feedback_question
 * @property string $fourth_feedback_description
 * @property string $fourth_feedback_purpose
 * @property string $fourth_feedback_name
 * @property integer $is_fourth_feedback_included
 * @property string $fifth_feedback_type
 * @property string $fifth_feedback_question
 * @property string $fifth_feedback_description
 * @property string $fifth_feedback_purpose
 * @property string $fifth_feedback_name
 * @property integer $is_fifth_feedback_included
 * @property string $status
 * @property integer $is_ussd_active
 * @property integer $maximum_feedback_required
 * @property integer $is_feedback_before_authenticity
 * @property integer $is_multiple_feedback_responses_allowed
 */
class FeedbackTemplate extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedback_template';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('code_id, status', 'required'),
			array('is_first_feedback_included, is_second_feedback_included, is_third_feedback_included, is_fourth_feedback_included, is_fifth_feedback_included, is_ussd_active, maximum_feedback_required, is_feedback_before_authenticity, is_multiple_feedback_responses_allowed', 'numerical', 'integerOnly'=>true),
			array('template_name, template_label, first_feedback_question, first_feedback_description, first_feedback_name, second_feedback_question, second_feedback_description, second_feedback_name, third_feedback_question, third_feedback_description, third_feedback_name, fourth_feedback_question, fourth_feedback_description, fourth_feedback_name, fifth_feedback_question, fifth_feedback_description, fifth_feedback_name', 'length', 'max'=>250),
			array('code_id', 'length', 'max'=>10),
			array('first_feedback_type, second_feedback_type, third_feedback_type, fourth_feedback_type, fifth_feedback_type', 'length', 'max'=>7),
			array('first_feedback_purpose, second_feedback_purpose, third_feedback_purpose, fourth_feedback_purpose, fifth_feedback_purpose', 'length', 'max'=>24),
			array('status', 'length', 'max'=>8),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, template_name, template_label, code_id, first_feedback_type, first_feedback_question, first_feedback_description, first_feedback_name, is_first_feedback_included, first_feedback_purpose, second_feedback_type, second_feedback_question, second_feedback_description, second_feedback_purpose, second_feedback_name, is_second_feedback_included, third_feedback_type, third_feedback_question, third_feedback_description, third_feedback_purpose, third_feedback_name, is_third_feedback_included, fourth_feedback_type, fourth_feedback_question, fourth_feedback_description, fourth_feedback_purpose, fourth_feedback_name, is_fourth_feedback_included, fifth_feedback_type, fifth_feedback_question, fifth_feedback_description, fifth_feedback_purpose, fifth_feedback_name, is_fifth_feedback_included, status, is_ussd_active, maximum_feedback_required, is_feedback_before_authenticity, is_multiple_feedback_responses_allowed', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'template_name' => 'Template Name',
			'template_label' => 'Template Label',
			'code_id' => 'Code',
			'first_feedback_type' => 'First Feedback Type',
			'first_feedback_question' => 'First Feedback Question',
			'first_feedback_description' => 'First Feedback Description',
			'first_feedback_name' => 'First Feedback Name',
			'is_first_feedback_included' => 'Is First Feedback Included',
			'first_feedback_purpose' => 'First Feedback Purpose',
			'second_feedback_type' => 'Second Feedback Type',
			'second_feedback_question' => 'Second Feedback Question',
			'second_feedback_description' => 'Second Feedback Description',
			'second_feedback_purpose' => 'Second Feedback Purpose',
			'second_feedback_name' => 'Second Feedback Name',
			'is_second_feedback_included' => 'Is Second Feedback Included',
			'third_feedback_type' => 'Third Feedback Type',
			'third_feedback_question' => 'Third Feedback Question',
			'third_feedback_description' => 'Third Feedback Description',
			'third_feedback_purpose' => 'Third Feedback Purpose',
			'third_feedback_name' => 'Third Feedback Name',
			'is_third_feedback_included' => 'Is Third Feedback Included',
			'fourth_feedback_type' => 'Fourth Feedback Type',
			'fourth_feedback_question' => 'Fourth Feedback Question',
			'fourth_feedback_description' => 'Fourth Feedback Description',
			'fourth_feedback_purpose' => 'Fourth Feedback Purpose',
			'fourth_feedback_name' => 'Fourth Feedback Name',
			'is_fourth_feedback_included' => 'Is Fourth Feedback Included',
			'fifth_feedback_type' => 'Fifth Feedback Type',
			'fifth_feedback_question' => 'Fifth Feedback Question',
			'fifth_feedback_description' => 'Fifth Feedback Description',
			'fifth_feedback_purpose' => 'Fifth Feedback Purpose',
			'fifth_feedback_name' => 'Fifth Feedback Name',
			'is_fifth_feedback_included' => 'Is Fifth Feedback Included',
			'status' => 'Status',
			'is_ussd_active' => 'Is Ussd Active',
			'maximum_feedback_required' => 'Maximum Feedback Required',
			'is_feedback_before_authenticity' => 'Is Feedback Before Authenticity',
			'is_multiple_feedback_responses_allowed' => 'Is Multiple Feedback Responses Allowed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('template_name',$this->template_name,true);
		$criteria->compare('template_label',$this->template_label,true);
		$criteria->compare('code_id',$this->code_id,true);
		$criteria->compare('first_feedback_type',$this->first_feedback_type,true);
		$criteria->compare('first_feedback_question',$this->first_feedback_question,true);
		$criteria->compare('first_feedback_description',$this->first_feedback_description,true);
		$criteria->compare('first_feedback_name',$this->first_feedback_name,true);
		$criteria->compare('is_first_feedback_included',$this->is_first_feedback_included);
		$criteria->compare('first_feedback_purpose',$this->first_feedback_purpose,true);
		$criteria->compare('second_feedback_type',$this->second_feedback_type,true);
		$criteria->compare('second_feedback_question',$this->second_feedback_question,true);
		$criteria->compare('second_feedback_description',$this->second_feedback_description,true);
		$criteria->compare('second_feedback_purpose',$this->second_feedback_purpose,true);
		$criteria->compare('second_feedback_name',$this->second_feedback_name,true);
		$criteria->compare('is_second_feedback_included',$this->is_second_feedback_included);
		$criteria->compare('third_feedback_type',$this->third_feedback_type,true);
		$criteria->compare('third_feedback_question',$this->third_feedback_question,true);
		$criteria->compare('third_feedback_description',$this->third_feedback_description,true);
		$criteria->compare('third_feedback_purpose',$this->third_feedback_purpose,true);
		$criteria->compare('third_feedback_name',$this->third_feedback_name,true);
		$criteria->compare('is_third_feedback_included',$this->is_third_feedback_included);
		$criteria->compare('fourth_feedback_type',$this->fourth_feedback_type,true);
		$criteria->compare('fourth_feedback_question',$this->fourth_feedback_question,true);
		$criteria->compare('fourth_feedback_description',$this->fourth_feedback_description,true);
		$criteria->compare('fourth_feedback_purpose',$this->fourth_feedback_purpose,true);
		$criteria->compare('fourth_feedback_name',$this->fourth_feedback_name,true);
		$criteria->compare('is_fourth_feedback_included',$this->is_fourth_feedback_included);
		$criteria->compare('fifth_feedback_type',$this->fifth_feedback_type,true);
		$criteria->compare('fifth_feedback_question',$this->fifth_feedback_question,true);
		$criteria->compare('fifth_feedback_description',$this->fifth_feedback_description,true);
		$criteria->compare('fifth_feedback_purpose',$this->fifth_feedback_purpose,true);
		$criteria->compare('fifth_feedback_name',$this->fifth_feedback_name,true);
		$criteria->compare('is_fifth_feedback_included',$this->is_fifth_feedback_included);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('is_ussd_active',$this->is_ussd_active);
		$criteria->compare('maximum_feedback_required',$this->maximum_feedback_required);
		$criteria->compare('is_feedback_before_authenticity',$this->is_feedback_before_authenticity);
		$criteria->compare('is_multiple_feedback_responses_allowed',$this->is_multiple_feedback_responses_allowed);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbackTemplate the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a template name had already been used for a service point
         */
        public function isThisTemplateNameAlreadyUsed($code_id,$template_name){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedback_template')
                    ->where("code_id = $code_id and template_name ='$template_name'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        /**
         * This is the function that retrieves the name of a feedback
         */
        public function getThisFeedbackTemplateName($id){
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$id);
             $template = FeedbackTemplate::model()->find($criteria);
             
             return $template['template_name'];
        }
        
        
       /**
        * This is the function that deactivates a feedback template
        */
        public function isTheDeactivationOfThisTemplateASuccess($id){
           $model= FeedbackTemplate::model()->findByPk($id);
           
           $model->status = "inactive";
           if($model->save()){
               return true;
           }else{
               return false;
           }
                   
        }
        
        
         /**
        * This is the function that disables a ussed feedback template
        */
        public function isTheDisablingOfThisUssdTemplateASuccess($id){
           $model= FeedbackTemplate::model()->findByPk($id);
           
           $model->is_ussd_active = 0;
           if($model->save()){
               return true;
           }else{
               return false;
           }
                   
        }
}
