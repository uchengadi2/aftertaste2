<?php

/**
 * This is the model class for table "feedback_template_option_response".
 *
 * The followings are the available columns in table 'feedback_template_option_response':
 * @property string $id
 * @property string $template_id
 * @property string $response
 * @property string $response_date
 * @property integer $response_from
 */
class FeedbackTemplateOptionResponse extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedback_template_option_response';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('template_id', 'required'),
			array('response_from', 'numerical', 'integerOnly'=>true),
			array('template_id', 'length', 'max'=>10),
			array('response, response_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, template_id, response, response_date, response_from', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'template_id' => 'Template',
			'response' => 'Response',
			'response_date' => 'Response Date',
			'response_from' => 'Response From',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('template_id',$this->template_id,true);
		$criteria->compare('response',$this->response,true);
		$criteria->compare('response_date',$this->response_date,true);
		$criteria->compare('response_from',$this->response_from);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbackTemplateOptionResponse the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that writes all the customer selected options on the response table
         */
        public function registerFeedbackOptionResponse($template_id,$feedback_options,$feedback_type,$ref,$question_number){
            
            $counter = 0;
            $options = [];
            if($feedback_type =="single_option"){
                $options = explode('+',$feedback_options);
                foreach($options as $opt){
                    if($this->writeTheOptionsToTheResponseTable($template_id,$opt,$feedback_type,$ref,$question_number)){
                        $counter = $counter + 1;
                    }
                }
               
            }else if($feedback_type =="multiple_option"){
                $options = explode('+',$feedback_options);
                foreach($options as $opt){
                    if($this->writeTheOptionsToTheResponseTable($template_id,$opt,$feedback_type,$ref,$question_number)){
                        $counter = $counter + 1;
                    }
                }
                
            }else if($feedback_type =="single_option_number"){
                $options = explode(',',$feedback_options);
                foreach($options as $opt){
                    if($this->writeTheOptionsToTheResponseTable($template_id,$opt,$feedback_type,$ref,$question_number)){
                        $counter = $counter + 1;
                    }
                }
                
            }else if($feedback_type =="multiple_option_number"){
                $options = explode(',',$feedback_options);
                foreach($options as $opt){
                   if($this->writeTheOptionsToTheResponseTable($template_id,$opt,$feedback_type,$ref,$question_number)){
                        $counter = $counter + 1;
                    }
                }
                
            }
            if($counter>0){
                return true;
            }else{
                return false;
            }
        }
        
        
         /**
         * This is the function that writes the response options to the table
         */
        public function writeTheOptionsToTheResponseTable($template_id,$response,$feedback_type,$ref,$question_number){
            
            if($response !=NULL){
                 //get the option id and the question number
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(template_id=:tempid and type=:type) and (`option`=:option and question_number=:quest)';   
             $criteria->params = array(':tempid'=>$template_id,':type'=>$feedback_type,':option'=>trim("$response"),':quest'=>$question_number);
             $options = FeedbackTemplateOptions::model()->find($criteria);

            //write a feedback option
             
             $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('feedback_template_option_response',
                                  array(
                                    'template_id'=>$template_id,
                                    'response'=>trim("$response"),
                                    'type'=>"$feedback_type",
                                    'trans_refid'=>$ref,
                                    'question_number'=>$question_number,
                                     'option_id'=>$options['id'],
                                    'response_date'=>new CDbExpression('NOW()')
                                   
                            )
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
            }else{
                return true;
            }
           
                             
                
        }
}
