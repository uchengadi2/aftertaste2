<?php

/**
 * This is the model class for table "feedback_template_options".
 *
 * The followings are the available columns in table 'feedback_template_options':
 * @property string $id
 * @property string $template_id
 * @property string $option
 */
class FeedbackTemplateOptions extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedback_template_options';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('template_id', 'required'),
			array('template_id', 'length', 'max'=>10),
			array('option', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, template_id, option', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'template_id' => 'Template',
			'option' => 'Option',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('template_id',$this->template_id,true);
		$criteria->compare('option',$this->option,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbackTemplateOptions the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that registers the feedback options
         */
        public function registerFeedbackOption($template_id,$feedback_options,$feedback_type,$question_number){
            $counter = 0;
            $options = [];
            if($feedback_type =="single_option"){
                $options = explode('+',$feedback_options);
                foreach($options as $opt){
                    if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type,$question_number)){
                        $counter = $counter + 1;
                    }
                }
               
            }else if($feedback_type =="multiple_option"){
                $options = explode('+',$feedback_options);
                foreach($options as $opt){
                    if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type,$question_number)){
                        $counter = $counter + 1;
                    }
                }
                
            }else if($feedback_type =="single_option_number"){
                $options = explode(',',$feedback_options);
                foreach($options as $opt){
                    if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type,$question_number)){
                        $counter = $counter + 1;
                    }
                }
                
            }else if($feedback_type =="multiple_option_number"){
                $options = explode(',',$feedback_options);
                foreach($options as $opt){
                   if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type,$question_number)){
                        $counter = $counter + 1;
                    }
                }
                
            }
            if($counter>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that writes the options to the table
         */
        public function writeTheOptionsToTheTable($template_id,$option,$feedback_type,$question_number){
            //write a feedback option
                             
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('feedback_template_options',
                                  array(
                                    'template_id'=>$template_id,
                                    'option'=>trim($option), 
                                    'type'=>$feedback_type,
                                     'question_number'=>$question_number
                                   
                            )
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        
        /**
         * This is the function that updates feedback options registeration
         **/
        public function updateFeedbackFeedbackOptionRegisteration($template_id,$feedback_options,$feedback_type){
            $counter = 0;
            $options = [];
            if($feedback_type =="single_option"){
                if($this->isTheDeletionOfCurrentFeedbackOptionsASuccess($template_id,$feedback_type)){
                    $options = explode('+',$feedback_options);
                    foreach($options as $opt){
                        if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type)){
                             $counter = $counter + 1;
                        }
                     }
                }
               
               
            }else if($feedback_type =="multiple_option"){
                if($this->isTheDeletionOfCurrentFeedbackOptionsASuccess($template_id,$feedback_type)){
                    $options = explode('+',$feedback_options);
                        foreach($options as $opt){
                                if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type)){
                                $counter = $counter + 1;
                        }
                    }
                    
                }
                
                
            }else if($feedback_type =="single_option_number"){
                if($this->isTheDeletionOfCurrentFeedbackOptionsASuccess($template_id,$feedback_type)){
                    $options = explode(',',$feedback_options);
                    foreach($options as $opt){
                        if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type)){
                            $counter = $counter + 1;
                        }
                    }
                    
                }
                
                
            }else if($feedback_type =="multiple_option_number"){
                if($this->isTheDeletionOfCurrentFeedbackOptionsASuccess($template_id,$feedback_type)){
                    $options = explode(',',$feedback_options);
                    foreach($options as $opt){
                        if($this->writeTheOptionsToTheTable($template_id,$opt,$feedback_type)){
                                $counter = $counter + 1;
                        }
                    }
                    
                }
                
                
            }
            if($counter>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that deletes feedback options
         */
        public function isTheDeletionOfCurrentFeedbackOptionsASuccess($template_id,$feedback_type){
                          
            $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('feedback_template_options', 'template_id=:templateid and type=:typeid', array(':templateid'=>$template_id, ':typeid'=>$feedback_type ));
            
                return $result;
        }
        
        
        
        /**
         * This is the options to retrieve active template options
         */
        public function getTheArrayOfTheQuestionOptionsNew($template_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='template_id=:id';   
             $criteria->params = array(':id'=>$template_id);
             $options = FeedbackTemplateOptions::model()->findAll($criteria);
             
             return $options;
        }
}
