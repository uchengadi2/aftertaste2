<?php

/**
 * This is the model class for table "feedbacks_for_enlistment".
 *
 * The followings are the available columns in table 'feedbacks_for_enlistment':
 * @property string $id
 * @property string $code_id
 * @property integer $is_product_likes
 * @property integer $is_product_hates
 * @property integer $is_was_needs_met
 * @property integer $is_unfillfulled_needs
 * @property integer $is_recommendation_to_friends
 * @property integer $is_can_get_product_again
 * @property integer $is_preferred_product_to_this
 * @property integer $is_your_expected_improvements_in_our_product
 */
class FeedbacksForEnlistment extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedbacks_for_enlistment';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('code_id', 'required'),
			array('is_product_likes, is_product_hates, is_was_needs_met, is_unfillfulled_needs, is_recommendation_to_friends, is_can_get_product_again, is_preferred_product_to_this, is_your_expected_improvements_in_our_product', 'numerical', 'integerOnly'=>true),
			array('code_id', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, code_id, is_product_likes, is_product_hates, is_was_needs_met, is_unfillfulled_needs, is_recommendation_to_friends, is_can_get_product_again, is_preferred_product_to_this, is_your_expected_improvements_in_our_product', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'code_id' => 'Code',
			'is_product_likes' => 'Is Product Likes',
			'is_product_hates' => 'Is Product Hates',
			'is_was_needs_met' => 'Is Was Needs Met',
			'is_unfillfulled_needs' => 'Is Unfillfulled Needs',
			'is_recommendation_to_friends' => 'Is Recommendation To Friends',
			'is_can_get_product_again' => 'Is Can Get Product Again',
			'is_preferred_product_to_this' => 'Is Preferred Product To This',
			'is_your_expected_improvements_in_our_product' => 'Is Your Expected Improvements In Our Product',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('code_id',$this->code_id,true);
		$criteria->compare('is_product_likes',$this->is_product_likes);
		$criteria->compare('is_product_hates',$this->is_product_hates);
		$criteria->compare('is_was_needs_met',$this->is_was_needs_met);
		$criteria->compare('is_unfillfulled_needs',$this->is_unfillfulled_needs);
		$criteria->compare('is_recommendation_to_friends',$this->is_recommendation_to_friends);
		$criteria->compare('is_can_get_product_again',$this->is_can_get_product_again);
		$criteria->compare('is_preferred_product_to_this',$this->is_preferred_product_to_this);
		$criteria->compare('is_your_expected_improvements_in_our_product',$this->is_your_expected_improvements_in_our_product);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbacksForEnlistment the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a feedback code already has a feedback design
         */
        public function isThisFeedbackAlreadyWithTemplate($code_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('feedbacks_for_enlistment')
                    ->where("code_id = $code_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that removes existing feedback template for a code
         */
        public function isTheRemovalOfThisFeedbackTemplateASuccess($code_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('feedbacks_for_enlistment', 'code_id=:codeid', array(':codeid'=>$code_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retrieve the feedback id of a code
         */
        public function getTheIdOfThisFeedback($code_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $feedback = FeedbacksForEnlistment::model()->find($criteria); 
            
           if(is_numeric($feedback['id']) and $feedback['id']>0){
               return $feedback['id'];
           }else{
               return 0;
           }
        }
}
