<?php

/**
 * This is the model class for table "platform_settings".
 *
 * The followings are the available columns in table 'platform_settings':
 * @property string $id
 * @property integer $icon_height
 * @property integer $icon_width
 * @property string $icon_mime_type
 * @property integer $poster_height
 * @property integer $poster_width
 * @property string $poster_mime_type
 * @property integer $video_size
 * @property string $document_mime_type
 * @property integer $zip_file_size
 * @property string $zip_file_type
 * @property double $max_renewal_activation_number
 * @property integer $default_allowable_min_percentage_task_share
 * @property string $platform_default_currency_id
 * @property string $platform_default_time_zone_id
 * @property integer $default_min_discount_settings
 * @property double $platform_revenue_share
 * @property integer $payment_holding_period
 * @property integer $excess_space_grace_period
 * @property integer $private_toolbox_min_subscription_no
 * @property double $private_toolboxes_price_per_task
 * @property double $price_for_one_gigabyte_size
 * @property integer $xml_validation
 * @property integer $json_validation
 * @property integer $enable_domain_initiator_verifier
 * @property integer $enable_platform_checker_verifier
 * @property integer $include_private_toolboxes_in_space_calculation
 * @property integer $include_public_toolboxes_in_space_calculation
 * @property integer $include_restricted_public_toolboxes_in_space_calculation
 * @property integer $include_private_and_public_toolboxes_in_space_calculation
 * @property integer $include_private_restricted_toolboxes_in_space_calculation
 * @property integer $include_reserved_toolboxes_in_space_calculation
 * @property integer $number_of_months_before_expiration
 * @property integer $gibberish_file_mime_type
 * @property integer $maximum_gibberish_filesize
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 * @property integer $is_closeable
 * @property integer $max_file_at_closure
 * @property integer $min_file_at_closure
 * @property integer $could_be_reopened
 * @property integer $could_be_reopened_when_max_number_not_reached
 * @property integer $overide_external_influence_on_parameters
 * @property integer $could_be_requested_by_all
 * @property integer $consummable_by_hood_members
 * @property integer $consummable_by_hood_clusters
 * @property integer $restrict_doc_capture_to_members_of_cluster
 * @property integer $capture_only_these_document_types
 * @property integer $accept_only_unique_batches
 * @property integer $accept_batches_containing_doc_of_these_type
 * @property integer $accept_batches_containing_doc_of_these_category
 * @property integer $are_boxes_closeable
 * @property integer $are_closed_boxes_openable
 * @property integer $closed_boxes_are_openable_only_max_batch_not_reached
 * @property integer $need_special_permission_to_open_closed_boxes
 * @property integer $need_special_permission_to_add_to_closed_boxes
 * @property integer $max_number_of_batches_before_closing
 * @property integer $min_number_of_batches_before_closing
 * @property integer $effect_blacklist_during_request
 * @property integer $effect_whitelist_during_request
 * @property integer $effect_blacklist_at_consumption
 * @property integer $effect_whitelist_at_consumption
 * @property string $list_conflict_resolution_preference
 * @property integer $accept_all_box_on_request
 * @property integer $box_is_consummable_by_hood_members
 * @property integer $box_is_consummable_by_hood_clusters
 * @property integer $apply_whitelist_during_request
 * @property integer $apply_blacklist_during_request
 * @property integer $documents_that_cannot_be_moved
 * @property integer $restrict_doc_movement_to_hoods
 * @property integer $documents_that_cannot_be_moved_outside_own_domain
 * @property integer $processor_docs_that_cant_be_moved
 * @property integer $processor_docs_that_cant_be_moved_beyond_domain
 * @property integer $batches_cannot_be_moved
 * @property integer $restrict_batch_movement_to_these_hood
 * @property integer $batch_cannot_be_moved_outside_own_domain
 * @property integer $boxes_cannot_be_moved
 * @property integer $restrict_movement_of_boxes_to_hoods
 * @property integer $boxes_cannot_be_moved_beyond_own_domain
 * @property integer $effect_blacklist_at_movement
 * @property integer $effect_whitelist_at_movement
 * @property integer $these_documents_not_reassignable
 * @property integer $these_batches_not_reassignable
 * @property integer $these_boxes_not_reassignable
 * @property integer $restrict_document_reassignment_to_hoods
 * @property integer $restrict_batches_reassignment_to_hoods
 * @property integer $restrict_boxes_reassignment_to_hoods
 * @property integer $restrict_documents_reassignment_to_hood_clusters
 * @property integer $restrict_batches_reassignment_to_hood_clusters
 * @property integer $restrict_boxes_reassignment_to_hood_clusters
 * @property integer $effect_lifespan_to_document_type
 * @property integer $effect_lifespan_to_document_categories
 * @property integer $retain_electronic_copy_of_destroyed_docs
 * @property integer $could_request_electronic_copy_of_destroyed_doc
 * @property integer $no_global_request_for_destroyed_documents_of_type
 * @property integer $hood_that_could_access_destroyed_docs
 * @property integer $clusters_that_could_access_destroyed_docs
 * @property integer $destroyed_doc_that_cannot_be_accessed_by_all
 * @property integer $effect_blacklist_at_destruction
 * @property integer $effect_whitelist_at_destruction
 * @property integer $all_doc_types_available_for_exchange
 * @property integer $doc_types_available_for_exchange
 * @property integer $restrict_exchange_of_doc_types_to_hood
 * @property integer $restrict_exchange_of_doc_types_to_clusters
 * @property integer $effect_blacklist_at_exchange
 * @property integer $effect_whitelist_at_exchange
 * @property integer $all_doc_types_available_for_sharing
 * @property integer $doc_types_available_for_sharing
 * @property integer $restrict_sharing_of_doc_types_to_hood
 * @property integer $restrict_sharing_of_doc_types_to_clusters
 * @property integer $effect_blacklist_at_sharing
 * @property integer $effect_whitelist_at_sharing
 * @property integer $all_doc_types_available_for_transfer
 * @property integer $doc_types_available_for_transfer
 * @property integer $restrict_transfer_of_doc_types_to_hood
 * @property integer $restrict_transfer_of_doc_types_to_clusters
 * @property integer $effect_blacklist_at_transfer
 * @property integer $effect_whitelist_at_transfer
 * @property integer $all_doc_type_available_for_trading
 * @property integer $these_doctypes_available_for_trading
 * @property integer $restrict_trading_of_doctype_to_hoods
 * @property integer $restrict_trading_of_doctype_to_clusters
 * @property integer $allow_hood_to_trade_on_own_private_store
 * @property integer $allow_doctypes_from_hoods_to_trade_on_store
 * @property integer $no_destroy_documents_from_hoods
 * @property integer $no_destroy_documents_from_hood_clusters
 * @property integer $no_destroy_documents_from_hood_processors
 * @property integer $no_destroy_documents_of_these_types
 * @property integer $no_destroy_documents_of_these_categories
 */
class PlatformSettings extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'platform_settings';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('icon_height, icon_width, poster_height, poster_width, video_size, zip_file_size, default_allowable_min_percentage_task_share, platform_default_currency_id, platform_default_time_zone_id, default_min_discount_settings, gibberish_file_mime_type, maximum_gibberish_filesize, list_conflict_resolution_preference', 'required'),
			array('icon_height, icon_width, poster_height, poster_width, video_size, zip_file_size, default_allowable_min_percentage_task_share, default_min_discount_settings, payment_holding_period, excess_space_grace_period, private_toolbox_min_subscription_no, xml_validation, json_validation, enable_domain_initiator_verifier, enable_platform_checker_verifier, include_private_toolboxes_in_space_calculation, include_public_toolboxes_in_space_calculation, include_restricted_public_toolboxes_in_space_calculation, include_private_and_public_toolboxes_in_space_calculation, include_private_restricted_toolboxes_in_space_calculation, include_reserved_toolboxes_in_space_calculation, number_of_months_before_expiration, gibberish_file_mime_type, maximum_gibberish_filesize, create_user_id, update_user_id, is_closeable, max_file_at_closure, min_file_at_closure, could_be_reopened, could_be_reopened_when_max_number_not_reached, overide_external_influence_on_parameters, could_be_requested_by_all, consummable_by_hood_members, consummable_by_hood_clusters, restrict_doc_capture_to_members_of_cluster, capture_only_these_document_types, accept_only_unique_batches, accept_batches_containing_doc_of_these_type, accept_batches_containing_doc_of_these_category, are_boxes_closeable, are_closed_boxes_openable, closed_boxes_are_openable_only_max_batch_not_reached, need_special_permission_to_open_closed_boxes, need_special_permission_to_add_to_closed_boxes, max_number_of_batches_before_closing, min_number_of_batches_before_closing, effect_blacklist_during_request, effect_whitelist_during_request, effect_blacklist_at_consumption, effect_whitelist_at_consumption, accept_all_box_on_request, box_is_consummable_by_hood_members, box_is_consummable_by_hood_clusters, apply_whitelist_during_request, apply_blacklist_during_request, documents_that_cannot_be_moved, restrict_doc_movement_to_hoods, documents_that_cannot_be_moved_outside_own_domain, processor_docs_that_cant_be_moved, processor_docs_that_cant_be_moved_beyond_domain, batches_cannot_be_moved, restrict_batch_movement_to_these_hood, batch_cannot_be_moved_outside_own_domain, boxes_cannot_be_moved, restrict_movement_of_boxes_to_hoods, boxes_cannot_be_moved_beyond_own_domain, effect_blacklist_at_movement, effect_whitelist_at_movement, these_documents_not_reassignable, these_batches_not_reassignable, these_boxes_not_reassignable, restrict_document_reassignment_to_hoods, restrict_batches_reassignment_to_hoods, restrict_boxes_reassignment_to_hoods, restrict_documents_reassignment_to_hood_clusters, restrict_batches_reassignment_to_hood_clusters, restrict_boxes_reassignment_to_hood_clusters, effect_lifespan_to_document_type, effect_lifespan_to_document_categories, retain_electronic_copy_of_destroyed_docs, could_request_electronic_copy_of_destroyed_doc, no_global_request_for_destroyed_documents_of_type, hood_that_could_access_destroyed_docs, clusters_that_could_access_destroyed_docs, destroyed_doc_that_cannot_be_accessed_by_all, effect_blacklist_at_destruction, effect_whitelist_at_destruction, all_doc_types_available_for_exchange, doc_types_available_for_exchange, restrict_exchange_of_doc_types_to_hood, restrict_exchange_of_doc_types_to_clusters, effect_blacklist_at_exchange, effect_whitelist_at_exchange, all_doc_types_available_for_sharing, doc_types_available_for_sharing, restrict_sharing_of_doc_types_to_hood, restrict_sharing_of_doc_types_to_clusters, effect_blacklist_at_sharing, effect_whitelist_at_sharing, all_doc_types_available_for_transfer, doc_types_available_for_transfer, restrict_transfer_of_doc_types_to_hood, restrict_transfer_of_doc_types_to_clusters, effect_blacklist_at_transfer, effect_whitelist_at_transfer, all_doc_type_available_for_trading, these_doctypes_available_for_trading, restrict_trading_of_doctype_to_hoods, restrict_trading_of_doctype_to_clusters, allow_hood_to_trade_on_own_private_store, allow_doctypes_from_hoods_to_trade_on_store, no_destroy_documents_from_hoods, no_destroy_documents_from_hood_clusters, no_destroy_documents_from_hood_processors, no_destroy_documents_of_these_types, no_destroy_documents_of_these_categories', 'numerical', 'integerOnly'=>true),
			array('max_renewal_activation_number, platform_revenue_share, private_toolboxes_price_per_task, price_for_one_gigabyte_size', 'numerical'),
			array('platform_default_currency_id, platform_default_time_zone_id', 'length', 'max'=>10),
			array('list_conflict_resolution_preference', 'length', 'max'=>9),
			array('icon_mime_type, poster_mime_type, document_mime_type, zip_file_type, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, icon_height, icon_width, icon_mime_type, poster_height, poster_width, poster_mime_type, video_size, document_mime_type, zip_file_size, zip_file_type, max_renewal_activation_number, default_allowable_min_percentage_task_share, platform_default_currency_id, platform_default_time_zone_id, default_min_discount_settings, platform_revenue_share, payment_holding_period, excess_space_grace_period, private_toolbox_min_subscription_no, private_toolboxes_price_per_task, price_for_one_gigabyte_size, xml_validation, json_validation, enable_domain_initiator_verifier, enable_platform_checker_verifier, include_private_toolboxes_in_space_calculation, include_public_toolboxes_in_space_calculation, include_restricted_public_toolboxes_in_space_calculation, include_private_and_public_toolboxes_in_space_calculation, include_private_restricted_toolboxes_in_space_calculation, include_reserved_toolboxes_in_space_calculation, number_of_months_before_expiration, gibberish_file_mime_type, maximum_gibberish_filesize, create_time, update_time, create_user_id, update_user_id, is_closeable, max_file_at_closure, min_file_at_closure, could_be_reopened, could_be_reopened_when_max_number_not_reached, overide_external_influence_on_parameters, could_be_requested_by_all, consummable_by_hood_members, consummable_by_hood_clusters, restrict_doc_capture_to_members_of_cluster, capture_only_these_document_types, accept_only_unique_batches, accept_batches_containing_doc_of_these_type, accept_batches_containing_doc_of_these_category, are_boxes_closeable, are_closed_boxes_openable, closed_boxes_are_openable_only_max_batch_not_reached, need_special_permission_to_open_closed_boxes, need_special_permission_to_add_to_closed_boxes, max_number_of_batches_before_closing, min_number_of_batches_before_closing, effect_blacklist_during_request, effect_whitelist_during_request, effect_blacklist_at_consumption, effect_whitelist_at_consumption, list_conflict_resolution_preference, accept_all_box_on_request, box_is_consummable_by_hood_members, box_is_consummable_by_hood_clusters, apply_whitelist_during_request, apply_blacklist_during_request, documents_that_cannot_be_moved, restrict_doc_movement_to_hoods, documents_that_cannot_be_moved_outside_own_domain, processor_docs_that_cant_be_moved, processor_docs_that_cant_be_moved_beyond_domain, batches_cannot_be_moved, restrict_batch_movement_to_these_hood, batch_cannot_be_moved_outside_own_domain, boxes_cannot_be_moved, restrict_movement_of_boxes_to_hoods, boxes_cannot_be_moved_beyond_own_domain, effect_blacklist_at_movement, effect_whitelist_at_movement, these_documents_not_reassignable, these_batches_not_reassignable, these_boxes_not_reassignable, restrict_document_reassignment_to_hoods, restrict_batches_reassignment_to_hoods, restrict_boxes_reassignment_to_hoods, restrict_documents_reassignment_to_hood_clusters, restrict_batches_reassignment_to_hood_clusters, restrict_boxes_reassignment_to_hood_clusters, effect_lifespan_to_document_type, effect_lifespan_to_document_categories, retain_electronic_copy_of_destroyed_docs, could_request_electronic_copy_of_destroyed_doc, no_global_request_for_destroyed_documents_of_type, hood_that_could_access_destroyed_docs, clusters_that_could_access_destroyed_docs, destroyed_doc_that_cannot_be_accessed_by_all, effect_blacklist_at_destruction, effect_whitelist_at_destruction, all_doc_types_available_for_exchange, doc_types_available_for_exchange, restrict_exchange_of_doc_types_to_hood, restrict_exchange_of_doc_types_to_clusters, effect_blacklist_at_exchange, effect_whitelist_at_exchange, all_doc_types_available_for_sharing, doc_types_available_for_sharing, restrict_sharing_of_doc_types_to_hood, restrict_sharing_of_doc_types_to_clusters, effect_blacklist_at_sharing, effect_whitelist_at_sharing, all_doc_types_available_for_transfer, doc_types_available_for_transfer, restrict_transfer_of_doc_types_to_hood, restrict_transfer_of_doc_types_to_clusters, effect_blacklist_at_transfer, effect_whitelist_at_transfer, all_doc_type_available_for_trading, these_doctypes_available_for_trading, restrict_trading_of_doctype_to_hoods, restrict_trading_of_doctype_to_clusters, allow_hood_to_trade_on_own_private_store, allow_doctypes_from_hoods_to_trade_on_store, no_destroy_documents_from_hoods, no_destroy_documents_from_hood_clusters, no_destroy_documents_from_hood_processors, no_destroy_documents_of_these_types, no_destroy_documents_of_these_categories', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'icon_height' => 'Icon Height',
			'icon_width' => 'Icon Width',
			'icon_mime_type' => 'Icon Mime Type',
			'poster_height' => 'Poster Height',
			'poster_width' => 'Poster Width',
			'poster_mime_type' => 'Poster Mime Type',
			'video_size' => 'Video Size',
			'document_mime_type' => 'Document Mime Type',
			'zip_file_size' => 'Zip File Size',
			'zip_file_type' => 'Zip File Type',
			'max_renewal_activation_number' => 'Max Renewal Activation Number',
			'default_allowable_min_percentage_task_share' => 'Default Allowable Min Percentage Task Share',
			'platform_default_currency_id' => 'Platform Default Currency',
			'platform_default_time_zone_id' => 'Platform Default Time Zone',
			'default_min_discount_settings' => 'Default Min Discount Settings',
			'platform_revenue_share' => 'Platform Revenue Share',
			'payment_holding_period' => 'Payment Holding Period',
			'excess_space_grace_period' => 'Excess Space Grace Period',
			'private_toolbox_min_subscription_no' => 'Private Toolbox Min Subscription No',
			'private_toolboxes_price_per_task' => 'Private Toolboxes Price Per Task',
			'price_for_one_gigabyte_size' => 'Price For One Gigabyte Size',
			'xml_validation' => 'Xml Validation',
			'json_validation' => 'Json Validation',
			'enable_domain_initiator_verifier' => 'Enable Domain Initiator Verifier',
			'enable_platform_checker_verifier' => 'Enable Platform Checker Verifier',
			'include_private_toolboxes_in_space_calculation' => 'Include Private Toolboxes In Space Calculation',
			'include_public_toolboxes_in_space_calculation' => 'Include Public Toolboxes In Space Calculation',
			'include_restricted_public_toolboxes_in_space_calculation' => 'Include Restricted Public Toolboxes In Space Calculation',
			'include_private_and_public_toolboxes_in_space_calculation' => 'Include Private And Public Toolboxes In Space Calculation',
			'include_private_restricted_toolboxes_in_space_calculation' => 'Include Private Restricted Toolboxes In Space Calculation',
			'include_reserved_toolboxes_in_space_calculation' => 'Include Reserved Toolboxes In Space Calculation',
			'number_of_months_before_expiration' => 'Number Of Months Before Expiration',
			'gibberish_file_mime_type' => 'Gibberish File Mime Type',
			'maximum_gibberish_filesize' => 'Maximum Gibberish Filesize',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
			'is_closeable' => 'Is Closeable',
			'max_file_at_closure' => 'Max File At Closure',
			'min_file_at_closure' => 'Min File At Closure',
			'could_be_reopened' => 'Could Be Reopened',
			'could_be_reopened_when_max_number_not_reached' => 'Could Be Reopened When Max Number Not Reached',
			'overide_external_influence_on_parameters' => 'Overide External Influence On Parameters',
			'could_be_requested_by_all' => 'Could Be Requested By All',
			'consummable_by_hood_members' => 'Consummable By Hood Members',
			'consummable_by_hood_clusters' => 'Consummable By Hood Clusters',
			'restrict_doc_capture_to_members_of_cluster' => 'Restrict Doc Capture To Members Of Cluster',
			'capture_only_these_document_types' => 'Capture Only These Document Types',
			'accept_only_unique_batches' => 'Accept Only Unique Batches',
			'accept_batches_containing_doc_of_these_type' => 'Accept Batches Containing Doc Of These Type',
			'accept_batches_containing_doc_of_these_category' => 'Accept Batches Containing Doc Of These Category',
			'are_boxes_closeable' => 'Are Boxes Closeable',
			'are_closed_boxes_openable' => 'Are Closed Boxes Openable',
			'closed_boxes_are_openable_only_max_batch_not_reached' => 'Closed Boxes Are Openable Only Max Batch Not Reached',
			'need_special_permission_to_open_closed_boxes' => 'Need Special Permission To Open Closed Boxes',
			'need_special_permission_to_add_to_closed_boxes' => 'Need Special Permission To Add To Closed Boxes',
			'max_number_of_batches_before_closing' => 'Max Number Of Batches Before Closing',
			'min_number_of_batches_before_closing' => 'Min Number Of Batches Before Closing',
			'effect_blacklist_during_request' => 'Effect Blacklist During Request',
			'effect_whitelist_during_request' => 'Effect Whitelist During Request',
			'effect_blacklist_at_consumption' => 'Effect Blacklist At Consumption',
			'effect_whitelist_at_consumption' => 'Effect Whitelist At Consumption',
			'list_conflict_resolution_preference' => 'List Conflict Resolution Preference',
			'accept_all_box_on_request' => 'Accept All Box On Request',
			'box_is_consummable_by_hood_members' => 'Box Is Consummable By Hood Members',
			'box_is_consummable_by_hood_clusters' => 'Box Is Consummable By Hood Clusters',
			'apply_whitelist_during_request' => 'Apply Whitelist During Request',
			'apply_blacklist_during_request' => 'Apply Blacklist During Request',
			'documents_that_cannot_be_moved' => 'Documents That Cannot Be Moved',
			'restrict_doc_movement_to_hoods' => 'Restrict Doc Movement To Hoods',
			'documents_that_cannot_be_moved_outside_own_domain' => 'Documents That Cannot Be Moved Outside Own Domain',
			'processor_docs_that_cant_be_moved' => 'Processor Docs That Cant Be Moved',
			'processor_docs_that_cant_be_moved_beyond_domain' => 'Processor Docs That Cant Be Moved Beyond Domain',
			'batches_cannot_be_moved' => 'Batches Cannot Be Moved',
			'restrict_batch_movement_to_these_hood' => 'Restrict Batch Movement To These Hood',
			'batch_cannot_be_moved_outside_own_domain' => 'Batch Cannot Be Moved Outside Own Domain',
			'boxes_cannot_be_moved' => 'Boxes Cannot Be Moved',
			'restrict_movement_of_boxes_to_hoods' => 'Restrict Movement Of Boxes To Hoods',
			'boxes_cannot_be_moved_beyond_own_domain' => 'Boxes Cannot Be Moved Beyond Own Domain',
			'effect_blacklist_at_movement' => 'Effect Blacklist At Movement',
			'effect_whitelist_at_movement' => 'Effect Whitelist At Movement',
			'these_documents_not_reassignable' => 'These Documents Not Reassignable',
			'these_batches_not_reassignable' => 'These Batches Not Reassignable',
			'these_boxes_not_reassignable' => 'These Boxes Not Reassignable',
			'restrict_document_reassignment_to_hoods' => 'Restrict Document Reassignment To Hoods',
			'restrict_batches_reassignment_to_hoods' => 'Restrict Batches Reassignment To Hoods',
			'restrict_boxes_reassignment_to_hoods' => 'Restrict Boxes Reassignment To Hoods',
			'restrict_documents_reassignment_to_hood_clusters' => 'Restrict Documents Reassignment To Hood Clusters',
			'restrict_batches_reassignment_to_hood_clusters' => 'Restrict Batches Reassignment To Hood Clusters',
			'restrict_boxes_reassignment_to_hood_clusters' => 'Restrict Boxes Reassignment To Hood Clusters',
			'effect_lifespan_to_document_type' => 'Effect Lifespan To Document Type',
			'effect_lifespan_to_document_categories' => 'Effect Lifespan To Document Categories',
			'retain_electronic_copy_of_destroyed_docs' => 'Retain Electronic Copy Of Destroyed Docs',
			'could_request_electronic_copy_of_destroyed_doc' => 'Could Request Electronic Copy Of Destroyed Doc',
			'no_global_request_for_destroyed_documents_of_type' => 'No Global Request For Destroyed Documents Of Type',
			'hood_that_could_access_destroyed_docs' => 'Hood That Could Access Destroyed Docs',
			'clusters_that_could_access_destroyed_docs' => 'Clusters That Could Access Destroyed Docs',
			'destroyed_doc_that_cannot_be_accessed_by_all' => 'Destroyed Doc That Cannot Be Accessed By All',
			'effect_blacklist_at_destruction' => 'Effect Blacklist At Destruction',
			'effect_whitelist_at_destruction' => 'Effect Whitelist At Destruction',
			'all_doc_types_available_for_exchange' => 'All Doc Types Available For Exchange',
			'doc_types_available_for_exchange' => 'Doc Types Available For Exchange',
			'restrict_exchange_of_doc_types_to_hood' => 'Restrict Exchange Of Doc Types To Hood',
			'restrict_exchange_of_doc_types_to_clusters' => 'Restrict Exchange Of Doc Types To Clusters',
			'effect_blacklist_at_exchange' => 'Effect Blacklist At Exchange',
			'effect_whitelist_at_exchange' => 'Effect Whitelist At Exchange',
			'all_doc_types_available_for_sharing' => 'All Doc Types Available For Sharing',
			'doc_types_available_for_sharing' => 'Doc Types Available For Sharing',
			'restrict_sharing_of_doc_types_to_hood' => 'Restrict Sharing Of Doc Types To Hood',
			'restrict_sharing_of_doc_types_to_clusters' => 'Restrict Sharing Of Doc Types To Clusters',
			'effect_blacklist_at_sharing' => 'Effect Blacklist At Sharing',
			'effect_whitelist_at_sharing' => 'Effect Whitelist At Sharing',
			'all_doc_types_available_for_transfer' => 'All Doc Types Available For Transfer',
			'doc_types_available_for_transfer' => 'Doc Types Available For Transfer',
			'restrict_transfer_of_doc_types_to_hood' => 'Restrict Transfer Of Doc Types To Hood',
			'restrict_transfer_of_doc_types_to_clusters' => 'Restrict Transfer Of Doc Types To Clusters',
			'effect_blacklist_at_transfer' => 'Effect Blacklist At Transfer',
			'effect_whitelist_at_transfer' => 'Effect Whitelist At Transfer',
			'all_doc_type_available_for_trading' => 'All Doc Type Available For Trading',
			'these_doctypes_available_for_trading' => 'These Doctypes Available For Trading',
			'restrict_trading_of_doctype_to_hoods' => 'Restrict Trading Of Doctype To Hoods',
			'restrict_trading_of_doctype_to_clusters' => 'Restrict Trading Of Doctype To Clusters',
			'allow_hood_to_trade_on_own_private_store' => 'Allow Hood To Trade On Own Private Store',
			'allow_doctypes_from_hoods_to_trade_on_store' => 'Allow Doctypes From Hoods To Trade On Store',
			'no_destroy_documents_from_hoods' => 'No Destroy Documents From Hoods',
			'no_destroy_documents_from_hood_clusters' => 'No Destroy Documents From Hood Clusters',
			'no_destroy_documents_from_hood_processors' => 'No Destroy Documents From Hood Processors',
			'no_destroy_documents_of_these_types' => 'No Destroy Documents Of These Types',
			'no_destroy_documents_of_these_categories' => 'No Destroy Documents Of These Categories',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('icon_height',$this->icon_height);
		$criteria->compare('icon_width',$this->icon_width);
		$criteria->compare('icon_mime_type',$this->icon_mime_type,true);
		$criteria->compare('poster_height',$this->poster_height);
		$criteria->compare('poster_width',$this->poster_width);
		$criteria->compare('poster_mime_type',$this->poster_mime_type,true);
		$criteria->compare('video_size',$this->video_size);
		$criteria->compare('document_mime_type',$this->document_mime_type,true);
		$criteria->compare('zip_file_size',$this->zip_file_size);
		$criteria->compare('zip_file_type',$this->zip_file_type,true);
		$criteria->compare('max_renewal_activation_number',$this->max_renewal_activation_number);
		$criteria->compare('default_allowable_min_percentage_task_share',$this->default_allowable_min_percentage_task_share);
		$criteria->compare('platform_default_currency_id',$this->platform_default_currency_id,true);
		$criteria->compare('platform_default_time_zone_id',$this->platform_default_time_zone_id,true);
		$criteria->compare('default_min_discount_settings',$this->default_min_discount_settings);
		$criteria->compare('platform_revenue_share',$this->platform_revenue_share);
		$criteria->compare('payment_holding_period',$this->payment_holding_period);
		$criteria->compare('excess_space_grace_period',$this->excess_space_grace_period);
		$criteria->compare('private_toolbox_min_subscription_no',$this->private_toolbox_min_subscription_no);
		$criteria->compare('private_toolboxes_price_per_task',$this->private_toolboxes_price_per_task);
		$criteria->compare('price_for_one_gigabyte_size',$this->price_for_one_gigabyte_size);
		$criteria->compare('xml_validation',$this->xml_validation);
		$criteria->compare('json_validation',$this->json_validation);
		$criteria->compare('enable_domain_initiator_verifier',$this->enable_domain_initiator_verifier);
		$criteria->compare('enable_platform_checker_verifier',$this->enable_platform_checker_verifier);
		$criteria->compare('include_private_toolboxes_in_space_calculation',$this->include_private_toolboxes_in_space_calculation);
		$criteria->compare('include_public_toolboxes_in_space_calculation',$this->include_public_toolboxes_in_space_calculation);
		$criteria->compare('include_restricted_public_toolboxes_in_space_calculation',$this->include_restricted_public_toolboxes_in_space_calculation);
		$criteria->compare('include_private_and_public_toolboxes_in_space_calculation',$this->include_private_and_public_toolboxes_in_space_calculation);
		$criteria->compare('include_private_restricted_toolboxes_in_space_calculation',$this->include_private_restricted_toolboxes_in_space_calculation);
		$criteria->compare('include_reserved_toolboxes_in_space_calculation',$this->include_reserved_toolboxes_in_space_calculation);
		$criteria->compare('number_of_months_before_expiration',$this->number_of_months_before_expiration);
		$criteria->compare('gibberish_file_mime_type',$this->gibberish_file_mime_type);
		$criteria->compare('maximum_gibberish_filesize',$this->maximum_gibberish_filesize);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('is_closeable',$this->is_closeable);
		$criteria->compare('max_file_at_closure',$this->max_file_at_closure);
		$criteria->compare('min_file_at_closure',$this->min_file_at_closure);
		$criteria->compare('could_be_reopened',$this->could_be_reopened);
		$criteria->compare('could_be_reopened_when_max_number_not_reached',$this->could_be_reopened_when_max_number_not_reached);
		$criteria->compare('overide_external_influence_on_parameters',$this->overide_external_influence_on_parameters);
		$criteria->compare('could_be_requested_by_all',$this->could_be_requested_by_all);
		$criteria->compare('consummable_by_hood_members',$this->consummable_by_hood_members);
		$criteria->compare('consummable_by_hood_clusters',$this->consummable_by_hood_clusters);
		$criteria->compare('restrict_doc_capture_to_members_of_cluster',$this->restrict_doc_capture_to_members_of_cluster);
		$criteria->compare('capture_only_these_document_types',$this->capture_only_these_document_types);
		$criteria->compare('accept_only_unique_batches',$this->accept_only_unique_batches);
		$criteria->compare('accept_batches_containing_doc_of_these_type',$this->accept_batches_containing_doc_of_these_type);
		$criteria->compare('accept_batches_containing_doc_of_these_category',$this->accept_batches_containing_doc_of_these_category);
		$criteria->compare('are_boxes_closeable',$this->are_boxes_closeable);
		$criteria->compare('are_closed_boxes_openable',$this->are_closed_boxes_openable);
		$criteria->compare('closed_boxes_are_openable_only_max_batch_not_reached',$this->closed_boxes_are_openable_only_max_batch_not_reached);
		$criteria->compare('need_special_permission_to_open_closed_boxes',$this->need_special_permission_to_open_closed_boxes);
		$criteria->compare('need_special_permission_to_add_to_closed_boxes',$this->need_special_permission_to_add_to_closed_boxes);
		$criteria->compare('max_number_of_batches_before_closing',$this->max_number_of_batches_before_closing);
		$criteria->compare('min_number_of_batches_before_closing',$this->min_number_of_batches_before_closing);
		$criteria->compare('effect_blacklist_during_request',$this->effect_blacklist_during_request);
		$criteria->compare('effect_whitelist_during_request',$this->effect_whitelist_during_request);
		$criteria->compare('effect_blacklist_at_consumption',$this->effect_blacklist_at_consumption);
		$criteria->compare('effect_whitelist_at_consumption',$this->effect_whitelist_at_consumption);
		$criteria->compare('list_conflict_resolution_preference',$this->list_conflict_resolution_preference,true);
		$criteria->compare('accept_all_box_on_request',$this->accept_all_box_on_request);
		$criteria->compare('box_is_consummable_by_hood_members',$this->box_is_consummable_by_hood_members);
		$criteria->compare('box_is_consummable_by_hood_clusters',$this->box_is_consummable_by_hood_clusters);
		$criteria->compare('apply_whitelist_during_request',$this->apply_whitelist_during_request);
		$criteria->compare('apply_blacklist_during_request',$this->apply_blacklist_during_request);
		$criteria->compare('documents_that_cannot_be_moved',$this->documents_that_cannot_be_moved);
		$criteria->compare('restrict_doc_movement_to_hoods',$this->restrict_doc_movement_to_hoods);
		$criteria->compare('documents_that_cannot_be_moved_outside_own_domain',$this->documents_that_cannot_be_moved_outside_own_domain);
		$criteria->compare('processor_docs_that_cant_be_moved',$this->processor_docs_that_cant_be_moved);
		$criteria->compare('processor_docs_that_cant_be_moved_beyond_domain',$this->processor_docs_that_cant_be_moved_beyond_domain);
		$criteria->compare('batches_cannot_be_moved',$this->batches_cannot_be_moved);
		$criteria->compare('restrict_batch_movement_to_these_hood',$this->restrict_batch_movement_to_these_hood);
		$criteria->compare('batch_cannot_be_moved_outside_own_domain',$this->batch_cannot_be_moved_outside_own_domain);
		$criteria->compare('boxes_cannot_be_moved',$this->boxes_cannot_be_moved);
		$criteria->compare('restrict_movement_of_boxes_to_hoods',$this->restrict_movement_of_boxes_to_hoods);
		$criteria->compare('boxes_cannot_be_moved_beyond_own_domain',$this->boxes_cannot_be_moved_beyond_own_domain);
		$criteria->compare('effect_blacklist_at_movement',$this->effect_blacklist_at_movement);
		$criteria->compare('effect_whitelist_at_movement',$this->effect_whitelist_at_movement);
		$criteria->compare('these_documents_not_reassignable',$this->these_documents_not_reassignable);
		$criteria->compare('these_batches_not_reassignable',$this->these_batches_not_reassignable);
		$criteria->compare('these_boxes_not_reassignable',$this->these_boxes_not_reassignable);
		$criteria->compare('restrict_document_reassignment_to_hoods',$this->restrict_document_reassignment_to_hoods);
		$criteria->compare('restrict_batches_reassignment_to_hoods',$this->restrict_batches_reassignment_to_hoods);
		$criteria->compare('restrict_boxes_reassignment_to_hoods',$this->restrict_boxes_reassignment_to_hoods);
		$criteria->compare('restrict_documents_reassignment_to_hood_clusters',$this->restrict_documents_reassignment_to_hood_clusters);
		$criteria->compare('restrict_batches_reassignment_to_hood_clusters',$this->restrict_batches_reassignment_to_hood_clusters);
		$criteria->compare('restrict_boxes_reassignment_to_hood_clusters',$this->restrict_boxes_reassignment_to_hood_clusters);
		$criteria->compare('effect_lifespan_to_document_type',$this->effect_lifespan_to_document_type);
		$criteria->compare('effect_lifespan_to_document_categories',$this->effect_lifespan_to_document_categories);
		$criteria->compare('retain_electronic_copy_of_destroyed_docs',$this->retain_electronic_copy_of_destroyed_docs);
		$criteria->compare('could_request_electronic_copy_of_destroyed_doc',$this->could_request_electronic_copy_of_destroyed_doc);
		$criteria->compare('no_global_request_for_destroyed_documents_of_type',$this->no_global_request_for_destroyed_documents_of_type);
		$criteria->compare('hood_that_could_access_destroyed_docs',$this->hood_that_could_access_destroyed_docs);
		$criteria->compare('clusters_that_could_access_destroyed_docs',$this->clusters_that_could_access_destroyed_docs);
		$criteria->compare('destroyed_doc_that_cannot_be_accessed_by_all',$this->destroyed_doc_that_cannot_be_accessed_by_all);
		$criteria->compare('effect_blacklist_at_destruction',$this->effect_blacklist_at_destruction);
		$criteria->compare('effect_whitelist_at_destruction',$this->effect_whitelist_at_destruction);
		$criteria->compare('all_doc_types_available_for_exchange',$this->all_doc_types_available_for_exchange);
		$criteria->compare('doc_types_available_for_exchange',$this->doc_types_available_for_exchange);
		$criteria->compare('restrict_exchange_of_doc_types_to_hood',$this->restrict_exchange_of_doc_types_to_hood);
		$criteria->compare('restrict_exchange_of_doc_types_to_clusters',$this->restrict_exchange_of_doc_types_to_clusters);
		$criteria->compare('effect_blacklist_at_exchange',$this->effect_blacklist_at_exchange);
		$criteria->compare('effect_whitelist_at_exchange',$this->effect_whitelist_at_exchange);
		$criteria->compare('all_doc_types_available_for_sharing',$this->all_doc_types_available_for_sharing);
		$criteria->compare('doc_types_available_for_sharing',$this->doc_types_available_for_sharing);
		$criteria->compare('restrict_sharing_of_doc_types_to_hood',$this->restrict_sharing_of_doc_types_to_hood);
		$criteria->compare('restrict_sharing_of_doc_types_to_clusters',$this->restrict_sharing_of_doc_types_to_clusters);
		$criteria->compare('effect_blacklist_at_sharing',$this->effect_blacklist_at_sharing);
		$criteria->compare('effect_whitelist_at_sharing',$this->effect_whitelist_at_sharing);
		$criteria->compare('all_doc_types_available_for_transfer',$this->all_doc_types_available_for_transfer);
		$criteria->compare('doc_types_available_for_transfer',$this->doc_types_available_for_transfer);
		$criteria->compare('restrict_transfer_of_doc_types_to_hood',$this->restrict_transfer_of_doc_types_to_hood);
		$criteria->compare('restrict_transfer_of_doc_types_to_clusters',$this->restrict_transfer_of_doc_types_to_clusters);
		$criteria->compare('effect_blacklist_at_transfer',$this->effect_blacklist_at_transfer);
		$criteria->compare('effect_whitelist_at_transfer',$this->effect_whitelist_at_transfer);
		$criteria->compare('all_doc_type_available_for_trading',$this->all_doc_type_available_for_trading);
		$criteria->compare('these_doctypes_available_for_trading',$this->these_doctypes_available_for_trading);
		$criteria->compare('restrict_trading_of_doctype_to_hoods',$this->restrict_trading_of_doctype_to_hoods);
		$criteria->compare('restrict_trading_of_doctype_to_clusters',$this->restrict_trading_of_doctype_to_clusters);
		$criteria->compare('allow_hood_to_trade_on_own_private_store',$this->allow_hood_to_trade_on_own_private_store);
		$criteria->compare('allow_doctypes_from_hoods_to_trade_on_store',$this->allow_doctypes_from_hoods_to_trade_on_store);
		$criteria->compare('no_destroy_documents_from_hoods',$this->no_destroy_documents_from_hoods);
		$criteria->compare('no_destroy_documents_from_hood_clusters',$this->no_destroy_documents_from_hood_clusters);
		$criteria->compare('no_destroy_documents_from_hood_processors',$this->no_destroy_documents_from_hood_processors);
		$criteria->compare('no_destroy_documents_of_these_types',$this->no_destroy_documents_of_these_types);
		$criteria->compare('no_destroy_documents_of_these_categories',$this->no_destroy_documents_of_these_categories);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return PlatformSettings the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
