<?php

/**
 * This is the model class for table "resourcegroupcategory".
 *
 * The followings are the available columns in table 'resourcegroupcategory':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $account_number
 * @property string $bank_name
 * @property string $swift_code
 * @property string $sort_code
 * @property string $operating_country
 * @property string $account_type
 * @property string $account_title
 * @property string $domain_type
 * @property string $corporate_email
 * @property string $contact_email
 * @property string $contact_mobile_number
 * @property string $rc_number
 * @property string $status
 * @property string $subscription_type
 * @property string $office_number
 * @property string $category
 * @property string $icon
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property Announcements[] $announcements
 * @property DomainHasTreaty[] $domainHasTreaties
 * @property DomainHasTreaty[] $domainHasTreaties1
 * @property Resourcegroup[] $resourcegroups
 * @property Treaty[] $treaties
 * @property Treaty[] $treaties1
 * @property UserHasNeed[] $userHasNeeds
 * @property Wishes[] $wishes
 * @property Wishes[] $wishes1
 */
class ResourceGroupCategory extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'resourcegroupcategory';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, domain_type, status', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, account_number, bank_name, swift_code, sort_code, account_title, corporate_email, contact_email, contact_mobile_number, rc_number, office_number, icon', 'length', 'max'=>60),
			array('description', 'length', 'max'=>150),
                        array('address', 'length', 'max'=>250),
			array('account_type', 'length', 'max'=>11),
			array('domain_type, status', 'length', 'max'=>10),
			array('subscription_type', 'length', 'max'=>34),
			array('category', 'length', 'max'=>21),
                        array('code', 'length', 'max'=>100),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, code,account_number, address,bank_name, swift_code, sort_code,  account_type, account_title, domain_type, corporate_email, contact_email, contact_mobile_number, rc_number, status, subscription_type, office_number, category, icon, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'announcements' => array(self::HAS_MANY, 'Announcements', 'category_id'),
			'domainHasTreaties' => array(self::HAS_MANY, 'DomainHasTreaty', 'domain_id'),
			'domainHasTreaties1' => array(self::HAS_MANY, 'DomainHasTreaty', 'related_domain_id'),
			'resourcegroups' => array(self::MANY_MANY, 'Resourcegroup', 'resourcegroup_has_resourcegroupcategory(category_id, resourcegroup_id)'),
			'treaties' => array(self::HAS_MANY, 'Treaty', 'related_domain_id'),
			'treaties1' => array(self::HAS_MANY, 'Treaty', 'domain_id'),
			'userHasNeeds' => array(self::HAS_MANY, 'UserHasNeed', 'category_id'),
			'wishes' => array(self::HAS_MANY, 'Wishes', 'tool_domain_id'),
			'wishes1' => array(self::HAS_MANY, 'Wishes', 'category_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'account_number' => 'Account Number',
			'bank_name' => 'Bank Name',
			'swift_code' => 'Swift Code',
			'sort_code' => 'Sort Code',
			'operating_country' => 'Operating Country',
			'account_type' => 'Account Type',
			'account_title' => 'Account Title',
			'domain_type' => 'Domain Type',
			'corporate_email' => 'Corporate Email',
			'contact_email' => 'Contact Email',
			'contact_mobile_number' => 'Contact Mobile Number',
			'rc_number' => 'Rc Number',
			'status' => 'Status',
			'subscription_type' => 'Subscription Type',
			'office_number' => 'Office Number',
			'category' => 'Category',
			'icon' => 'Icon',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('account_number',$this->account_number,true);
		$criteria->compare('bank_name',$this->bank_name,true);
		$criteria->compare('swift_code',$this->swift_code,true);
		$criteria->compare('sort_code',$this->sort_code,true);
		$criteria->compare('operating_country',$this->operating_country,true);
		$criteria->compare('account_type',$this->account_type,true);
		$criteria->compare('account_title',$this->account_title,true);
		$criteria->compare('domain_type',$this->domain_type,true);
		$criteria->compare('corporate_email',$this->corporate_email,true);
		$criteria->compare('contact_email',$this->contact_email,true);
		$criteria->compare('contact_mobile_number',$this->contact_mobile_number,true);
		$criteria->compare('rc_number',$this->rc_number,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('subscription_type',$this->subscription_type,true);
		$criteria->compare('office_number',$this->office_number,true);
		$criteria->compare('category',$this->category,true);
		$criteria->compare('icon',$this->icon,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Resourcegroupcategory the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that determines if a domain has an available space
         */
        public function isDomainWithAvailableSpace($domain_id,$filesize){
            
            $model = new DomainAssets;
            
            $current_used_spaces = $model->calculateTheTotalUsedSpaceByThisDomain($domain_id);
            
            $estimated_space_required = $current_used_spaces + $filesize;
            
            if($this->isEstimatedSpaceGreaterThanAllocatedSpace($domain_id,$estimated_space_required)){
                return false;
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that determines if estimated space is greater than allocated space
         */
        public function isEstimatedSpaceGreaterThanAllocatedSpace($domain_id,$estimated_space_required){
            
            $domain_allocated_space = $this->getDomainAllocatedSpace($domain_id);
            if($domain_allocated_space>$estimated_space_required){
                return false;
            }else{
                return true;
            }
            
        }
        
        
        /**
         * This is the function that retrieves a domains allocated space
         */
        public function getDomainAllocatedSpace($domain_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$domain_id);
            $domain = ResourceGroupCategory::model()->find($criteria);
                       
            return $domain['allocated_space'];
        }
        
        /**
         * this is the function that retrieves the totral number of domains based on domain types
         */
        public function getTheTotalCountOfThisScriptWithDomainType($domain_type){
            
            $criteria = new CDbCriteria();
            $criteria->condition = "domain_type='$domain_type'";
            $count = ResourceGroupCategory::model()->count($criteria);
            return $count;
        }
        
        
        /**
         * this is the function that retrieves the total number of domains based on domain types and country
         */
        public function getTheTotalCountOfThisScriptWithDomainTypeAndCountry($domain_type,$country_id){
            
            $criteria = new CDbCriteria();
            $criteria->condition = "domain_type='$domain_type' and country_id=$country_id";
            $count = ResourceGroupCategory::model()->count($criteria);
            return $count;
        }
        
        
         /**
         * this is the function that retrieves the total number of domains based on domain types and category
         */
        public function getTheTotalCountOfThisScriptWithDomainTypeAndCategory($domain_type,$category){
            
            $criteria = new CDbCriteria();
            $criteria->condition = "domain_type='$domain_type' and category='$category'";
            $count = ResourceGroupCategory::model()->count($criteria);
            return $count;
        }
        
        
          /**
         * this is the function that retrieves the total number of domains based on domain types, country and category
         */
        public function getTheTotalCountOfThisScriptWithDomainTypeCategoryAndCountry($domain_type,$category,$country_id){
            
            $criteria = new CDbCriteria();
            $criteria->condition = "domain_type='$domain_type' and (category='$category' and country_id=$country_id)";
            $count = ResourceGroupCategory::model()->count($criteria);
            return $count;
        }
        
        
        /**
         * This is the function that determines if a domain is of the type required
         */
        public function isDomainOfTheRequiredDomainType($domain_id,$domain_type){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroupcategory')
                    ->where("id = $domain_id and domain_type='$domain_type'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that determines if a domain is of the type and from teh country required
         */
        public function isDomainOfTheRequiredDomainTypeAndCountry($domain_id,$domain_type,$country_id){
            
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroupcategory')
                    ->where("id = $domain_id and (domain_type='$domain_type' and country_id=$country_id)");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
           
            
        }
        
        
        /**
         * This is the function that retrieves a country's name
         */
        public function getThisDomainName($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria);
             return $domain['name'];
        }
        
        
        /**
         * This is the function that confirms if domain is the platform domain
         */
        public function isUserDomainThePlatformDomain($domain_id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria);
             
             if($domain['is_platform_domain'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        /**
         * This is the function that retrieves all domains on the platform
         */
        public function retrieveAllDomains(){
            
            $all_domains = [];
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             //$criteria->condition='id=:id';   
             //$criteria->params = array(':id'=>$domain_id);
             $domains = ResourceGroupCategory::model()->findAll($criteria);
             
             foreach($domains as $domain){
                 $all_domains[] = $domain['id'];
             }
             return $all_domains;
             
            
        }
        
        
        /**
         * This is the function that lists all verified domains
         */
        public function retrieveAllVerifiedDomains(){
            
           $model = new DomainVerification;
           return retrieveAllVerifiedDomains();
        }
        
        
        /*8
         * This is the function that gets the name of a domain
         */
        public function getTheDomainNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria);
             return $domain['name'];
        }
        
        
        /**
         * This is the function that retrieves the platform domain id
         */
        public function getThePlatformDomainId(){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='is_platform_domain=:id';   
             $criteria->params = array(':id'=>1);
             $domain = ResourceGroupCategory::model()->find($criteria);
             
            return $domain['id'];
        }
        
        
        
        
         /**
         * This is the function that updates a domain information on verification
         */
        public function isDomainRecordSuccessfullyUpdated($domain_id,$name,$address,$rc_number,$website,$website_expiry_date,$residency_expiry_date,$official_emal,$wechat_profile,$telegram_profile,$whatsapp_profile,$facebook_profile,$tweeter_handle,$youtube_channel,$logo,$instagram_profile,$first_office_phone_number,$second_office_phone_number){
            //move the logo to its location
            $icon = $this->moveTheImageToItsPathAndReturnTheFilenameName($logo);
            
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('resourcegroupcategory',
                                  array(
                                    'name'=>$name,
                                    'address'=>$address,
                                    'rc_number'=>$rc_number,
                                    'website'=>$website,
                                    'website_expiry_date'=>$website_expiry_date,
                                    'residency_expiry_date'=>$residency_expiry_date,
                                    'official_email'=>$official_emal,
                                    'email_address'=>$official_emal,  
                                    'wechat_profile'=>$wechat_profile,
                                    'telegram_profile'=>$telegram_profile,
                                    'whatsapp_profile'=>$whatsapp_profile,
                                    'facebook_profile'=>$facebook_profile,
                                    'tweeter_handle'=>$tweeter_handle,
                                    'youtube_channel'=>$youtube_channel,
                                    'instagram_profile'=>$instagram_profile,
                                    'first_office_phone_number'=>$first_office_phone_number,
                                    'second_office_phone_number'=>$second_office_phone_number,
                                    'icon'=>$icon  
     
                            ),
                     ("id=$domain_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
           /**
         * This is the function that determines the type and size of icon file
         */
        public function isFileTypeSuitable(){
            
           if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['icon']['tmp_name'];
                $iconFileName = $_FILES['icon']['name'];    
                $iconFileType = $_FILES['icon']['type'];
                $iconFileSize = $_FILES['icon']['size'];
            } 
          if(($iconFileType == 'image/jpg' or $iconFileType =='image/png' or $iconFileType == 'image/jpeg')){
              return true;
               
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that moves file to its destination
         */
        public function moveTheImageToItsPathAndReturnTheFilenameName($icon_filename){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                   }
                    if($icon_filename == NULL){
                        $iconFileName = $icon_filename;
                         return $iconFileName;
                        
                    }else{
                        if($iconName !== null) {
                        if($icon_filename != ""){
                                
                              $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['images'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                   
                            }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
                        
                    }
                    
        }
        
        
         /**
         * This is the function that gets the id of the guest domain
         */
        public function getTheIdOfTheGuestDomain(){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='is_guest_domain=:guestid';   
             $criteria->params = array(':guestid'=>1);
             $domain = ResourceGroupCategory::model()->find($criteria);
             return $domain['id'];
        }
        
        
        /**
         * This is the function that determines if a domain is a guest domain
         */
        public function isThisUserDomainAGuestDomain($domain_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria);
             
             if($domain['is_guest_domain'] == 1){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that retrieves a domain unique number
         */
        public function getThisDomainUniqueNumber($domain_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria);
             
             return $domain['rc_number'];
        }
        
        /**
         * This is the function that retrieves a domain country code
         */
        public function getThisDomainCountryCode($domain_id){
             $model = new Country;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$domain_id);
             $domain = ResourceGroupCategory::model()->find($criteria);
             
             return $model->getCountryCodeGivenId($domain['country_id']);
        }
        
        
        
         /**
         * This is the function that determines if a domain code exist
         */
        public function isDomainCodeExist($code){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroupcategory')
                    ->where("code = '$code'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that retrieves a domain id given its code
         */
        public function getTheIdOfThisDomain($code){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='code=:code';   
             $criteria->params = array(':code'=>$code);
             $domain = ResourceGroupCategory::model()->find($criteria);
             
             return $domain['id'];
        }
        
        
       /**
         * This is the function that determines if a domain exist
         */
        public function isThisDomainAvailable($domain_id){
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroupcategory')
                    ->where("id = $domain_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                    
        }
        
        
        /**
         * This is the function that retrieves the code of a domain
         * 
         */
        public function getDomainCode($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $domain = ResourceGroupCategory::model()->find($criteria);
            
            
            return $domain['code'];
        }
        
        
        /**
         * This is the function that determines if a domain code is a unique
         */
        public function isThisCodeUnique($code){
           $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroupcategory')
                    ->where("code = '$code'");
                $result = $cmd->queryScalar();
                
                if($result==0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retrieves the existing domain code of a domain
         */
        public function retrieveTheExistingDomainCode($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $domain = ResourceGroupCategory::model()->find($criteria);
            
            
            return $domain['code'];
        }
        
        
        /**
         * This is the function that determines if an updated code is unique
         */
        public function isThisUpdatedDomainCodeUnique($code,$id){
            if($this->isThisCodeUnique($code)){
                return true;
            }else if($this->isThisAnExistingDomainCodeForThisDomain($code,$id)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that determines if a code belongs to a domain
         */
        public function isThisAnExistingDomainCodeForThisDomain($code,$id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $domain = ResourceGroupCategory::model()->find($criteria);
            
            if($domain['code'] =="$code"){
                return true;
            }else{
                return false;
            }
        }
}
