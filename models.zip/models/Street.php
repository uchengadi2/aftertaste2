<?php

/**
 * This is the model class for table "street".
 *
 * The followings are the available columns in table 'street':
 * @property string $id
 * @property string $name
 * @property string $city_id
 * @property string $is_street_gated
 * @property string $street_gate_colour
 * @property string $street_road_condition
 * @property integer $is_street_with_street_light_facility
 * @property string $is_street_light_facilities_working
 * @property string $nearest_busstop_to_the_street
 * @property string $is_street_guided_with_securities
 * @property string $does_street_allow_commercial_bikes
 * @property string $does_street_allow_commercial_keke
 * @property string $does_street_allow_commercial_buses
 * @property string $location_summary_from_popular_city_landmark
 */
class Street extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'street';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('city_id', 'required'),
			array('name, street_gate_colour, nearest_busstop_to_the_street, location_summary_from_popular_city_landmark', 'length', 'max'=>250),
			array('city_id', 'length', 'max'=>10),
			array('is_street_gated, is_street_light_facilities_working, is_street_guided_with_securities, does_street_allow_commercial_bikes, does_street_allow_commercial_keke, is_street_with_street_light_facility,does_street_allow_commercial_buses', 'length', 'max'=>16),
			array('street_road_condition', 'length', 'max'=>27),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, city_id, is_street_gated, street_gate_colour, street_road_condition, is_street_with_street_light_facility, is_street_light_facilities_working, nearest_busstop_to_the_street, is_street_guided_with_securities, does_street_allow_commercial_bikes, does_street_allow_commercial_keke, does_street_allow_commercial_buses, location_summary_from_popular_city_landmark', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'city_id' => 'City',
			'is_street_gated' => 'Is Street Gated',
			'street_gate_colour' => 'Street Gate Colour',
			'street_road_condition' => 'Street Road Condition',
			'is_street_with_street_light_facility' => 'Is Street With Street Light Facility',
			'is_street_light_facilities_working' => 'Is Street Light Facilities Working',
			'nearest_busstop_to_the_street' => 'Nearest Busstop To The Street',
			'is_street_guided_with_securities' => 'Is Street Guided With Securities',
			'does_street_allow_commercial_bikes' => 'Does Street Allow Commercial Bikes',
			'does_street_allow_commercial_keke' => 'Does Street Allow Commercial Keke',
			'does_street_allow_commercial_buses' => 'Does Street Allow Commercial Buses',
			'location_summary_from_popular_city_landmark' => 'Location Summary From Popular City Landmark',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('city_id',$this->city_id,true);
		$criteria->compare('is_street_gated',$this->is_street_gated,true);
		$criteria->compare('street_gate_colour',$this->street_gate_colour,true);
		$criteria->compare('street_road_condition',$this->street_road_condition,true);
		$criteria->compare('is_street_with_street_light_facility',$this->is_street_with_street_light_facility);
		$criteria->compare('is_street_light_facilities_working',$this->is_street_light_facilities_working,true);
		$criteria->compare('nearest_busstop_to_the_street',$this->nearest_busstop_to_the_street,true);
		$criteria->compare('is_street_guided_with_securities',$this->is_street_guided_with_securities,true);
		$criteria->compare('does_street_allow_commercial_bikes',$this->does_street_allow_commercial_bikes,true);
		$criteria->compare('does_street_allow_commercial_keke',$this->does_street_allow_commercial_keke,true);
		$criteria->compare('does_street_allow_commercial_buses',$this->does_street_allow_commercial_buses,true);
		$criteria->compare('location_summary_from_popular_city_landmark',$this->location_summary_from_popular_city_landmark,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Street the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that gets the name of a street
         */
        public function getTheNameOfThisStreet($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $street= Street::model()->find($criteria);
                
                return $street['name'];
        }
}
