<?php

/**
 * This is the model class for table "user_has_location".
 *
 * The followings are the available columns in table 'user_has_location':
 * @property string $id
 * @property string $user_id
 * @property string $location_id
 * @property string $status
 * @property string $active_start_date
 * @property string $active_end_date
 * @property string $inactive_start_date
 * @property string $inactive_end_date
 * @property integer $assigned_by
 * @property integer $update_user_id
 */
class UserHasLocation extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_has_location';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('id, user_id, location_id, status', 'required'),
			array('assigned_by, update_user_id', 'numerical', 'integerOnly'=>true),
			array('id, user_id, location_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>8),
			array('active_start_date, active_end_date, inactive_start_date, inactive_end_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, location_id, status, active_start_date, active_end_date, inactive_start_date, inactive_end_date, assigned_by, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'location_id' => 'Location',
			'status' => 'Status',
			'active_start_date' => 'Active Start Date',
			'active_end_date' => 'Active End Date',
			'inactive_start_date' => 'Inactive Start Date',
			'inactive_end_date' => 'Inactive End Date',
			'assigned_by' => 'Assigned By',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('location_id',$this->location_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('active_start_date',$this->active_start_date,true);
		$criteria->compare('active_end_date',$this->active_end_date,true);
		$criteria->compare('inactive_start_date',$this->inactive_start_date,true);
		$criteria->compare('inactive_end_date',$this->inactive_end_date,true);
		$criteria->compare('assigned_by',$this->assigned_by);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return UserHasLocation the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
