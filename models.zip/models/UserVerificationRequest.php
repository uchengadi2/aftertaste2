<?php

/**
 * This is the model class for table "user_verification_request".
 *
 * The followings are the available columns in table 'user_verification_request':
 * @property string $id
 * @property string $user_id
 * @property string $status
 * @property string $type
 * @property string $invoice_id
 * @property integer $requestor_id
 * @property integer $requestor_domain_id
 * @property integer $domain_transaction_id
 * @property string $date_requested
 * @property string $date_verified
 * @property integer $verified_by
 * @property integer $is_freezed
 * @property integer $freezed_by
 * @property string $date_freezed
 * @property string $verification_code
 */
class UserVerificationRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_verification_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('user_id, status, type, invoice_id', 'required'),
			array('requestor_id, requestor_domain_id, domain_transaction_id, verified_by, is_freezed, freezed_by', 'numerical', 'integerOnly'=>true),
			array('user_id, type, invoice_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>12),
			array('verification_code', 'length', 'max'=>250),
			array('date_requested, date_verified, date_freezed', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, status, type, invoice_id, requestor_id, requestor_domain_id, domain_transaction_id, date_requested, date_verified, verified_by, is_freezed, freezed_by, date_freezed, verification_code', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'status' => 'Status',
			'type' => 'Type',
			'invoice_id' => 'Invoice',
			'requestor_id' => 'Requestor',
			'requestor_domain_id' => 'Requestor Domain',
			'domain_transaction_id' => 'Domain Transaction',
			'date_requested' => 'Date Requested',
			'date_verified' => 'Date Verified',
			'verified_by' => 'Verified By',
			'is_freezed' => 'Is Freezed',
			'freezed_by' => 'Freezed By',
			'date_freezed' => 'Date Freezed',
			'verification_code' => 'Verification Code',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('invoice_id',$this->invoice_id,true);
		$criteria->compare('requestor_id',$this->requestor_id);
		$criteria->compare('requestor_domain_id',$this->requestor_domain_id);
		$criteria->compare('domain_transaction_id',$this->domain_transaction_id);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('date_verified',$this->date_verified,true);
		$criteria->compare('verified_by',$this->verified_by);
		$criteria->compare('is_freezed',$this->is_freezed);
		$criteria->compare('freezed_by',$this->freezed_by);
		$criteria->compare('date_freezed',$this->date_freezed,true);
		$criteria->compare('verification_code',$this->verification_code,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return UserVerificationRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
         /**
         * This is the function that initiates a domain verification request
         */
        public function isUserVerificationRequestMadeSuccesfully($user_id){
            
            $model = new DomainTransactions;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
             //$user_id = Yii::app()->user->id;
             //confirm if these domain has a live transaction tree. create it if unavailable
            if($model->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $model->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $model->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
           // $location_invoice_id = 0;
            
            $this->user_id = $user_id;
            $this->invoice_id = $location_invoice_id;
            $this->status = strtolower("requested");
            $this->type = strtolower("fresh");
            $this->requestor_domain_id = $domain_id;
            $this->domain_transaction_id = $domain_trans_id;
            $this->date_requested = new CDbExpression('NOW()');
            $this->requestor_id = Yii::app()->user->id;
            
            $this->verification_code = $this->generateTheVerificationCode($user_id,$domain_id);
            
            if($location_invoice_id>0){
                 if($this->isThisRequestNotAlreadyMade($user_id,$domain_id)){
                     if($this->save()){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
                
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
        
        
           /**
         * This is the function that retrieves the pending invoice id of a user's location
         */
        public function getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id){
            $model = new Invoice;
            return $model->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
        }
        
        /**
         * This is the function that determines if a request had already been made
         */
        public function isThisRequestNotAlreadyMade($user_id,$domain_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_verification_request')
                    ->where("user_id = $user_id");
                $result = $cmd->queryScalar();
                
                if($result==0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that generates the verification code
         */
        public function generateTheVerificationCode($user_id,$domain_id){
            
            $model = new DomainLocations;
            //get the first 3 letters of the domain name
                $domain_first_three_letters = strtoupper($this->getThePurchasingDomainNameFirstThreeLetters($domain_id)); 
                
                //get the location name of this user
                $location_name = $model->getTheLocationOfThisUser($user_id);
           
                //get the first three letters of the location
                $location_first_three = strtoupper(substr($location_name,0,3));
                    //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
               
                $verification_code = "$random_number-$location_first_three$domain_first_three_letters$user_id$domain_id";
                
                return $verification_code; 
        }
        
        
        
         /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstThreeLetters($domain_id){
                
                $model = new ResourceGroupCategory;    
                //get the domain name
                $domainname = $model->getThisDomainName($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,3);
                
                return $substring;
            }
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
            
               /**
         * This is the function that updates a user verification request
         */
        public function isUpdateOfUserVerificationRequestMadeSuccesfully($user_id){
            
            $model = new DomainTransactions;
           $domain_id = $this->getTheDomainIdOfThisUser($user_id);
             //confirm if these domain has a live transaction tree. create it if unavailable
            if($model->isDomainWithLiveTransaction($domain_id) == false){
                //add a new domain transaction tree
                $domain_trans_id = $model->newDomainTransactionTreeAdded($domain_id);
            }else{
                $domain_trans_id = $model->getTheLiveDomainTransId($domain_id);
            }
            
            $location_invoice_id = $this->getThisUserPendingLocationInvoice($user_id,$domain_id,$domain_trans_id);
            //get the transaction type
            if($this->isTheStatusOfTheCurrentDomainVerificationRequestVerified($user_id)){
                $type = strtolower('reverified');
            }else{
                $type = strtolower('fresh');
            }
            
         
            if($location_invoice_id>0){
                
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('user_verification_request',
                                  array(
                                    'invoice_id' => $location_invoice_id,
                                    'status' => strtolower("requested"),
                                    'type' => $type,
                                    'requestor_domain_id' => $domain_id,
                                    'domain_transaction_id' => $domain_trans_id,
                                    'date_requested' => new CDbExpression('NOW()'),
                                    'requestor_id' => Yii::app()->user->id
     
                            ),
                     ("user_id=$user_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
               
                
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that determines the current domain verification status
         */
        public function isTheStatusOfTheCurrentDomainVerificationRequestVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $request = UserVerificationRequest::model()->find($criteria);
             
             if($request['status'] == strtolower('verified')){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function tat confirms if a user verification request is frozen successfully
         */
        public function isTheFreezingOfThisUserVerificationRequestASuccess($user_id){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('user_verification_request',
                                  array(
                                    'is_freezed'=>1,
                                    'freezed_by'=>Yii::app()->user->id,
                                   'date_freezed'=>new CDbExpression('NOW()')
                                   
                               
		
                            ),
                     ("user_id=$user_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        
        
          /**
         * This is the function that effects verification on a user verification request
         */
        public function isTheVerificationOfThisUserVerificationRequestMadeSuccesfully($user_id){
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('user_verification_request',
                                  array(
                                     'status'=>"verified",
                                    'verified_by'=>Yii::app()->user->id,
                                    'date_verified'=>new CDbExpression('NOW()'),
                                   
                            ),
                     ("user_id=$user_id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
}
