<?php

/**
 * This is the model class for table "verification_cost".
 *
 * The followings are the available columns in table 'verification_cost':
 * @property string $id
 * @property string $verification_code
 * @property string $type
 * @property double $cost
 * @property integer $is_cost_quotatble
 */
class VerificationCost extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'verification_cost';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('type', 'required'),
			array('is_cost_quotatble', 'numerical', 'integerOnly'=>true),
			array('cost', 'numerical'),
			array('verification_code', 'length', 'max'=>250),
			array('type', 'length', 'max'=>6),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, verification_code, type, cost, is_cost_quotatble', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'verification_code' => 'Verification Code',
			'type' => 'Type',
			'cost' => 'Cost',
			'is_cost_quotatble' => 'Is Cost Quotatble',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('verification_code',$this->verification_code,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('cost',$this->cost);
		$criteria->compare('is_cost_quotatble',$this->is_cost_quotatble);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return VerificationCost the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
         /**
         * This is the function that gets the consumption cost of a home address verification
         */
        public function getTheUnitCostOfConsumptionTransaction(){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='verification_code=:code';
            $criteria1->params = array(':code'=>"home_address");
            $cost= VerificationCost::model()->find($criteria1);
            
            return $cost['cost'];
        }
}
